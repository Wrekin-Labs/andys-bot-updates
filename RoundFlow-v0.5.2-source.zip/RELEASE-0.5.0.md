# RoundFlow v0.5.0 — Live Geographic Routing Foundation

Date: 5 October 2026
Package: `uk.co.roundflow.app`
Android versionCode: 26

## Major routing upgrade
- Added Mapbox Geocoding API v6 integration for real UK address -> latitude/longitude lookup.
- Jobs can persist real latitude/longitude, geocode label/provider and geocoded timestamp.
- Added Mapbox Directions driving-traffic integration for real road distance, travel time and route geometry.
- Added Mapbox Optimization v1 integration for duration-optimized road order on normal-sized days.
- Added Mapbox Static Images route view for a real geographic map, numbered pins and route polyline without a native-map dependency.
- Added road-based Start Furthest using Mapbox Matrix travel time rather than straight-line distance.
- Mapbox live features activate only when `EXPO_PUBLIC_MAPBOX_TOKEN` is configured.
- Larger/time-window/multi-worker routing is explicitly reserved for `EXPO_PUBLIC_ROUNDFLOW_ROUTING_URL` advanced backend; no fake optimisation is claimed.

## Squeegee-style Day Pilot improvements
- Worker filter: All Workers or a specific active worker.
- Not Done / Completed / All filters apply within the selected worker's day.
- Area/round colour groups remain visible.
- Manual and Area-planned local routing retained.
- Job-specific Start/End controls retained.
- Each worker can store default route start/end addresses (home/depot/business).
- If no job-specific endpoints are selected and a worker has both defaults, live routing uses those as true geographic endpoints.
- Ignore Time toggle for fast routing.
- Start Furthest option uses road travel-time lookup when live routing is configured.
- Fixed appointment flag + start/end time window fields on each job.
- Time-window aware optimisation is not falsely claimed by Mapbox Optimization v1; it requires the advanced backend / future Optimization v2-style solver.

## Phone / tablet / PC
- Same responsive RoundFlow product is preserved across Android phone/tablet and PC/web.
- PC/tablet split route planning remains available.
- Local planner continues working offline even without Mapbox/Supabase.
- Google Maps hand-off remains available for turn-by-turn navigation.

## Data safety
- Coordinate ranges are validated.
- Latitude/longitude must exist as a pair.
- Geocode metadata and appointment-window fields survive core snapshots.
- Existing v0.3/v0.4 data remains additive/backward-safe.

## Environment
```
EXPO_PUBLIC_MAPBOX_TOKEN=
EXPO_PUBLIC_ROUNDFLOW_ROUTING_URL=
```
The Mapbox token is a public client token. Do not put GraphHopper/server secrets or Supabase service-role keys in the app.

## Verification target
- TypeScript
- CSV parser
- Invoice integrity 11/11
- v0.4.0 suite 18/18
- v0.4.1 suite 2/2
- v0.4.2 suite 8/8
- v0.5.0 routing/data suite 5/5
- PC/web export
- signed APK/AAB
- Android upgrade/install/launch smoke

## External/commercial items still required
- Create/configure a Mapbox account/token for live geographic routing.
- Dedicated production RoundFlow Supabase and true multi-device sync.
- Advanced routing backend for >12-stop optimisation, fixed time windows and multi-vehicle/worker VRP (GraphHopper or equivalent).
- Provider-backed customer payments, SaaS billing, automatic SMS/email and customer portal.
