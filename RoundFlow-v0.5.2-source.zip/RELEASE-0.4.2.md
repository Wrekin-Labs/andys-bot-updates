# RoundFlow v0.4.2 — Planning, Capacity & Visit Tracking

Date: 5 October 2026  
Package: `uk.co.roundflow.app`  
Android versionCode: 25

## Added in v0.4.2

### Forward capacity
- New **Capacity** planner mode covering the next 28 days.
- Shows jobs, planned minutes, day value and percentage of configured team capacity.
- Status labels: Available / Healthy / Nearly full / Over capacity.
- Weekly planner now shows capacity % for each day.

### Worker capacity and skills
- Team users can store skills and daily working capacity in minutes.
- Jobs can be assigned from one-tap worker chips.
- Required job skills are checked against the assigned active worker.
- Skill gaps are shown directly on job cards.
- Older jobs with no worker set fall back to the active Owner for skill matching.

### Bulk replanning
- One tap can move all unfinished active jobs on the selected day:
  - +1 day;
  - +1 week.
- Rescheduling is recorded in the visit/job history.

### Visit/job tracking
- Completing, skipping, reopening and bulk rescheduling add a visit-history event.
- Visit history is visible inside Job Tools.
- Events retain timestamp, worker and reschedule note where applicable.

### Day Pilot and route planning
- Day Pilot switch: Not Done / Completed / All for the selected date.
- Colour-coded area groups with consistent route numbering.
- Manual or area-planned route ordering.
- Explicit route Start and End controls.
- Planned order can be applied back to the day's round order.
- Google Maps receives the selected ordered stops for real road navigation.
- The in-app route surface remains an honest schematic planning view; it does not claim geographic pin positions, mileage or travel time without a production mapping provider.

### Existing v0.4.1 capability retained
- Phone / tablet / PC responsive UI.
- Dark compact planner.
- List / Map / Week / Calendar.
- Colour-coded numbered route plan.
- Job files/photos, checklists, custom fields, hazards/risks, required skills and time recording.
- Feature hub, marketing drafts and marketplace listing drafts.
- Invoices, quotes, reminders, statements, expenses, reporting and backups.

## Verification
- TypeScript: PASS
- CSV parser: PASS
- Invoice integrity: 11/11 PASS
- v0.4.0 suite: 18/18 PASS
- v0.4.1 suite: 2/2 PASS
- v0.4.2 planning suite: 8/8 PASS
- PC/web production export: PASS
- Android APK build/signature: PASS
- Android AAB build/signature: PASS
- Android in-place install/launch smoke: PASS (v0.4.2 / code 25)
- Day Pilot UI smoke: PASS (Not Done / Completed / All)
- Map/route UI smoke: PASS (Manual / Area planned / Apply order / Start / End)

### Final Android SHA-256
- APK: `EBDFF7C3702F22B668A44EC489E1BC6CB8A18DA6DF05534263320F3DAE306527`
- AAB: `64628F6A4BF35FC605E29FB5FE2FC998462ACD1885A3A27BBB9FD1B0D652465D`
- Signing certificate SHA-256: `bab5e67dd732cf992c378ec9284d4632f52520995306af2fb8c40ca5e229b02e`

## Dependency audit note
`npm audit --omit=dev --audit-level=high` still reports upstream Expo/Metro toolchain advisories. npm's forced remediation proposes a breaking Expo downgrade to 44, so it was not applied. Revisit when compatible upstream fixes are available.

## Still external / commercial
- Dedicated production Supabase.
- Real multi-device sync and live team updates.
- Embedded geographic map/routing provider for true turn-by-turn optimisation.
- Stripe/GoCardless/PayPal production payments/webhooks.
- RoundFlow SaaS billing.
- Automatic provider-backed email/SMS.
- Secure customer portal.
