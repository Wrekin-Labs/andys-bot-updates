# RoundFlow

Window-cleaning rounds and invoicing for Android. Version 0.4.0, application ID `uk.co.roundflow.app`, Android version code 23.

RoundFlow is a local-first Android beta. Customers, recurring rounds, completion/undo/skip, invoices, partial payments, payment reversal, void invoices, PDF sharing, numbered quotes, expenses, insights/reports, reminders, statements, water fills, business/payment details and backups are available locally. Dedicated cloud/team sync, provider payment collection, automatic background reminders and hosted customer portals are not live.

## Development

Use Node 24 and the committed npm lockfile. The project uses Expo SDK 57 and React Native 0.86. Read `AGENTS.md` before changes.

```
npm ci
npm run typecheck
npm test
```

`npm test` includes the CSV parser test, the original 11 invoice/data-integrity regressions, and 18 v0.4.0 regressions.

## Android release

Use JDK 17, Android SDK 36 and the existing upload keystore. On Windows:

```powershell
powershell -File scripts/build_android.ps1 -JdkHome "<your JDK 17 directory>"
```

The script runs checks and requires the existing, untracked `android/keystore.properties` configuration. Keep signing files and passwords out of Git. Do not replace the upload key or application ID.

Expected outputs are:

- `android/app/build/outputs/apk/release/app-release.apk`
- `android/app/build/outputs/bundle/release/app-release.aab`

The full release build includes all configured Android architectures.

## Major changes in 0.4.0

- Customer balances are derived from opening adjustments plus unpaid invoice balances instead of being hand-maintained in multiple handlers.
- Upgrade migration preserves every displayed v0.3.x balance and stores an untouched pre-upgrade core snapshot.
- Undo completion voids the issued invoice instead of deleting it; invoice numbers remain auditable.
- Partial payments, reversals, overdue state, due dates and statements share the same ledger rules.
- Statements show total, paid, balance and running outstanding, including opening balances.
- Quotes have numbers, expiry/status handling and guarded conversion to job/invoice.
- Business/payment profile supports trading/contact details, VAT details, bank details, optional payment URL, payment terms and invoice footer.
- Payment reminders have friendly/overdue/final templates, SMS/email composer hand-off and reminder history.
- Money includes invoice filters and Insights with received/invoiced/expenses/net, aged debt, balances and worker metrics.
- Routes split long Google Maps hand-offs into chained legs and can order locally by area/postcode.
- CSV import/export is hardened against spreadsheet formula injection and preserves one-off frequencies/opening balances.
- Full backup can export corrupt side-data verbatim for recovery and validates before restore.
- Attachments are copied to app document storage instead of relying on purgeable cache URIs.
- The draft Supabase data model was replaced with a tenant-isolated RLS design and local SQL tests. It is not deployed yet.
- Accessibility labels/states, larger targets and small-screen handling were improved.

The canonical core snapshot intentionally remains `version: 1` with an additive revision so v0.3.1 can still read core jobs/invoices. Export a full backup before any downgrade because v0.3.1 does not understand newer side-data/features.

## Verification

Verified on Andy Home on 5 October 2026:

- TypeScript: 0 errors.
- CSV parser: pass.
- Original invoice/data regressions: 11/11 pass.
- v0.4.0 regressions: 18/18 pass.
- Release APK/AAB produced with version 0.4.0 / code 23.
- APK signature verifies with the existing RoundFlow upload certificate.
- Dedicated API 35 emulator upgraded in-place from signed 0.3.0/code 21 to 0.4.0/code 23.
- Android invoice/upgrade flow: 8/8 pass, including balance retention, decimal edit, partial payment, undo protection, duplicate, reversal, void-on-undo, invoice sequencing and restart persistence.

See `RELEASE_STATUS.md` for hashes and remaining external deployment gates.

## Cloud / commercial deployment

The app is usable locally without cloud services. Commercial multi-device/team deployment still requires a dedicated RoundFlow Supabase project, a rewritten sync engine against the new tenant model, invitation delivery, subscription billing, live customer payment-provider integrations and hosted legal/store assets. Do not point RoundFlow at an unrelated existing Supabase project.
