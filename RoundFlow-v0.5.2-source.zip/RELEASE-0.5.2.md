# RoundFlow v0.5.2 — Managed Routing & Real Map Pins

Date: 5 October 2026
Package: `uk.co.roundflow.app`
Android versionCode: 28

## Cleaner-facing routing is now built in
Cleaners no longer create a mapping account, paste API keys, test provider credentials or configure routing URLs.

Cleaner flow:
- add customers/addresses;
- open Today → Map;
- choose worker / Not Done / Completed / All;
- use Road Preview or Optimise road order;
- tap numbered pins to open jobs;
- use Google Maps for turn-by-turn navigation.

Routing provider credentials are a RoundFlow/Wrekin Labs operator concern, not an end-user concern.

## Real map pins
- Live route map uses real customer latitude/longitude.
- Numbered pins match the route list exactly.
- Pin fill colour follows the job area/round.
- Pin border reflects status (scheduled / done / owing / skipped).
- Tapping a pin opens the matching customer/job.
- Real route line follows live road geometry.
- Phone uses map + stop list; tablet/PC use the wider split layout.
- The old schematic pin board remains only as the local/offline fallback when managed live routing is not enabled.

## Automatic customer locating
- Missing customer locations are geocoded automatically when Road Preview or Optimise is used.
- No separate Locate button or provider setup step is required.
- Bad/unmatched customer addresses produce a human-readable address warning.
- RoundFlow does not invent coordinates, mileage or travel time.

## Managed routing configuration
Operator/build setting:
```
EXPO_PUBLIC_MAPBOX_TOKEN=
```
This is one centrally managed PUBLIC token owned by RoundFlow/Wrekin Labs. Cleaners never enter it.

Future advanced managed backend:
```
EXPO_PUBLIC_ROUNDFLOW_ROUTING_URL=
```
Reserved for >12-point optimisation, true fixed time-window optimisation and multi-worker/vehicle VRP.

## Verification
- TypeScript: PASS
- CSV parser: PASS
- Invoice integrity: 11/11 PASS
- v0.4.0: 18/18 PASS
- v0.4.1: 2/2 PASS
- v0.4.2: 8/8 PASS
- v0.5.0: 5/5 PASS
- v0.5.1: 4/4 PASS
- v0.5.2 managed-routing/pin tests: 4/4 PASS
- PC/web production export: PASS
- Android APK build: PASS
- Android AAB build: PASS
- APK signature: PASS
- AAB signature: PASS
- Android in-place upgrade/install: PASS
- Runtime metadata: v0.5.2 / versionCode 28
- Cleaner-facing Map screen smoke: PASS, shows ROUNDFLOW ROUTING / LOCAL MODE with no provider setup exposed

### Android SHA-256
- APK: `964D0EA61917FB2B065D572206CE9AAA0E6D9A288AE34BEF5014C1BE32C6019D`
- AAB: `08D4FC9BC645795762B4C4F0815E3DFFA802A0E973BA7CDFCD63540EE3981DE4`
- Signing certificate: `bab5e67dd732cf992c378ec9284d4632f52520995306af2fb8c40ca5e229b02e`

## Commercial note
The app-side work is complete for a Squeegee-style cleaner experience: provider setup is hidden, pins and route order are handled inside RoundFlow, and cleaners use routing without managing an account.

To turn live real-road pins/maps on for every commercial user, Wrekin Labs still needs one central Mapbox account/public token (or equivalent managed map provider). That is a one-time operator setup, not something each cleaner does.
