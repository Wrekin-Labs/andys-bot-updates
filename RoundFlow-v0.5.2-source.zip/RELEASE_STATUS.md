# RoundFlow 0.4.0 — verified Android release candidate

Verified on Andy Home on 5 October 2026.

## Identity

- Application ID: `uk.co.roundflow.app`
- Version: `0.4.0`
- Android versionCode: `23`
- Expo SDK: 57
- React Native: 0.86.3
- Release JDK: 17
- Existing RoundFlow signing path preserved

## Verification completed

- `npm run typecheck`: PASS, 0 TypeScript errors.
- `npm test`: PASS.
  - quoted/multiline CSV parser: PASS
  - original invoice/data-integrity regressions: 11/11
  - v0.4.0 regressions: 18/18
- Gradle produced the final release APK and AAB for 0.4.0/code 23.
- APK signature verification: PASS using Android APK Signature Scheme v2.
- AAB signature verification: PASS.
- APK signer certificate SHA-256:
  `bab5e67dd732cf992c378ec9284d4632f52520995306af2fb8c40ca5e229b02e`
- Dedicated API 35 QA emulator upgraded in place from installed RoundFlow 0.3.0/code 21 to 0.4.0/code 23 without clearing app data.
- Android invoice/upgrade flow: PASS 8/8.
  1. upgrade retains legacy invoice/balance
  2. decimal editing + £5 partial payment reconcile
  3. partial payment blocks completion undo
  4. duplicate updates customer balance
  5. payment reversal restores balance
  6. undo voids the completed visit invoice while preserving the duplicate
  7. recompletion receives the next invoice number
  8. restart preserves invoices and balances

Step 2 was independently verified on-screen after a transient Android `uiautomator dump` failure; the QA harness was then hardened with hierarchy retries. The remaining steps completed automatically. The harness was also updated for the taller v0.4 invoice editor, accessibility-label invoice rows and the preserved synthetic fixture date.

## Release artifacts

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `RoundFlow-0.4.0-release.apk` | 69,604,512 | `0654bf248ef2b4ea87214f1ecca9402eda6f5b6cbcb1291ebd0c2c898eeb1910` |
| `RoundFlow-0.4.0-release.aab` | 47,699,822 | `c8e7e649cc6ef14923cc9edf107a933938d9b7938c14191be0ed7037be4978a6` |

## Data / accounting status

The v0.4.0 migration preserves displayed balances by converting any legacy difference into an opening balance adjustment. Customer owing is then derived from the adjustment plus unpaid invoice balances.

Issued invoices are voided rather than deleted. Payment rows/reversals drive paid and outstanding values. Statements, reports and overdue status use the same ledger/date helpers.

The canonical core snapshot remains version 1 with additive revision 2 so the older 0.3.1 core decoder can still open jobs/invoices. A first migration writes `roundflow.core.pre-0.4.0` before changing the live snapshot.

## Supabase / cloud status

A new tenant-safe migration exists at:

`supabase/migrations/20261005120000_roundflow_v040_tenant_model.sql`

It is intended only for a new, dedicated RoundFlow Supabase project. It includes organisation membership, role guards, composite tenant foreign keys, RLS, append-only payments, invoice guards, audit events and sync metadata. Do not deploy it into an unrelated existing project.

Cloud sync is **not live** in this release. `lib/cloudSync.ts` still targets the superseded draft schema and must be rewritten before multi-device/team sync is enabled.

## Not yet verified / external gates

1. Physical Android phone pass for native PDF share, attachment persistence and SMS/email composer hand-off.
2. Dedicated RoundFlow Supabase project creation and deployment of the new migration.
3. Rewrite/test the client sync engine against the tenant model.
4. Invitation-email Edge Function.
5. Live Stripe/GoCardless/PayPal customer-payment sessions + signed webhooks.
6. App subscription billing / entitlement enforcement.
7. Automatic background SMS/email reminders and opt-out handling.
8. Hosted customer portal / secure invoice links.
9. Hosted privacy policy and terms; update Play Data Safety and store listing.
10. Google Play closed-track rollout of code 23.
11. iOS native build/testing.
12. GitHub remote/CI execution.

## Release decision

**Android local-first beta candidate: VERIFIED.**

Do not describe cloud sync, live payment collection, automatic reminders, subscriptions or hosted customer portal as live until their external-account/deployment work is completed.
