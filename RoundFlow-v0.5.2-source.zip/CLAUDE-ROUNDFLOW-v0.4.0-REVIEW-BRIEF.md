# RoundFlow v0.4.0 — Claude Engineering Review + Improvement Handoff

Date: 5 October 2026
Working branch: roundflow-v0.4.0-final
Known-good baseline: v0.3.1 / Android versionCode 22
Android package ID: uk.co.roundflow.app

## Mission
Review and improve RoundFlow as a commercial-grade offline-first field-service / round-management app. Preserve every currently working feature, existing user data, Android package identity and signing path. Do not fake cloud or payment functionality.

## Current proven baseline
v0.3.1 has passed TypeScript checks, CSV parser tests, invoice/data integrity regressions, Android assembleRelease and bundleRelease with JDK 17, APK signature verification, and an 8/8 Android invoice-flow test covering upgrade retention, decimal editing, partial payment, payment reversal, duplication, invoice numbering and restart persistence.

## Existing features that must remain
- Today/My Work round view
- 4-week calendar and multi-planner
- recurring jobs/custom frequencies
- pause/resume service
- route ordering, skip/unskip and Google Maps day route handoff
- customer search/filter/details/account history/archive/restore
- click-to-call and SMS composer
- quotes/estimates, quote PDF share, accepted quote -> recurring job
- invoice edit/preview/history and multi-line items
- discounts, tax, deposits, partial payments, mark paid and payment reversal
- invoice duplication
- PDF invoice sharing
- customer PDF statements
- SMS invoice reminder composer
- attachments and payment schedules
- review-request SMS composer
- expenses and business reports
- bulk price updates
- UK VAT/CIS settings
- local users/roles
- backup/restore and CSV import/export
- local persistence
- water-fill ledger and Spotless station finder
- draft Supabase auth/schema/sync code
- Android release build/signing setup

## Known gaps
The current app works locally. These are not genuinely live yet:
- dedicated RoundFlow Supabase production backend
- real multi-device/team sync and invitations
- Stripe/GoCardless/PayPal customer collection
- secure customer portal/payment links
- automatic background SMS/email reminders
- SaaS subscription billing
- advanced route optimisation
- iOS release verification
- store publication

## Priority improvements
1. Full code/architecture/security review.
2. Find correctness bugs, race conditions, stale-state bugs and data-loss risks.
3. Preserve offline-first behaviour and improve recovery/error handling.
4. Strengthen invoice/payment/quote accounting integrity.
5. Add a central business/payment profile with:
   business/trading name, owner/contact name, address, phone, email, VAT number,
   bank account name, sort code, account number, optional payment URL, default payment terms/footer.
   Flow these automatically into invoice PDFs/statements/payment requests.
6. Improve quotes: expiry, statuses, accepted quote -> job and/or invoice without duplicate accounting.
7. Improve overdue invoice UX: due/overdue status, days overdue, filters, reminder templates, manual SMS/email composer handoff, reminder history.
8. Improve reports: paid/outstanding/overdue, income by month, expenses/net, balances, useful round/worker metrics.
9. Fix customer statements to show invoice total, paid, balance and running outstanding.
10. Review VAT/CIS behaviour for sensible UK use. Do not claim tax/accounting compliance.
11. Improve route workflow while retaining current Google Maps fallback and avoiding unnecessary paid APIs.
12. Improve accessibility, small-screen layout, keyboard handling and Android safe-area/status-bar behaviour.
13. Strengthen backup/restore migration/versioning and tests.
14. Review Supabase draft schema/RLS for tenant isolation and secure role handling.
15. Review Android permissions/dependencies/security.
16. Add high-value regression tests and CI improvements.
17. Keep package ID uk.co.roundflow.app and existing signing path.
18. Target v0.4.0 / versionCode 23 only after changes pass verification.
19. Prefer maintainable incremental changes over a rewrite.

## Payments
Current Cash / Bank transfer / Card / GoCardless entries are bookkeeping only.
For real collection, design provider adapters with server-side session creation, no client secrets,
webhook verification, idempotency and invoice reconciliation.
Keep app subscription billing separate from customer invoice collection.
If credentials are absent, implement clean interfaces/test seams and document the remaining setup rather than pretending it is live.

## Supabase/cloud
Existing files are drafts. Do not silently use an unrelated Supabase project.
Propose a dedicated tenant-safe design for organisations, memberships/roles, customers, jobs, invoices,
invoice items, payments, quotes, expenses, reminders, water fills, audit events and sync metadata/versioning.
Every exposed table must have RLS and tenant isolation. Never put service-role secrets in the client.

## Required verification
- npm run typecheck
- npm test
- add tests for any new accounting/data-integrity logic
- run Android release build if environment permits
- preserve upgrade/data compatibility from v0.3.1
- do not remove features just to make tests pass
- report anything not verified

## Return to ChatGPT
Return:
1. Improved source ZIP or patch set.
2. CLAUDE-ROUNDFLOW-REVIEW.md with Critical/High/Medium/Low findings.
3. CLAUDE-ROUNDFLOW-CHANGES.md with every material change.
4. CLAUDE-ROUNDFLOW-TESTS.md with commands and actual results.
5. CLAUDE-ROUNDFLOW-NEXT.md listing only genuine external-account/deployment work.
6. Any SQL migrations separately.
7. A short list of files ChatGPT should inspect first.

## Hard constraints
- Preserve existing data/migrations and working features.
- Preserve package ID and signing path.
- Never include/request private signing keys.
- No secret keys in source.
- No fake cloud/payment functionality.
- No destructive data reset.
- Explain breaking schema/data changes.
