# RoundFlow v0.4.0 — Material changes

> Post-review update (5 Oct 2026): Andy Home verification is complete and the release is now version 0.4.0 / code 23. See `RELEASE_STATUS.md` for the current verified status. The Claude handoff notes below are retained as review history.

Version numbers are **not** bumped (still 0.3.1 / code 22) because the Android build could not be verified here. After verification run `node scripts/bump_version.mjs 0.4.0 23`.

## Data model (backward- and downgrade-compatible)
- Core snapshot keeps `version: 1` and adds `revision: 2`, so v0.3.1 can still open v0.4.0 data. Newer revisions are refused with a clear message.
- First load of v0.3.x data writes an untouched copy to `roundflow.core.pre-0.4.0` before migrating.
- Additive fields: `Job.balanceAdjustment`, `Job.balanceLog`, `Job.quoteId`; `Invoice.issuedISO`, `voided`, `reminders`, `quoteId`; `Payment.atISO`, `providerRef`.
- Customer balance is derived (see review H1). The migration preserves every balance exactly.
- Backups keep `version: 1` (+ `revision: 2`, `appVersion`, optional `raw`), so v0.3.1 can restore them.
- **Breaking-ish:** undo now voids rather than deletes; void invoices are hidden from Money → All (see the Void filter).

## New libraries (pure, unit-tested)
`lib/ledger.ts` (derived balances, migration, void, payments, invoice state) · `lib/dates.ts` · `lib/profile.ts` · `lib/statement.ts` · `lib/reports.ts` · `lib/quotes.ts` · `lib/reminders.ts` · `lib/routes.ts` · `lib/backup.ts` · `lib/payments.ts` (provider seam + idempotent reconciliation, **no provider calls**) · `lib/types.ts` · `lib/version.ts`.

## Features
- **Business & payment profile** (More): trading name, contact, phone, email, address, VAT number/default rate, bank account name, sort code, account number, optional payment link, payment terms, invoice footer. Validated; flows into invoice PDFs, statements, quotes, reminders and default due dates.
- **Invoices:** status chips (Paid / Due today / Overdue N days / Owing / Void), filters with counts, overdue total, validated due dates, manual void with confirmation, "Share payment link" (your own link only), payment instructions from profile.
- **New invoice** button on Money (pick a customer) and in the customer Finance tab.
- **Reminders:** three templates (friendly / overdue / final) with payment details, SMS or email composer hand-off, reminder history per invoice and per customer.
- **Quotes:** Q-numbers, validity/expiry, extend, statuses, PDF with business details, accepted → recurring job and/or invoice, each once only; converted quotes locked.
- **Reports / Insights:** received (cash basis), invoiced, expenses, net, 6-month chart, aged debt, highest balances, workers, monthly round value; PDF report. On Money → Insights and Business hub → Reports.
- **Statements:** date-ordered rows with total, paid, balance and running outstanding, opening balances, bank details.
- **Routes:** multi-leg Google Maps hand-off; "Order by area" (postcode/area grouping, offline, not optimisation).
- **Expenses:** date field, category chips, delete.
- **CSV:** formula-injection guard, frequency mapping, extra columns (service, worker, next visit, status), BOM for Excel.

## UI redesign (patterns from Squeegee + Invoice Simple, RoundFlow's own look)
- Shared design kit `components/ui.tsx`: colour tokens, initials avatars, status chips, segmented control, stat cards, dependency-free bar chart, empty states, floating action button.
- **Customers:** avatar list with address, frequency/area/next-visit chips, balance on the right, red "OWED (N DAYS)" chip; sort A–Z / most owed / next visit.
- **Customer screen:** teal header with balance; tabs **Customer · Finance · Messages**. Finance = account timeline with running balance and quick actions; Messages = call/text/email, reminder composer, message log.
- **Money:** Invoices | Insights. Invoice rows with avatar, status chip, last reminder.
- **Invoice editor:** balance summary header with status chip, "How to pay" from profile, reminder card, history timeline.
- Accessibility: roles/labels/selected state on controls, larger touch targets (≥36–44px), `keyboardShouldPersistTaps`, contrast nudges.
- Existing QA labels kept (`COMPLETE`, `Undo`, `Invoice actions`, `Duplicate`, `Back to invoices`, `Item rate`, `Payment amount`, `Record payment`, `Reverse recorded payment`, `Mark paid`, …).

## Supabase
- New `supabase/migrations/20261005120000_roundflow_v040_tenant_model.sql` (organisations, memberships, invitations, subscriptions, business profiles, customers, jobs, quotes, invoices, items, payments, expenses, reminders, water fills, audit events; RLS on all; composite tenant FKs; role guards; sync metadata; RPCs `create_organization`, `accept_invitation`).
- `supabase/tests/` — auth stub, 34-check RLS suite, local runner. Old `supabase-schema.sql` marked superseded.
- `lib/cloudSync.ts` / `CloudAccount.tsx` unchanged (still drafts against the old schema; not wired to data).

## Tooling
- `npm test` now also runs `scripts/test_v040.cjs` (18 tests). Shared `scripts/lib_loader.cjs`.
- CI: new `database` job runs the migration + RLS suite on PostgreSQL 16; non-blocking `npm audit`.
- `scripts/bump_version.mjs` updates package.json, app.json, build.gradle and lib/version.ts together.
