# RoundFlow v0.5.1 — Routing Setup, Bulk Geocoding & ETA Schedule

Date: 5 October 2026
Package: `uk.co.roundflow.app`
Android versionCode: 27

## Added in v0.5.1

### In-app routing setup
- New **More → Settings → Routing Setup** card.
- Enter a Mapbox public token directly in RoundFlow; no rebuild is required.
- Test the token against a real Telford geocoding request.
- Public tokens are stored locally as app settings; the UI explicitly warns not to paste secret/server tokens.
- Optional advanced routing-service URL can be saved for future larger/time-window/multi-worker routing.

### Bulk customer geocoding
- Shows located vs unpinned active customers.
- One action can geocode all active unpinned customers after a usage/billing confirmation.
- Saved coordinates include provider label and timestamp.
- Existing offline/local planner still works when Mapbox is not configured.

### Real stop schedule
- Live Directions/Optimization responses now retain per-leg road distance/time.
- Day Pilot can show each stop’s actual drive minutes and ETA from the configured route start time.
- Fixed appointment windows are shown in the schedule.
- With **Ignore time OFF**, ETA preview waits until a window opens and flags stops that are already past the window end.
- If worker default start/end addresses are active, the final road leg back to the route-end address is shown.

### Safer route-start time
- Default route-start time can be edited in Settings and in Day Pilot.
- Editing uses a local draft and only commits valid 24-hour time.
- Invalid values are rejected instead of corrupting the saved route start time.

### Start Furthest hardening
- Uses Mapbox `driving-traffic` Matrix API.
- Traffic-matrix lookups are batched at 9 candidates + 1 source to stay within the current 10-coordinate traffic-profile limit.
- Larger worker days therefore remain supported without inventing distance or using straight-line shortcuts.

### Feature wording
- Feature Hub now accurately states that live Mapbox road optimisation/map/distance/ETA work when configured.
- Advanced backend is reserved for >12-point optimisation, fixed time-window optimisation, and multi-worker/vehicle VRP.

## Verification

- TypeScript: PASS
- CSV parser: PASS
- Invoice integrity: 11/11 PASS
- v0.4.0 suite: 18/18 PASS
- v0.4.1 suite: 2/2 PASS
- v0.4.2 suite: 8/8 PASS
- v0.5.0 suite: 5/5 PASS
- v0.5.1 suite: 4/4 PASS
- PC/web production export: PASS
- Android APK build/signature: PASS
- Android AAB build/signature: PASS
- Android in-place install/launch smoke: PASS
- Routing Setup UI smoke: PASS
- Map screen safe SETUP state with no token: PASS
- Runtime metadata: v0.5.1 / versionCode 27

### Final Android SHA-256
- APK: `F306018BA13EC0F04FA8CF4DA8EC11C695763EEA3560FB076321C8316E24F8FA`
- AAB: `2BA3852083EEDF238AE4A31EB8F824785BAAF01088336C824AB0D7D93E3DA231`
- Signing certificate SHA-256: `bab5e67dd732cf992c378ec9284d4632f52520995306af2fb8c40ca5e229b02e`

## Dependency note
The existing Expo/Metro dependency audit warnings remain unchanged from v0.5.0. No breaking forced downgrade was applied.

## External/commercial items still required
- A real Mapbox public token/account to turn on live geographic routing for production users.
- Dedicated production RoundFlow Supabase and multi-device sync.
- Advanced routing backend for >12-point optimisation, fixed appointment-window optimisation, and multi-worker/vehicle planning.
- Provider-backed customer payments, RoundFlow SaaS billing, automatic SMS/email, customer portal and store rollout.
