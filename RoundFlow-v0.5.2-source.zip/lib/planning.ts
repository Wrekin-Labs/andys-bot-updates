import type {Job,TeamUser} from './types';

const norm=(v:string)=>v.trim().toLowerCase();

export function workerForJob(job:Job,users:TeamUser[]){
 const target=norm(job.worker||'');
 if(target)return users.find(u=>u.active&&norm(u.name)===target);
 return users.find(u=>u.active&&u.roles.includes('Owner'))||users.find(u=>u.active);
}

export function missingSkills(job:Job,users:TeamUser[]){
 const required=(job.requiredSkills||[]).map(norm).filter(Boolean);
 if(!required.length)return[] as string[];
 const worker=workerForJob(job,users);
 if(!worker)return [...(job.requiredSkills||[])];
 const have=new Set((worker.skills||[]).map(norm));
 return (job.requiredSkills||[]).filter(s=>!have.has(norm(s)));
}

export function totalDailyCapacity(users:TeamUser[],fallback=480){
 const active=users.filter(u=>u.active);
 if(!active.length)return fallback;
 const sum=active.reduce((n,u)=>n+(Number.isFinite(u.dailyCapacityMin)?Math.max(0,u.dailyCapacityMin||0):480),0);
 return sum>0?sum:fallback;
}

export function plannedMinutes(jobs:Job[]){
 return jobs.filter(j=>!j.archived&&!j.paused&&!j.skipped).reduce((n,j)=>n+(Number.isFinite(j.durationMin)?Math.max(0,j.durationMin||0):30),0);
}

export function capacityPercent(jobs:Job[],users:TeamUser[],fallback=480){
 const cap=totalDailyCapacity(users,fallback);
 return cap?Math.round(plannedMinutes(jobs)*100/cap):0;
}

export function capacityLabel(percent:number){
 if(percent>115)return'Over capacity';
 if(percent>95)return'Nearly full';
 if(percent>=70)return'Healthy';
 return'Available';
}

export type DayPilotStatus='notdone'|'completed'|'all';
export type RoutePlanMode='manual'|'area';

export function filterDayPilot(jobs:Job[],status:DayPilotStatus){
 if(status==='completed')return jobs.filter(j=>j.done);
 if(status==='notdone')return jobs.filter(j=>!j.done);
 return [...jobs];
}

export function routePlan(jobs:Job[],mode:RoutePlanMode,startId?:string|null,endId?:string|null){
 const indexed=jobs.map((job,index)=>({job,index}));
 const ordered=mode==='area'
  ?indexed.sort((a,b)=>norm(a.job.area||'').localeCompare(norm(b.job.area||''))||norm(a.job.address||'').localeCompare(norm(b.job.address||''))||a.index-b.index).map(x=>x.job)
  :indexed.map(x=>x.job);
 const start=startId?ordered.find(j=>j.id===startId):undefined;
 const end=endId&&endId!==startId?ordered.find(j=>j.id===endId):undefined;
 const middle=ordered.filter(j=>j.id!==start?.id&&j.id!==end?.id);
 return [...(start?[start]:[]),...middle,...(end?[end]:[])];
}

export function areaSummary(jobs:Job[]){
 const map=new Map<string,number>();
 for(const j of jobs){const key=j.area.trim()||'Unassigned';map.set(key,(map.get(key)||0)+1);}
 return [...map.entries()].map(([area,count])=>({area,count})).sort((a,b)=>b.count-a.count||a.area.localeCompare(b.area));
}
