export type InvoiceMoney = {
  amount: number;
  status: 'paid' | 'owing';
  items?: {description: string; qty: number; rate: number}[];
  discount?: number;
  taxRate?: number;
  paidAmount?: number;
  voided?: unknown;
};

export const roundMoney = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
const nonNegative = (value: number | undefined) => Number.isFinite(value) ? Math.max(0, value!) : 0;

export function invoiceAmounts(invoice: InvoiceMoney) {
  const subtotal = roundMoney(invoice.items?.length
    ? invoice.items.reduce((sum, item) => sum + roundMoney(nonNegative(item.qty) * nonNegative(item.rate)), 0)
    : nonNegative(invoice.amount));
  const discount = Math.min(subtotal, roundMoney(nonNegative(invoice.discount)));
  const taxable = roundMoney(subtotal - discount);
  const tax = roundMoney(taxable * nonNegative(invoice.taxRate) / 100);
  const total = roundMoney(taxable + tax);
  const paid = roundMoney(nonNegative(invoice.paidAmount ?? (invoice.status === 'paid' ? total : 0)));
  return {subtotal, discount, tax, total, paid, balance: roundMoney(Math.max(0, total - paid)), credit: roundMoney(Math.max(0, paid - total))};
}

export const invoiceTotal = (invoice: InvoiceMoney) => invoiceAmounts(invoice).total;
export const invoicePaid = (invoice: InvoiceMoney) => invoiceAmounts(invoice).paid;
export const invoiceBalance = (invoice: InvoiceMoney) => invoiceAmounts(invoice).balance;

export function validateInvoiceEdit(previous: InvoiceMoney, next: InvoiceMoney) {
  if (previous.voided) throw new Error('A void invoice cannot be edited. Duplicate it to issue a corrected invoice.');
  const values = [next.amount, next.discount ?? 0, next.taxRate ?? 0, ...(next.items ?? []).flatMap(i => [i.qty, i.rate])];
  if (values.some(n => !Number.isFinite(n) || n < 0)) throw new Error('Use valid, non-negative amounts.');
  const paid = invoicePaid(previous);
  if (invoiceTotal(next) < paid) throw new Error('The invoice total cannot be less than its recorded payments. Reverse the payment before reducing this total.');
  return {...next, paidAmount: paid, status: (paid >= invoiceTotal(next) ? 'paid' : 'owing') as 'paid' | 'owing'};
}

export function paymentAllocation(invoice: InvoiceMoney, requested: number) {
  if (!Number.isFinite(requested) || requested <= 0) throw new Error('Enter a valid payment greater than £0.');
  const amount = roundMoney(Math.min(requested, invoiceBalance(invoice)));
  if (amount <= 0) throw new Error('There is no unpaid balance to record.');
  const paidAmount = roundMoney(invoicePaid(invoice) + amount);
  return {amount, paidAmount, status: (paidAmount >= invoiceTotal(invoice) ? 'paid' : 'owing') as 'paid' | 'owing'};
}

export function numberInvoices<T extends {invoiceNo?: number}>(invoices: T[], lastIssued = 0) {
  let last = Math.max(0, Number.isSafeInteger(lastIssued) ? lastIssued : 0,
    ...invoices.map(i => Number.isSafeInteger(i.invoiceNo) && i.invoiceNo! > 0 ? i.invoiceNo! : 0));
  const used = new Set<number>();
  const numbered = [...invoices].reverse().map(invoice => {
    let no = invoice.invoiceNo;
    if (!Number.isSafeInteger(no) || no! <= 0 || used.has(no!)) no = ++last;
    used.add(no!);
    return {...invoice, invoiceNo: no!};
  }).reverse();
  return {invoices: numbered, lastInvoiceNo: last};
}

export const localDateISO = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
