import {invoicePaid, roundMoney} from './invoiceMath';
import {recordPayment, stamp, newId} from './ledger';
import type {Invoice} from './types';

/**
 * Customer payment collection seam. NOTHING HERE TALKS TO A PROVIDER.
 *
 * Real collection (Stripe / GoCardless / PayPal) must create checkout sessions on a
 * server (e.g. a Supabase Edge Function holding the secret key), verify provider
 * webhooks there, and write payments idempotently. The app only ever receives a
 * hosted payment URL and reconciled payment events. See CLAUDE-ROUNDFLOW-NEXT.md.
 * App subscription billing is a separate concern and must not share this code path.
 */
export type PaymentLinkRequest = {invoiceId: string; invoiceRef: string; amountPence: number; currency: 'GBP'; description: string};
export interface PaymentProvider {
  readonly id: string;
  readonly label: string;
  isConfigured(): boolean;
  createPaymentLink(req: PaymentLinkRequest): Promise<{url: string; providerRef: string}>;
}

export const notConfiguredProvider: PaymentProvider = {
  id: 'none',
  label: 'Online payments not connected',
  isConfigured: () => false,
  createPaymentLink: async () => { throw new Error('Online card/direct-debit collection is not connected in this build.'); },
};

export type ProviderPaymentEvent = {
  provider: string;
  /** Unique, provider-issued id for this payment or refund (webhook event id is not enough if retried with new ids). */
  providerRef: string;
  kind: 'payment' | 'refund';
  amountPence: number;
  currency: string;
  occurredAt: Date;
};

/**
 * Applies a verified provider event to an invoice exactly once.
 * Returns {applied:false} for duplicates so webhook retries are harmless.
 */
export function applyProviderEvent(inv: Invoice, ev: ProviderPaymentEvent): {invoice: Invoice; applied: boolean; note?: string} {
  const ref = ev.provider + ':' + ev.providerRef;
  if ((inv.payments || []).some(p => p.providerRef === ref)) return {invoice: inv, applied: false, note: 'duplicate'};
  if (ev.currency.toUpperCase() !== 'GBP') throw new Error('Only GBP payments can be reconciled.');
  if (!Number.isSafeInteger(ev.amountPence) || ev.amountPence <= 0) throw new Error('Invalid provider amount.');
  const amount = roundMoney(ev.amountPence / 100);
  if (ev.kind === 'payment') {
    const next = recordPayment(inv, amount, ev.provider, ev.occurredAt, ref);
    const credited = next.payments![next.payments!.length - 1].amount;
    return {invoice: next, applied: true, note: credited < amount ? `overpayment of £${(amount - credited).toFixed(2)} needs manual refund/credit` : undefined};
  }
  const paid = invoicePaid(inv);
  const refund = roundMoney(Math.min(amount, paid));
  if (refund <= 0) throw new Error('Refund exceeds recorded payments.');
  const s = stamp(ev.occurredAt);
  const paidAmount = roundMoney(paid - refund);
  return {
    applied: true,
    invoice: {
      ...inv, paidAmount, status: 'owing',
      payments: [...(inv.payments || []), {id: newId('r'), date: s.at, atISO: s.atISO, amount: -refund, method: ev.provider + ' refund', providerRef: ref}],
      history: [...(inv.history || []), {at: s.at, label: `£${refund.toFixed(2)} refunded via ${ev.provider}`}],
    },
  };
}
