import {decodeCore, loadCore, encodeCore} from './coreState';
import {normalizeProfile} from './profile';

export const BACKUP_KEYS = ['roundflow.core','roundflow.jobs','roundflow.invoices','roundflow.rounds','roundflow.quotes','roundflow.expenses','roundflow.templates','roundflow.profile','roundflow.users','roundflow.waterFills'] as const;
const LIST_KEYS = ['roundflow.rounds','roundflow.quotes','roundflow.expenses','roundflow.templates','roundflow.users','roundflow.waterFills'];
export const BACKUP_FORMAT = 'roundflow-backup';
/** `version` stays 1 so v0.3.1 can restore v0.4.0 backups; `revision` tracks the additive changes. */
export const BACKUP_VERSION = 1;
export const BACKUP_REVISION = 2;

/**
 * Builds a backup from raw AsyncStorage pairs. Unlike v0.3.1, a corrupt section no longer
 * aborts the whole export: it is preserved verbatim under `raw` so it can be recovered by hand.
 */
export function buildBackup(pairs: readonly (readonly [string, string | null])[], meta: {appVersion: string; now?: Date}) {
  const data: Record<string, unknown> = {};
  const raw: Record<string, string> = {};
  const warnings: string[] = [];
  for (const [k, v] of pairs) {
    if (v == null) { data[k] = null; continue; }
    try { data[k] = JSON.parse(v); } catch { raw[k] = v; data[k] = null; warnings.push(k); }
  }
  if (data['roundflow.core']) {
    try {
      const core = decodeCore(JSON.stringify(data['roundflow.core']));
      // Mirror into the legacy keys so v0.3.0-style restores still work.
      data['roundflow.jobs'] = core.jobs; data['roundflow.invoices'] = core.invoices;
    } catch (e: any) {
      raw['roundflow.core'] = JSON.stringify(data['roundflow.core']); data['roundflow.core'] = null; warnings.push('roundflow.core (' + (e?.message || 'invalid') + ')');
    }
  }
  const payload = {format: BACKUP_FORMAT, version: BACKUP_VERSION, revision: BACKUP_REVISION, appVersion: meta.appVersion, createdAt: (meta.now || new Date()).toISOString(), data, ...(Object.keys(raw).length ? {raw} : {})};
  return {json: JSON.stringify(payload, null, 2), warnings};
}

export type RestorePlan = {ops: [string, string][]; summary: {customers: number; invoices: number; sections: number}; warnings: string[]};

/** Validates a backup file completely before anything is written. Throws on anything unsafe. */
export function planRestore(text: string): RestorePlan {
  let parsed: any;
  try { parsed = JSON.parse(text.replace(/^﻿/, '')); } catch { throw new Error('This file is not valid JSON.'); }
  if (parsed?.format !== BACKUP_FORMAT || parsed?.version !== BACKUP_VERSION || !parsed?.data || typeof parsed.data !== 'object') throw new Error('This is not a valid RoundFlow backup');
  if (typeof parsed.revision === 'number' && parsed.revision > BACKUP_REVISION) throw new Error('This backup was made by a newer RoundFlow version. Update the app first.');
  const d = parsed.data;
  const core = d['roundflow.core'] ? decodeCore(JSON.stringify(d['roundflow.core'])) : (d['roundflow.jobs'] || d['roundflow.invoices'] ? loadCore(d['roundflow.jobs'] || [], d['roundflow.invoices'] || []) : null);
  const ops: [string, string][] = [];
  const warnings: string[] = [];
  if (core) ops.push(['roundflow.core', encodeCore(core.jobs, core.invoices, core.lastInvoiceNo)]);
  for (const key of LIST_KEYS) {
    const v = d[key];
    if (v == null) continue;
    if (!Array.isArray(v)) throw new Error('Invalid backup section: ' + key);
    ops.push([key, JSON.stringify(v)]);
  }
  if (d['roundflow.profile'] != null) {
    if (typeof d['roundflow.profile'] !== 'object' || Array.isArray(d['roundflow.profile'])) throw new Error('Invalid backup section: roundflow.profile');
    ops.push(['roundflow.profile', JSON.stringify(normalizeProfile(d['roundflow.profile']))]);
  }
  if (parsed.raw && typeof parsed.raw === 'object') warnings.push('Some sections were unreadable when this backup was made and will not be restored: ' + Object.keys(parsed.raw).join(', '));
  if (!ops.length) throw new Error('Backup contains no recognised RoundFlow data');
  return {ops, summary: {customers: core?.jobs.length || 0, invoices: core?.invoices.length || 0, sections: ops.length}, warnings};
}
