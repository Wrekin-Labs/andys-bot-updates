import {invoiceBalance} from './invoiceMath';
import {invoiceState, stamp} from './ledger';
import {displayDate, isISODate} from './dates';
import {invoiceRef} from './invoiceHtml';
import {displayBusinessName, normalizeProfile, paymentDetailsLines} from './profile';
import type {Invoice, Job} from './types';

export type ReminderTemplate = {id: string; name: string; text: string};

/** Tokens: {name} {invoice} {balance} {due} {days} {business} {payment} */
export const REMINDER_TEMPLATES: ReminderTemplate[] = [
  {id: 'friendly', name: 'Friendly reminder', text: 'Hi {name}, a quick reminder that invoice {invoice} for {balance} is due {due}.{payment} Thank you, {business}'},
  {id: 'overdue', name: 'Overdue', text: 'Hi {name}, invoice {invoice} for {balance} is now {days} days overdue (due {due}). Please could you arrange payment.{payment} Thank you, {business}'},
  {id: 'final', name: 'Final notice', text: 'Hi {name}, invoice {invoice} for {balance} remains unpaid {days} days after the due date. Please pay within 7 days or contact us to discuss.{payment} {business}'},
];

export function suggestedTemplate(inv: Invoice, today: string) {
  const s = invoiceState(inv, today);
  if (s.state !== 'overdue') return REMINDER_TEMPLATES[0];
  return s.daysOverdue > 30 ? REMINDER_TEMPLATES[2] : REMINDER_TEMPLATES[1];
}

export function fillReminder(template: ReminderTemplate, inv: Invoice, job: Pick<Job, 'name'> | undefined, profileRaw: unknown, today: string) {
  const p = normalizeProfile(profileRaw);
  const s = invoiceState(inv, today);
  const pay = paymentDetailsLines(p, invoiceRef(inv.invoiceNo));
  const values: Record<string, string> = {
    name: job?.name || inv.customer,
    invoice: invoiceRef(inv.invoiceNo),
    balance: '£' + invoiceBalance(inv).toFixed(2),
    due: isISODate(inv.dueDate) ? displayDate(inv.dueDate) : 'on receipt',
    days: String(s.daysOverdue),
    business: displayBusinessName(p),
    payment: pay.length ? ' ' + pay.join(', ') + '.' : '',
  };
  return template.text.replace(/\{(\w+)\}/g, (m, k) => (k in values ? values[k] : m));
}

export const smsHref = (phone: string, body: string) => 'sms:' + phone.replace(/[^\d+]/g, '') + '?body=' + encodeURIComponent(body);
export const mailtoHref = (email: string, subject: string, body: string) =>
  'mailto:' + encodeURIComponent(email.trim()) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);

/** Records that the device composer was opened. RoundFlow cannot confirm the message was actually sent. */
export function logReminder(inv: Invoice, channel: 'sms' | 'email', template: ReminderTemplate, now = new Date()): Invoice {
  const s = stamp(now);
  return {
    ...inv,
    reminders: [...(inv.reminders || []), {...s, channel, template: template.name}],
    history: [...(inv.history || []), {at: s.at, label: `Reminder composer opened (${channel.toUpperCase()} · ${template.name})`}],
  };
}

export const lastReminder = (inv: Invoice) => inv.reminders?.length ? inv.reminders[inv.reminders.length - 1] : undefined;
