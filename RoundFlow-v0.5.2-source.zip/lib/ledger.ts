import {invoiceAmounts, invoiceBalance, invoicePaid, paymentAllocation, roundMoney, localDateISO} from './invoiceMath';
import {daysBetween, isISODate, parseLegacyDate} from './dates';
import type {BalanceLogEntry, Invoice, Job, Payment} from './types';

/** Current core data shape revision. Stored alongside `version: 1` so v0.3.1 can still read it. */
export const CORE_REVISION = 2;

export const stamp = (now = new Date()) => ({at: now.toLocaleString('en-GB'), atISO: localDateISO(now)});
export const newId = (prefix: string) => prefix + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);

const invoiceBalancesByJob = (invoices: Invoice[]) => {
  const map = new Map<string, number>();
  for (const inv of invoices) map.set(inv.jobId, roundMoney((map.get(inv.jobId) || 0) + invoiceBalance(inv)));
  return map;
};

/**
 * Customer balance is derived, never edited directly:
 *   owing = max(0, balanceAdjustment + sum(unpaid invoice balances))
 * This removes the v0.3.x risk of `owing` drifting away from invoices.
 */
export function reconcileBalances<J extends Job>(jobs: J[], invoices: Invoice[]): J[] {
  const balances = invoiceBalancesByJob(invoices);
  let changed = false;
  const next = jobs.map(j => {
    const owing = roundMoney(Math.max(0, (j.balanceAdjustment || 0) + (balances.get(j.id) || 0)));
    if (owing === j.owing) return j;
    changed = true;
    return {...j, owing};
  });
  return changed ? next : jobs;
}

/**
 * One-time v0.3.1 -> v0.4.0 migration. Preserves every displayed balance exactly by
 * recording the difference between the stored `owing` and the invoice balances as
 * `balanceAdjustment` (opening balances from CSV import or demo data).
 */
export function migrateCore(jobs: Job[], invoices: Invoice[], revision: number | undefined) {
  if ((revision || 1) >= CORE_REVISION) return {jobs, invoices, migrated: false};
  const balances = invoiceBalancesByJob(invoices);
  const migratedJobs = jobs.map(j => j.balanceAdjustment !== undefined ? j : {...j, balanceAdjustment: roundMoney(j.owing - (balances.get(j.id) || 0))});
  const migratedInvoices = invoices.map(inv => ({
    ...inv,
    issuedISO: inv.issuedISO || parseLegacyDate(inv.date),
    payments: inv.payments?.map(p => p.atISO ? p : {...p, atISO: parseLegacyDate(p.date)}),
  }));
  return {jobs: migratedJobs, invoices: migratedInvoices, migrated: true};
}

export type InvoiceState = 'void' | 'paid' | 'overdue' | 'due' | 'owing';

export function invoiceState(inv: Invoice, today: string): {state: InvoiceState; daysOverdue: number} {
  if (inv.voided) return {state: 'void', daysOverdue: 0};
  if (invoiceBalance(inv) <= 0) return {state: 'paid', daysOverdue: 0};
  if (!isISODate(inv.dueDate)) return {state: 'owing', daysOverdue: 0};
  const days = daysBetween(inv.dueDate, today);
  if (days > 0) return {state: 'overdue', daysOverdue: days};
  if (days === 0) return {state: 'due', daysOverdue: 0};
  return {state: 'owing', daysOverdue: 0};
}

export const invoiceStateLabel = (s: {state: InvoiceState; daysOverdue: number}) =>
  s.state === 'overdue' ? `Overdue ${s.daysOverdue} day${s.daysOverdue === 1 ? '' : 's'}`
    : s.state === 'due' ? 'Due today'
    : s.state === 'void' ? 'Void'
    : s.state === 'paid' ? 'Paid' : 'Owing';

/**
 * Voids an issued invoice instead of deleting it, so the invoice number is never
 * silently lost. Amounts are zeroed (v0.3.1 therefore also reads it as £0) and the
 * original figures are kept in `voided.original`.
 */
export function voidInvoice(inv: Invoice, reason: string, now = new Date()): Invoice {
  if (inv.voided) throw new Error('This invoice is already void.');
  if (invoicePaid(inv) > 0) throw new Error('This invoice has recorded payments. Reverse the payment first.');
  const s = stamp(now);
  return {
    ...inv,
    amount: 0, items: undefined, discount: 0, taxRate: 0, deposit: 0,
    status: 'paid', paidAmount: 0,
    voided: {...s, reason, original: {amount: inv.amount, items: inv.items, discount: inv.discount, taxRate: inv.taxRate}},
    history: [...(inv.history || []), {at: s.at, label: 'Voided · ' + reason}],
  };
}

export function recordPayment(inv: Invoice, requested: number, method: string, now = new Date(), providerRef?: string): Invoice {
  if (inv.voided) throw new Error('Payments cannot be recorded on a void invoice.');
  const p = paymentAllocation(inv, requested);
  const s = stamp(now);
  const payment: Payment = {id: newId('p'), date: s.at, atISO: s.atISO, amount: p.amount, method: method || 'Payment', ...(providerRef ? {providerRef} : {})};
  return {
    ...inv, paidAmount: p.paidAmount, status: p.status,
    payments: [...(inv.payments || []), payment],
    history: [...(inv.history || []), {at: s.at, label: '£' + p.amount.toFixed(2) + ' payment recorded · ' + payment.method}],
  };
}

export function settleInvoice(inv: Invoice, now = new Date()): Invoice {
  const remaining = invoiceBalance(inv);
  if (inv.voided || remaining <= 0) return inv;
  return recordPayment(inv, remaining, 'Balance paid', now);
}

export function reversePayments(inv: Invoice, now = new Date()): Invoice {
  const restore = invoicePaid(inv);
  if (restore <= 0) return inv;
  const s = stamp(now);
  return {
    ...inv, status: 'owing', paidAmount: 0,
    payments: [...(inv.payments || []), {id: newId('r'), date: s.at, atISO: s.atISO, amount: -restore, method: 'Reversal'}],
    history: [...(inv.history || []), {at: s.at, label: 'Payment reversed'}],
  };
}

/** Clears a positive opening balance (not tied to any invoice) and records it as a payment. */
export function settleAdjustment(job: Job, now = new Date()): Job {
  const adj = job.balanceAdjustment || 0;
  if (adj <= 0) return job;
  const s = stamp(now);
  const entry: BalanceLogEntry = {...s, amount: -adj, label: 'Opening balance paid'};
  return {...job, balanceAdjustment: 0, balanceLog: [...(job.balanceLog || []), entry]};
}

export function invoiceIssuedISO(inv: Invoice) {
  return inv.issuedISO || parseLegacyDate(inv.date);
}

export {invoiceAmounts};
