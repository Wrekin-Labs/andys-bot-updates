import {invoiceAmounts, roundMoney} from './invoiceMath';
import type {InvoiceMoney} from './invoiceMath';
import {normalizeProfile, paymentDetailsLines, displayBusinessName} from './profile';
import {displayDate, isISODate} from './dates';

type PrintableInvoice = InvoiceMoney & {customer:string;invoiceNo?:number;date:string;dueDate?:string;notes?:string;paymentInfo?:string;paymentSchedule?:string;signatureName?:string;attachments?:{name:string}[];voided?:{reason:string;original:{amount:number}}};
type Customer = {name?:string;address?:string;area?:string;email?:string;service?:string};
export const esc = (value: unknown) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]!));
export const money = (value:number) => '£' + value.toFixed(2);
export const invoiceRef = (invoiceNo?: number) => 'RF-' + String(invoiceNo || 1).padStart(5, '0');

export const PDF_STYLE = 'body{font-family:Arial,Helvetica,sans-serif;padding:32px;color:#17342d}h1{color:#0b6b57;margin:0 0 6px}header{display:flex;justify-content:space-between;gap:24px}table{width:100%;border-collapse:collapse;margin:24px 0}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}.r{text-align:right}.balance{font-size:22px;font-weight:bold}.text{white-space:pre-wrap}.muted{color:#667873;font-size:12px}.void{border:3px solid #a12626;color:#a12626;padding:10px;font-weight:bold;text-align:center;margin:16px 0}footer{margin-top:28px;border-top:1px solid #ddd;padding-top:12px}';

/** Business header block shared by invoices, statements and quotes. */
export function businessHeader(profileRaw: unknown) {
  const p = normalizeProfile(profileRaw);
  const contact = [p.phone, p.email].filter(Boolean).map(esc).join(' · ');
  return `<div><h1>${esc(displayBusinessName(p))}</h1>${p.name ? `<div>${esc(p.name)}</div>` : ''}<div class="text">${esc(p.address)}</div>${contact ? `<div>${contact}</div>` : ''}${p.vat && p.vatNumber.trim() ? `<div>VAT No. ${esc(p.vatNumber.trim())}</div>` : ''}</div>`;
}

export function invoiceHtml(invoice: PrintableInvoice, customer: Customer = {}, profileRaw: unknown = {}) {
  const p = normalizeProfile(profileRaw);
  const a = invoiceAmounts(invoice);
  const ref = invoiceRef(invoice.invoiceNo);
  const items = invoice.items?.length ? invoice.items : [{description:customer.service || 'Window cleaning service',qty:1,rate:invoice.amount}];
  const rows = items.map(i => `<tr><td>${esc(i.description || 'Item')}</td><td class="r">${esc(i.qty)}</td><td class="r">${money(i.rate)}</td><td class="r">${money(roundMoney(i.qty * i.rate))}</td></tr>`).join('');
  const taxLabel = p.vat ? `VAT${invoice.taxRate ? ' @ ' + invoice.taxRate + '%' : ''}` : 'Tax';
  const due = invoice.dueDate ? (isISODate(invoice.dueDate) ? displayDate(invoice.dueDate) : invoice.dueDate) : 'On receipt';
  const payLines = invoice.paymentInfo?.trim() ? [invoice.paymentInfo.trim()] : paymentDetailsLines(p, ref);
  const extra: [string, string | undefined][] = [['How to pay', payLines.join('\n')],['Payment schedule',invoice.paymentSchedule],['Notes',invoice.notes],['Signed by',invoice.signatureName]];
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${PDF_STYLE}</style></head><body><header>${businessHeader(p)}<div class="r"><b>${p.vat ? 'VAT INVOICE' : 'INVOICE'} ${ref}</b><p>Issued ${esc(invoice.date)}<br>Due ${esc(due)}</p></div></header>${invoice.voided ? `<div class="void">VOID — this invoice has been cancelled (${esc(invoice.voided.reason)}). Nothing is payable.</div>` : ''}<h3>Bill to</h3><b>${esc(invoice.customer)}</b><div class="text">${esc(customer.address || customer.area)}</div>${esc(customer.email)}<table><tr><th>Description</th><th class="r">Qty</th><th class="r">Rate</th><th class="r">Amount</th></tr>${rows}</table><div class="r">Subtotal ${money(a.subtotal)}<br>Discount ${money(a.discount)}<br>${taxLabel} ${money(a.tax)}<br><b>Total ${money(a.total)}</b><br>Paid ${money(a.paid)}<p class="balance">Balance due ${money(a.balance)}</p>${a.credit ? `<p>Credit ${money(a.credit)}</p>` : ''}</div>${extra.filter(([,v])=>v && v.trim()).map(([k,v])=>`<p><b>${k}</b><br><span class="text">${esc(v)}</span></p>`).join('')}${invoice.attachments?.length ? `<p><b>Attachment references</b><br>${invoice.attachments.map(x=>esc(x.name)).join('<br>')}</p>` : ''}${p.invoiceFooter.trim() ? `<footer class="text muted">${esc(p.invoiceFooter)}</footer>` : ''}</body></html>`;
}
