export type RoutingSettings={
 mapboxToken:string;
 advancedRoutingUrl:string;
 defaultRouteStartTime:string;
};

export const DEFAULT_ROUTING_SETTINGS:RoutingSettings={
 mapboxToken:'',
 advancedRoutingUrl:'',
 defaultRouteStartTime:'08:00'
};

export function normalizeClock(v:string){const m=String(v||'').trim().match(/^(\d{1,2}):(\d{2})$/);if(!m)return null;const h=Number(m[1]),n=Number(m[2]);return h>=0&&h<24&&n>=0&&n<60?String(h).padStart(2,'0')+':'+String(n).padStart(2,'0'):null;}

export function normalizeRoutingSettings(v:any):RoutingSettings{
 const x=v&&typeof v==='object'?v:{};
 return{
  mapboxToken:typeof x.mapboxToken==='string'?x.mapboxToken.trim():'',
  advancedRoutingUrl:typeof x.advancedRoutingUrl==='string'?x.advancedRoutingUrl.trim():'',
  defaultRouteStartTime:normalizeClock(x.defaultRouteStartTime)||'08:00'
 };
}

export function isPublicMapboxToken(v:string){return /^pk\.[A-Za-z0-9._-]{10,}$/.test(v.trim());}
