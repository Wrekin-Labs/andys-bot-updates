/**
 * Google Maps URL hand-off (no paid APIs). Google documents up to 9 waypoints per
 * directions URL (fewer in some mobile browsers), so long days are split into legs.
 * Each later leg starts at the previous leg's last stop.
 */
export const MAX_WAYPOINTS = 9;

export function routeLegs(stops: string[], maxWaypoints = MAX_WAYPOINTS): string[][] {
  const clean = stops.map(s => s.trim()).filter(Boolean);
  const legs: string[][] = [];
  const firstSize = maxWaypoints + 1; // waypoints + destination, origin = current location
  if (!clean.length) return legs;
  legs.push(clean.slice(0, firstSize));
  for (let i = firstSize; i < clean.length; i += maxWaypoints + 1) {
    legs.push([clean[i - 1], ...clean.slice(i, i + maxWaypoints + 1)]);
  }
  return legs;
}

export function legUrl(leg: string[], isFirst: boolean) {
  const enc = encodeURIComponent;
  if (isFirst && leg.length === 1) return 'https://www.google.com/maps/search/?api=1&query=' + enc(leg[0]);
  const origin = isFirst ? '' : '&origin=' + enc(leg[0]);
  const rest = isFirst ? leg : leg.slice(1);
  const destination = rest[rest.length - 1];
  const waypoints = rest.slice(0, -1);
  return 'https://www.google.com/maps/dir/?api=1&travelmode=driving' + origin + '&destination=' + enc(destination) + (waypoints.length ? '&waypoints=' + waypoints.map(enc).join('%7C') : '');
}

export const routeUrls = (stops: string[], maxWaypoints = MAX_WAYPOINTS) => routeLegs(stops, maxWaypoints).map((leg, i) => legUrl(leg, i === 0));

const postcodeOf = (s: string) => (s.toUpperCase().match(/[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}/) || [''])[0].replace(/\s+/g, ' ');

/**
 * Simple offline ordering: groups stops by postcode district/area, then street text.
 * Stable for equal keys so manual order inside a group is kept. Not true optimisation.
 */
export function orderByArea<T extends {id: string; area: string; address?: string}>(stops: T[]): T[] {
  const key = (j: T) => {
    const pc = postcodeOf(j.address || '') || postcodeOf(j.area);
    return [(pc.split(' ')[0] || j.area || '').toLowerCase(), (j.area || '').toLowerCase(), pc.toLowerCase(), (j.address || '').toLowerCase()];
  };
  return stops.map((s, i) => ({s, i, k: key(s)})).sort((a, b) => {
    for (let n = 0; n < a.k.length; n++) { const c = a.k[n].localeCompare(b.k[n]); if (c) return c; }
    return a.i - b.i;
  }).map(x => x.s);
}

/** Applies a new order for a subset of ids while leaving all other rows where they are. */
export function applySubsetOrder<T extends {id: string}>(rows: T[], orderedIds: string[]): T[] {
  const set = new Set(orderedIds);
  const queue = orderedIds.map(id => rows.find(r => r.id === id)!).filter(Boolean);
  let k = 0;
  return rows.map(r => set.has(r.id) ? queue[k++] : r);
}
