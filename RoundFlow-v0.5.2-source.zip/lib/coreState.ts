import {numberInvoices} from './invoiceMath';
import {CORE_REVISION, migrateCore, reconcileBalances} from './ledger';
import type {Invoice, Job} from './types';

const finiteNonNeg = (n: unknown) => typeof n === 'number' && Number.isFinite(n) && n >= 0;

export function validateCore(jobs: unknown, invoices: unknown, lastInvoiceNo: unknown = 0) {
  if (!Array.isArray(jobs) || !Array.isArray(invoices)) throw new Error('Customer or invoice data is not a valid list.');
  const ids = (rows:any[]) => rows.every(x => x && typeof x.id === 'string' && x.id.length > 0) && new Set(rows.map(x=>x.id)).size === rows.length;
  if (!ids(jobs) || !ids(invoices)) throw new Error('Customer or invoice IDs are missing or duplicated.');
  const badJob=(j:any)=>typeof j.name !== 'string' || typeof j.freq !== 'string' || !Array.isArray(j.tags) || !finiteNonNeg(j.price) || !finiteNonNeg(j.owing)
    || (j.balanceAdjustment !== undefined && (typeof j.balanceAdjustment !== 'number' || !Number.isFinite(j.balanceAdjustment)))
    || (j.latitude !== undefined && (typeof j.latitude!=='number'||!Number.isFinite(j.latitude)||j.latitude < -90||j.latitude > 90))
    || (j.longitude !== undefined && (typeof j.longitude!=='number'||!Number.isFinite(j.longitude)||j.longitude < -180||j.longitude > 180))
    || ((j.latitude===undefined)!==(j.longitude===undefined))
    || (j.geocodedAt !== undefined && typeof j.geocodedAt!=='string')
    || (j.geocodeLabel !== undefined && typeof j.geocodeLabel!=='string')
    || (j.geocodeProvider !== undefined && !['mapbox','manual'].includes(j.geocodeProvider))
    || (j.timeWindowStart !== undefined && typeof j.timeWindowStart!=='string')
    || (j.timeWindowEnd !== undefined && typeof j.timeWindowEnd!=='string')
    || (j.fixedAppointment !== undefined && typeof j.fixedAppointment!=='boolean')
    || (j.hazards !== undefined && typeof j.hazards !== 'string')
    || (j.requiredSkills !== undefined && (!Array.isArray(j.requiredSkills) || j.requiredSkills.some((x:any)=>typeof x!=='string')))
    || (j.jobAttachments !== undefined && (!Array.isArray(j.jobAttachments) || j.jobAttachments.some((x:any)=>!x||typeof x.id!=='string'||typeof x.name!=='string'||typeof x.uri!=='string'||typeof x.addedAt!=='string')))
    || (j.checklist !== undefined && (!Array.isArray(j.checklist) || j.checklist.some((x:any)=>!x||typeof x.id!=='string'||typeof x.text!=='string'||typeof x.done!=='boolean')))
    || (j.formFields !== undefined && (!Array.isArray(j.formFields) || j.formFields.some((x:any)=>!x||typeof x.id!=='string'||typeof x.label!=='string'||typeof x.value!=='string')))
    || (j.timeEntries !== undefined && (!Array.isArray(j.timeEntries) || j.timeEntries.some((x:any)=>!x||typeof x.id!=='string'||typeof x.startISO!=='string'||(x.endISO!==undefined&&typeof x.endISO!=='string')||(x.minutes!==undefined&&!finiteNonNeg(x.minutes)))))
    || (j.visitHistory !== undefined && (!Array.isArray(j.visitHistory) || j.visitHistory.some((x:any)=>!x||typeof x.id!=='string'||typeof x.atISO!=='string'||!['completed','skipped','reopened','rescheduled'].includes(x.status))));
  if (jobs.some(badJob)) throw new Error('A customer has invalid details or amounts.');
  if (invoices.some(i => typeof i.jobId !== 'string' || typeof i.customer !== 'string' || !finiteNonNeg(i.amount) || !['paid','owing'].includes(i.status)
    || ['paidAmount','discount','taxRate','deposit'].some(k=>i[k]!==undefined&&!finiteNonNeg(i[k]))
    || (i.items!==undefined&&(!Array.isArray(i.items)||i.items.some((x:any)=>!x||typeof x.description!=='string'||!finiteNonNeg(x.qty)||!finiteNonNeg(x.rate))))
    || (i.payments!==undefined&&(!Array.isArray(i.payments)||i.payments.some((p:any)=>!p||typeof p.amount!=='number'||!Number.isFinite(p.amount)))))) throw new Error('An invoice has invalid amounts or status.');
  const numbered = numberInvoices(invoices, typeof lastInvoiceNo==='number' ? lastInvoiceNo : 0);
  return {version:1 as const,jobs,invoices:numbered.invoices,lastInvoiceNo:numbered.lastInvoiceNo};
}

/** Validates, migrates (v0.3.1 -> revision 2) and reconciles balances. Never mutates its input. */
export function loadCore(jobs: unknown, invoices: unknown, lastInvoiceNo: unknown = 0, revision: unknown = 1) {
  const valid = validateCore(jobs, invoices, lastInvoiceNo);
  const migrated = migrateCore(valid.jobs as Job[], valid.invoices as Invoice[], typeof revision === 'number' ? revision : 1);
  return {
    version: 1 as const,
    revision: CORE_REVISION,
    jobs: reconcileBalances(migrated.jobs, migrated.invoices),
    invoices: migrated.invoices,
    lastInvoiceNo: valid.lastInvoiceNo,
    migrated: migrated.migrated,
  };
}

export function decodeCore(raw:string) {
  const core=JSON.parse(raw);
  // `version` stays 1 so v0.3.1 can still open data written by v0.4.0 (downgrade safety);
  // the additive v0.4.0 shape is tracked by `revision`.
  if(core?.version!==1)throw new Error('This data version is not supported by this RoundFlow build.');
  if(typeof core.revision==='number'&&core.revision>CORE_REVISION)throw new Error('This data was saved by a newer RoundFlow version. Update the app before opening it.');
  return loadCore(core.jobs,core.invoices,core.lastInvoiceNo,core.revision);
}

export const encodeCore = (jobs: Job[], invoices: Invoice[], lastInvoiceNo: number) =>
  JSON.stringify({version: 1, revision: CORE_REVISION, jobs, invoices, lastInvoiceNo});
