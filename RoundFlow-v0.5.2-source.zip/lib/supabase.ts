import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

const url=process.env.EXPO_PUBLIC_SUPABASE_URL;
const key=process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export const cloudConfigured=Boolean(url&&key);
export const supabase=cloudConfigured?createClient(url!,key!,{
 auth:{
  storage:AsyncStorage as any,
  autoRefreshToken:true,
  persistSession:true,
  detectSessionInUrl:false,
 }
}):null;
