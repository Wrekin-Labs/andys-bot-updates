import { supabase } from './supabase';

export type CloudCustomer={
 id:string;organization_id:string;name:string;area:string|null;address:string|null;phone:string|null;notes:string|null;
 price:number;frequency_weeks:number;balance:number;active:boolean;updated_at:string;
};

export async function fetchCustomers(organizationId:string){
 if(!supabase) throw new Error('Cloud is not configured');
 const {data,error}=await supabase.from('customers').select('*').eq('organization_id',organizationId).eq('active',true).order('name');
 if(error) throw error;
 return (data??[]) as CloudCustomer[];
}

export async function upsertCustomer(customer:Partial<CloudCustomer>&{organization_id:string;name:string}){
 if(!supabase) throw new Error('Cloud is not configured');
 const {data,error}=await supabase.from('customers').upsert(customer).select().single();
 if(error) throw error;
 return data as CloudCustomer;
}

export async function fetchTodayJobs(organizationId:string,dateISO:string){
 if(!supabase) throw new Error('Cloud is not configured');
 const {data,error}=await supabase.from('jobs').select('*,customers(*)').eq('organization_id',organizationId).eq('due_date',dateISO).order('route_order');
 if(error) throw error;
 return data??[];
}

export async function markJobStatus(jobId:string,status:'scheduled'|'done'|'skipped'|'cancelled'){
 if(!supabase) throw new Error('Cloud is not configured');
 const patch:any={status,updated_at:new Date().toISOString()};
 if(status==='done') patch.completed_at=new Date().toISOString();
 const {error}=await supabase.from('jobs').update(patch).eq('id',jobId);
 if(error) throw error;
}


export type CloudWaterFill={
 id:string;organization_id:string;fill_date:string;litres:number;total_cost:number;vat_amount:number;
 supplier:string;station:string|null;vehicle:string|null;notes:string|null;receipt_path:string|null;
 created_by:string|null;created_at:string;updated_at:string;
};

export async function fetchWaterFills(organizationId:string){
 if(!supabase) throw new Error('Cloud is not configured');
 const {data,error}=await supabase.from('water_fills').select('*').eq('organization_id',organizationId).order('fill_date',{ascending:false});
 if(error) throw error;
 return (data??[]) as CloudWaterFill[];
}

export async function upsertWaterFill(fill:Partial<CloudWaterFill>&{organization_id:string;fill_date:string;litres:number;total_cost:number}){
 if(!supabase) throw new Error('Cloud is not configured');
 const {data,error}=await supabase.from('water_fills').upsert(fill).select().single();
 if(error) throw error;
 return data as CloudWaterFill;
}

export async function deleteWaterFill(id:string){
 if(!supabase) throw new Error('Cloud is not configured');
 const {error}=await supabase.from('water_fills').delete().eq('id',id);
 if(error) throw error;
}
