// Shared RoundFlow domain types. All fields added after v0.3.1 are optional so
// v0.3.1 snapshots and backups load unchanged and v0.4.0 data stays readable
// by v0.3.1 (it ignores unknown fields).

export type LineItem = {description: string; qty: number; rate: number};

export type Payment = {
  id: string;
  /** Display timestamp (en-GB), kept for compatibility with v0.3.x. */
  date: string;
  /** Machine-readable local date (YYYY-MM-DD). Added in v0.4.0. */
  atISO?: string;
  amount: number;
  method: string;
  /** Provider event/payment id used to make provider reconciliation idempotent. */
  providerRef?: string;
};

export type HistoryEntry = {at: string; label: string};

export type ReminderEntry = {at: string; atISO: string; channel: 'sms' | 'email'; template: string};

export type VoidRecord = {
  at: string;
  atISO: string;
  reason: string;
  original: {amount: number; items?: LineItem[]; discount?: number; taxRate?: number};
};

export type Invoice = {
  id: string;
  jobId: string;
  customer: string;
  amount: number;
  /** Display date (e.g. "05 Oct 2026"). */
  date: string;
  /** Machine-readable issue date. Added in v0.4.0 (migrated from `date`). */
  issuedISO?: string;
  status: 'paid' | 'owing';
  invoiceNo?: number;
  dueDate?: string;
  notes?: string;
  discount?: number;
  taxRate?: number;
  deposit?: number;
  paymentSchedule?: string;
  paymentInfo?: string;
  history?: HistoryEntry[];
  attachments?: {name: string; uri: string; mimeType?: string}[];
  signatureName?: string;
  attachmentName?: string;
  attachmentUri?: string;
  items?: LineItem[];
  paidAmount?: number;
  payments?: Payment[];
  reminders?: ReminderEntry[];
  voided?: VoidRecord;
  quoteId?: string;
};

export type BalanceLogEntry = {at: string; atISO: string; amount: number; label: string};
export type JobAttachment = {id:string;name:string;uri:string;mimeType?:string;addedAt:string};
export type JobChecklistItem = {id:string;text:string;done:boolean};
export type JobFormField = {id:string;label:string;value:string};
export type JobTimeEntry = {id:string;startISO:string;endISO?:string;minutes?:number};
export type JobVisitEntry = {id:string;atISO:string;status:'completed'|'skipped'|'reopened'|'rescheduled';worker?:string;note?:string};
export type TeamRole='Owner'|'Administrator'|'Creator'|'Planner'|'Worker';
export type TeamUser={id:string;name:string;email:string;active:boolean;roles:TeamRole[];skills?:string[];dailyCapacityMin?:number;startAddress?:string;endAddress?:string;startLatitude?:number;startLongitude?:number;endLatitude?:number;endLongitude?:number};

export type Job = {
  id: string; name: string; area: string; address?: string; phone?: string; email?: string; notes?: string;
  price: number;
  /** Customer balance. From v0.4.0 this is always derived: balanceAdjustment + unpaid invoice balances. */
  owing: number;
  /** Opening balance / migration adjustment not represented by an invoice (may be negative). */
  balanceAdjustment?: number;
  /** Audit trail for changes to balanceAdjustment (e.g. opening balance paid). */
  balanceLog?: BalanceLogEntry[];
  freq: string; tags: string[]; done: boolean; lastDone?: string; nextDue?: string;
  completionInvoiceId?: string; skipped?: boolean; dueDate?: string; nextDueDate?: string; archived?: boolean; paused?: boolean;
  durationMin?: number; worker?: string; service?: string;
  latitude?: number; longitude?: number; geocodedAt?: string; geocodeLabel?: string; geocodeProvider?: 'mapbox'|'manual';
  timeWindowStart?: string; timeWindowEnd?: string; fixedAppointment?: boolean;
  hazards?: string; requiredSkills?: string[]; jobAttachments?: JobAttachment[]; checklist?: JobChecklistItem[]; formFields?: JobFormField[]; timeEntries?: JobTimeEntry[]; visitHistory?: JobVisitEntry[];
  quoteId?: string;
};

export type Expense = {id: string; supplier: string; category: string; amount: number; date: string; notes?: string};

export type QuoteStatus = 'draft' | 'sent' | 'accepted' | 'declined';
export type Quote = {
  id: string;
  number?: number;
  customer: string;
  description: string;
  amount: number;
  status: QuoteStatus;
  created: string;
  validUntil?: string;
  history?: HistoryEntry[];
};
