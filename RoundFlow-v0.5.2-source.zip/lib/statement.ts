import {invoiceAmounts, roundMoney} from './invoiceMath';
import {invoiceIssuedISO, invoiceState} from './ledger';
import {businessHeader, esc, invoiceRef, money, PDF_STYLE} from './invoiceHtml';
import {normalizeProfile, paymentDetailsLines} from './profile';
import {displayDate} from './dates';
import type {Invoice, Job} from './types';

export type StatementRow = {
  date: string; ref: string; description: string; status: string;
  charged: number; paid: number; balance: number; running: number;
};

/**
 * Statement rows in date order with a running outstanding balance.
 * The final running figure always equals the customer's derived balance
 * (balanceAdjustment + unpaid invoices) before the zero floor is applied.
 */
export function statementRows(job: Job, invoices: Invoice[], today: string): StatementRow[] {
  const rows: StatementRow[] = [];
  let running = 0;
  const adjustment = job.balanceAdjustment || 0;
  const logPaid = roundMoney(-(job.balanceLog || []).reduce((a, e) => a + e.amount, 0));
  const opening = roundMoney(adjustment + logPaid);
  if (opening !== 0) {
    running = roundMoney(running + opening);
    rows.push({date: '', ref: '—', description: opening > 0 ? 'Balance brought forward' : 'Credit / adjustment brought forward', status: '', charged: opening, paid: 0, balance: opening, running});
  }
  for (const e of job.balanceLog || []) {
    running = roundMoney(running + e.amount);
    rows.push({date: e.atISO, ref: '—', description: e.label, status: 'Paid', charged: 0, paid: -e.amount, balance: 0, running});
  }
  const own = invoices.filter(i => i.jobId === job.id)
    .map(i => ({i, d: invoiceIssuedISO(i) || ''}))
    .sort((x, y) => x.d.localeCompare(y.d) || (x.i.invoiceNo || 0) - (y.i.invoiceNo || 0));
  for (const {i, d} of own) {
    const a = invoiceAmounts(i);
    const st = invoiceState(i, today);
    running = roundMoney(running + a.balance);
    rows.push({date: d, ref: invoiceRef(i.invoiceNo), description: i.voided ? 'Void invoice' : 'Invoice', status: st.state === 'overdue' ? `Overdue ${st.daysOverdue}d` : st.state[0].toUpperCase() + st.state.slice(1), charged: a.total, paid: a.paid, balance: a.balance, running});
  }
  return rows;
}

export function statementTotals(rows: StatementRow[]) {
  return {
    charged: roundMoney(rows.reduce((a, r) => a + r.charged, 0)),
    paid: roundMoney(rows.reduce((a, r) => a + r.paid, 0)),
    outstanding: rows.length ? Math.max(0, rows[rows.length - 1].running) : 0,
  };
}

export function statementHtml(job: Job, invoices: Invoice[], profileRaw: unknown, today: string) {
  const p = normalizeProfile(profileRaw);
  const rows = statementRows(job, invoices, today);
  const t = statementTotals(rows);
  const body = rows.map(r => `<tr><td>${esc(r.date ? displayDate(r.date) : '')}</td><td>${esc(r.ref)}</td><td>${esc(r.description)}${r.status ? `<div class="muted">${esc(r.status)}</div>` : ''}</td><td class="r">${money(r.charged)}</td><td class="r">${money(r.paid)}</td><td class="r">${money(r.balance)}</td><td class="r"><b>${money(r.running)}</b></td></tr>`).join('');
  const pay = paymentDetailsLines(p, job.name);
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${PDF_STYLE}</style></head><body><header>${businessHeader(p)}<div class="r"><b>CUSTOMER STATEMENT</b><p>${esc(displayDate(today))}</p></div></header><h3>${esc(job.name)}</h3><div class="text">${esc(job.address || job.area || '')}</div><table><tr><th>Date</th><th>Ref</th><th>Detail</th><th class="r">Total</th><th class="r">Paid</th><th class="r">Balance</th><th class="r">Running</th></tr>${body || '<tr><td colspan="7">No transactions yet.</td></tr>'}</table><div class="r">Total charged ${money(t.charged)}<br>Total paid ${money(t.paid)}<p class="balance">Outstanding ${money(t.outstanding)}</p></div>${pay.length ? `<p><b>How to pay</b><br><span class="text">${esc(pay.join('\n'))}</span></p>` : ''}${p.invoiceFooter.trim() ? `<footer class="text muted">${esc(p.invoiceFooter)}</footer>` : ''}</body></html>`;
}
