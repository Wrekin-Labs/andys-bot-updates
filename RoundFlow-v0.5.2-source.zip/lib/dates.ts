import {localDateISO} from './invoiceMath';

const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

export const isISODate = (value: unknown): value is string => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const dt = new Date(y, m - 1, d, 12);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
};

const build = (y: number, m: number, d: number) => {
  const iso = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  return isISODate(iso) ? iso : undefined;
};

/**
 * Converts the date strings written by v0.3.x into YYYY-MM-DD.
 * Accepts ISO dates, "05 Oct 2026" / "5 Sept 2026" (toLocaleDateString en-GB) and
 * "05/10/2026, 10:08:00" (toLocaleString en-GB). Returns undefined when unknown.
 */
export function parseLegacyDate(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const s = value.trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return build(+m[1], +m[2], +m[3]);
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (m) return build(+m[3], +m[2], +m[1]);
  m = s.match(/^(\d{1,2})\s+([A-Za-z]{3,})\.?,?\s+(\d{4})/);
  if (m) {
    const month = MONTHS.indexOf(m[2].slice(0, 3).toLowerCase());
    if (month >= 0) return build(+m[3], month + 1, +m[1]);
  }
  return undefined;
}

export const parseISODate = (iso: string) => new Date(iso + 'T12:00:00');
export const addDaysISO = (iso: string, days: number) => {
  const d = parseISODate(iso);
  d.setDate(d.getDate() + days);
  return localDateISO(d);
};
/** Whole calendar days from a to b (b - a). */
export const daysBetween = (a: string, b: string) => Math.round((parseISODate(b).getTime() - parseISODate(a).getTime()) / 86400000);
export const monthKey = (iso: string) => iso.slice(0, 7);
export const displayDate = (iso: string) => isISODate(iso)
  ? parseISODate(iso).toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'})
  : iso;
