export function parseCsvLine(line:string){
 const out:string[]=[];let cur='';let quoted=false;
 for(let i=0;i<line.length;i++){
  const c=line[i];
  if(c==='"'){if(quoted&&line[i+1]==='"'){cur+='"';i++;}else quoted=!quoted;}
  else if(c===','&&!quoted){out.push(cur);cur='';}
  else cur+=c;
 }
 out.push(cur);
 return out;
}

export function parseCsv(text:string){
 const records:string[]=[];let cur='';let quoted=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(c==='"'){
   if(quoted&&text[i+1]==='"'){cur+='""';i++;}
   else{quoted=!quoted;cur+=c;}
  }else if((c==='\n'||c==='\r')&&!quoted){
   if(c==='\r'&&text[i+1]==='\n')i++;
   if(cur.trim())records.push(cur);
   cur='';
  }else cur+=c;
 }
 if(quoted)throw new Error('CSV contains an unclosed quoted field');
 if(cur.trim())records.push(cur);
 return records.map(parseCsvLine);
}
/**
 * Escapes one CSV cell. Text beginning with = + - @ (or tab/CR) is prefixed with an
 * apostrophe so spreadsheet apps do not execute it as a formula (CSV injection).
 * Real numbers are written unchanged.
 */
export function csvCell(v: unknown) {
 if (typeof v === 'number') return Number.isFinite(v) ? String(v) : '';
 let s = String(v ?? '');
 if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
 return '"' + s.replace(/"/g, '""') + '"';
}

/** Maps spreadsheet frequency text to RoundFlow frequencies without turning one-off work into recurring work. */
export function parseFrequency(raw: string) {
 const s = raw.trim().toLowerCase();
 if (!s) return '4-weekly';
 if (/one[\s-]?off|\bonce\b|ad[\s-]?hoc|single/.test(s) || s === '0') return 'One-off';
 if (/fortnight/.test(s)) return '2-weekly';
 if (/^monthly$|^month$/.test(s)) return '4-weekly';
 const m = s.match(/\d+/);
 if (!m) return '4-weekly';
 const n = Number(m[0]);
 if (/month/.test(s)) return Math.max(1, Math.round(n * 52 / 12)) + '-weekly';
 return n > 0 ? n + '-weekly' : 'One-off';
}
