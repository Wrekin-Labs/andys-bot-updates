import {invoiceAmounts, roundMoney} from './invoiceMath';
import {invoiceIssuedISO, invoiceState} from './ledger';
import {monthKey, parseLegacyDate} from './dates';
import type {Expense, Invoice, Job} from './types';

export type MonthRow = {month: string; invoiced: number; received: number; expenses: number; net: number};
export type AgedDebt = {current: number; d1_30: number; d31_60: number; d61_90: number; d90plus: number};

const freqWeeks = (f: string) => { const m = f.match(/\d+/); return m ? Number(m[0]) : 0; };

/**
 * Business report. Income is cash-basis (payments by the date they were recorded,
 * reversals negative); "invoiced" is by issue date. Void invoices are excluded.
 * These figures are management information, not statutory accounts.
 */
export function buildReport({jobs, invoices, expenses, today}: {jobs: Job[]; invoices: Invoice[]; expenses: Expense[]; today: string}) {
  const months = new Map<string, MonthRow>();
  const row = (m: string) => { let r = months.get(m); if (!r) { r = {month: m, invoiced: 0, received: 0, expenses: 0, net: 0}; months.set(m, r); } return r; };
  const live = invoices.filter(i => !i.voided);
  const aged: AgedDebt = {current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90plus: 0};
  let invoiced = 0, received = 0, outstandingInvoices = 0, overdue = 0, overdueCount = 0, undated = 0;
  const jobById = new Map(jobs.map(j => [j.id, j]));
  const workers = new Map<string, {worker: string; visits: number; invoiced: number; collected: number}>();

  for (const inv of live) {
    const a = invoiceAmounts(inv);
    const issued = invoiceIssuedISO(inv);
    invoiced += a.total;
    if (issued) row(monthKey(issued)).invoiced += a.total; else undated += a.total;
    let recorded = 0;
    for (const p of inv.payments || []) {
      recorded += p.amount;
      const d = p.atISO || parseLegacyDate(p.date) || issued;
      if (d) row(monthKey(d)).received += p.amount;
      received += p.amount;
    }
    // v0.2/0.3 invoices marked paid before payment lines existed: attribute to issue month.
    const unrecorded = roundMoney(a.paid - recorded);
    if (unrecorded > 0) { received += unrecorded; if (issued) row(monthKey(issued)).received += unrecorded; }
    outstandingInvoices += a.balance;
    const st = invoiceState(inv, today);
    if (a.balance > 0) {
      if (st.state === 'overdue') {
        overdue += a.balance; overdueCount++;
        const d = st.daysOverdue;
        if (d <= 30) aged.d1_30 += a.balance; else if (d <= 60) aged.d31_60 += a.balance; else if (d <= 90) aged.d61_90 += a.balance; else aged.d90plus += a.balance;
      } else aged.current += a.balance;
    }
    const worker = jobById.get(inv.jobId)?.worker || 'Unassigned';
    const w = workers.get(worker) || {worker, visits: 0, invoiced: 0, collected: 0};
    w.visits++; w.invoiced += a.total; w.collected += a.paid; workers.set(worker, w);
  }
  // Opening balances settled through "Mark balance paid" are income too.
  for (const j of jobs) for (const e of j.balanceLog || []) { received += -e.amount; row(monthKey(e.atISO)).received += -e.amount; }

  let expenseTotal = 0;
  for (const e of expenses) {
    if (!Number.isFinite(e.amount)) continue;
    expenseTotal += e.amount;
    const d = parseLegacyDate(e.date);
    if (d) row(monthKey(d)).expenses += e.amount;
  }
  const monthly = [...months.values()].map(r => ({month: r.month, invoiced: roundMoney(r.invoiced), received: roundMoney(r.received), expenses: roundMoney(r.expenses), net: roundMoney(r.received - r.expenses)}))
    .sort((a, b) => b.month.localeCompare(a.month));

  const active = jobs.filter(j => !j.archived);
  const recurring = active.filter(j => !j.paused && freqWeeks(j.freq) > 0);
  const monthlyRoundValue = recurring.reduce((a, j) => a + j.price * (52 / 12) / freqWeeks(j.freq), 0);
  const outstanding = roundMoney(jobs.reduce((a, j) => a + j.owing, 0));

  return {
    invoiced: roundMoney(invoiced),
    received: roundMoney(received),
    expenses: roundMoney(expenseTotal),
    net: roundMoney(received - expenseTotal),
    /** Customer balances including opening balances; includes archived customers (debt still exists). */
    outstanding,
    outstandingInvoices: roundMoney(outstandingInvoices),
    overdue: roundMoney(overdue), overdueCount,
    aged: Object.fromEntries(Object.entries(aged).map(([k, v]) => [k, roundMoney(v)])) as AgedDebt,
    undatedInvoiced: roundMoney(undated),
    monthly,
    topBalances: [...jobs].filter(j => j.owing > 0).sort((a, b) => b.owing - a.owing).slice(0, 10).map(j => ({id: j.id, name: j.name, owing: j.owing, archived: !!j.archived})),
    workers: [...workers.values()].map(w => ({...w, invoiced: roundMoney(w.invoiced), collected: roundMoney(w.collected)})).sort((a, b) => b.invoiced - a.invoiced),
    round: {
      activeCustomers: active.length,
      paused: active.filter(j => j.paused).length,
      recurring: recurring.length,
      oneOff: active.filter(j => freqWeeks(j.freq) === 0).length,
      monthlyRoundValue: roundMoney(monthlyRoundValue),
      averagePrice: active.length ? roundMoney(active.reduce((a, j) => a + j.price, 0) / active.length) : 0,
    },
  };
}
export type Report = ReturnType<typeof buildReport>;
