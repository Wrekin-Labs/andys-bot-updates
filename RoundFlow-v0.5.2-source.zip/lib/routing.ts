import type {Job} from './types';

export type GeoPoint={lat:number;lng:number;label?:string};
export type MapViewport={centerLat:number;centerLng:number;zoom:number;width:number;height:number};
export type RouteLeg={distanceM:number;durationS:number};
export type RouteMetrics={distanceM:number;durationS:number;geometry?:string;legs?:RouteLeg[]};
export type RouteOptimiseResult={jobs:Job[];metrics:RouteMetrics;provider:'mapbox';snapped:GeoPoint[]};

const finite=(n:unknown)=>typeof n==='number'&&Number.isFinite(n);
export const hasCoords=(j:Job)=>finite(j.latitude)&&finite(j.longitude);
export const mapboxToken=()=>process.env.EXPO_PUBLIC_MAPBOX_TOKEN?.trim()||'';
export const liveRoutingReady=(token=mapboxToken())=>!!token.trim();

export function geocodeUrl(address:string,token=mapboxToken()){
 const q=encodeURIComponent(address.trim());
 return 'https://api.mapbox.com/search/geocode/v6/forward?q='+q+'&country=GB&limit=1&types=address,street,postcode,place&access_token='+encodeURIComponent(token);
}

export async function geocodeAddress(address:string,token=mapboxToken()):Promise<GeoPoint|null>{
 if(!token)throw new Error('Mapbox is not configured. Add EXPO_PUBLIC_MAPBOX_TOKEN to the build environment.');
 if(!address.trim())throw new Error('Enter a full address before locating this job.');
 const res=await fetch(geocodeUrl(address,token));
 if(!res.ok)throw new Error('Mapbox geocoding failed ('+res.status+').');
 const data:any=await res.json();
 const feature=data?.features?.[0];
 const coords=feature?.geometry?.coordinates;
 if(!Array.isArray(coords)||coords.length<2||!finite(coords[0])||!finite(coords[1]))return null;
 return{lng:Number(coords[0]),lat:Number(coords[1]),label:feature?.properties?.full_address||feature?.place_name||address};
}

const profile='mapbox/driving-traffic';
const point=(j:Job)=>String(j.longitude)+','+String(j.latitude);

export function directionsUrl(jobs:Job[],token=mapboxToken()){
 if(jobs.length<2)throw new Error('At least two located jobs are required.');
 if(jobs.some(j=>!hasCoords(j)))throw new Error('Every route job needs coordinates.');
 const coords=jobs.map(point).join(';');
 return 'https://api.mapbox.com/directions/v5/'+profile+'/'+coords+'?geometries=polyline&overview=full&steps=false&access_token='+encodeURIComponent(token);
}

export async function getRoadRoute(jobs:Job[],token=mapboxToken()):Promise<RouteMetrics>{
 if(!token)throw new Error('Mapbox is not configured.');
 if(jobs.length>25)throw new Error('Mapbox Directions supports up to 25 coordinates per request.');
 const res=await fetch(directionsUrl(jobs,token));
 if(!res.ok)throw new Error('Mapbox directions failed ('+res.status+').');
 const data:any=await res.json();
 const route=data?.routes?.[0];
 if(!route)throw new Error(data?.message||'No road route was returned.');
 return{distanceM:Number(route.distance)||0,durationS:Number(route.duration)||0,geometry:route.geometry||undefined,legs:Array.isArray(route.legs)?route.legs.map((l:any)=>({distanceM:Number(l?.distance)||0,durationS:Number(l?.duration)||0})):[]};
}

export function optimisationUrl(jobs:Job[],startFixed:boolean,endFixed:boolean,token=mapboxToken()){
 if(jobs.length<2||jobs.length>12)throw new Error('Mapbox road optimisation supports 2 to 12 coordinates.');
 if(jobs.some(j=>!hasCoords(j)))throw new Error('Every optimised job needs coordinates.');
 const coords=jobs.map(point).join(';');
 const source=startFixed?'first':'any';
 const destination=endFixed?'last':'any';
 const roundtrip=(!startFixed&&!endFixed)?'true':'false';
 if(roundtrip==='false'&&(!startFixed||!endFixed))throw new Error('For an open optimised route, choose both a start and an end job.');
 return 'https://api.mapbox.com/optimized-trips/v1/'+profile+'/'+coords+'?source='+source+'&destination='+destination+'&roundtrip='+roundtrip+'&geometries=polyline&overview=full&steps=false&access_token='+encodeURIComponent(token);
}

export async function optimiseMapbox(jobs:Job[],startId?:string|null,endId?:string|null,token=mapboxToken()):Promise<RouteOptimiseResult>{
 if(!token)throw new Error('Mapbox is not configured. Add EXPO_PUBLIC_MAPBOX_TOKEN to the build environment.');
 const start=startId?jobs.find(j=>j.id===startId):undefined;
 const end=endId?jobs.find(j=>j.id===endId):undefined;
 let ordered=[...jobs];
 if(start){ordered=[start,...ordered.filter(j=>j.id!==start.id)];}
 if(end&&end.id!==start?.id){ordered=[...ordered.filter(j=>j.id!==end.id),end];}
 const url=optimisationUrl(ordered,!!start,!!end,token);
 const res=await fetch(url);
 if(!res.ok)throw new Error('Mapbox optimisation failed ('+res.status+').');
 const data:any=await res.json();
 if(data?.code!=='Ok'||!data?.trips?.[0])throw new Error(data?.message||'No optimised route was returned.');
 const byWaypoint=(data.waypoints||[]).map((w:any,index:number)=>({index,order:Number(w.waypoint_index)})).sort((a:any,b:any)=>a.order-b.order);
 const sorted=byWaypoint.map((x:any)=>ordered[x.index]).filter(Boolean);
 const trip=data.trips[0];
 const snapped=(data.waypoints||[]).map((w:any)=>({lng:Number(w.location?.[0]),lat:Number(w.location?.[1]),label:w.name||undefined})).filter((p:GeoPoint)=>finite(p.lat)&&finite(p.lng));
 return{jobs:sorted,metrics:{distanceM:Number(trip.distance)||0,durationS:Number(trip.duration)||0,geometry:trip.geometry||undefined,legs:Array.isArray(trip.legs)?trip.legs.map((l:any)=>({distanceM:Number(l?.distance)||0,durationS:Number(l?.duration)||0})):[]},provider:'mapbox',snapped};
}

export function matrixUrl(jobs:Job[],source:GeoPoint,token=mapboxToken()){
 if(!token)throw new Error('Mapbox is not configured.');
 if(jobs.length<1||jobs.length>9)throw new Error('A traffic-matrix batch supports 1 to 9 candidate jobs.');
 if(jobs.some(j=>!hasCoords(j)))throw new Error('Every matrix candidate needs coordinates.');
 const coords=[source,...jobs.map(j=>({lat:j.latitude!,lng:j.longitude!}))].map(p=>String(p.lng)+','+String(p.lat)).join(';');
 const destinations=jobs.map((_,i)=>String(i+1)).join(';');
 return 'https://api.mapbox.com/directions-matrix/v1/mapbox/driving-traffic/'+coords+'?sources=0&destinations='+destinations+'&annotations=duration&access_token='+encodeURIComponent(token);
}

export async function furthestByRoad(jobs:Job[],source:GeoPoint,token=mapboxToken()):Promise<Job|null>{
 if(!token)throw new Error('Mapbox is not configured.');
 const located=jobs.filter(hasCoords);
 if(!located.length)return null;
 let best:Job|null=null,bestDur=-1;
 for(let i=0;i<located.length;i+=9){
  const batch=located.slice(i,i+9);
  const res=await fetch(matrixUrl(batch,source,token));
  if(!res.ok)throw new Error('Mapbox matrix failed ('+res.status+').');
  const data:any=await res.json();const row=data?.durations?.[0];
  if(!Array.isArray(row))throw new Error(data?.message||'No road matrix was returned.');
  row.forEach((d:any,n:number)=>{if(typeof d==='number'&&Number.isFinite(d)&&d>bestDur){bestDur=d;best=batch[n];}});
 }
 return best;
}

export function formatDistance(m:number){return m>=1609.344?(m/1609.344).toFixed(m>=16093.44?0:1)+' mi':Math.round(m)+' m';}
export function formatDuration(s:number){const mins=Math.round(s/60);const h=Math.floor(mins/60);const m=mins%60;return h?h+'h '+m+'m':mins+'m';}

const markerColour=(j:Job)=>j.done?'19a37f':j.owing>0?'c83f49':j.skipped?'8c9995':'4b82c3';
const mercatorY=(lat:number)=>{const r=lat*Math.PI/180;return(1-Math.log(Math.tan(r)+1/Math.cos(r))/Math.PI)/2;};

export function mapViewport(jobs:Job[],width=700,height=420,padding=56):MapViewport|null{
 const located=jobs.filter(hasCoords);if(!located.length)return null;
 const xs=located.map(j=>(j.longitude!+180)/360);const ys=located.map(j=>mercatorY(Math.max(-85,Math.min(85,j.latitude!))));
 const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
 const centerX=(minX+maxX)/2,centerY=(minY+maxY)/2;
 const spanX=Math.max(maxX-minX,1e-6),spanY=Math.max(maxY-minY,1e-6);
 const usableW=Math.max(64,width-padding*2),usableH=Math.max(64,height-padding*2);
 const zx=Math.log2(usableW/(512*spanX)),zy=Math.log2(usableH/(512*spanY));
 const zoom=Math.max(2,Math.min(18,Math.min(zx,zy)));
 const centerLng=centerX*360-180;
 const n=Math.PI*(1-2*centerY);const centerLat=180/Math.PI*Math.atan(Math.sinh(n));
 return{centerLat,centerLng,zoom,width,height};
}

export function projectMapPoint(lat:number,lng:number,v:MapViewport){
 const world=512*Math.pow(2,v.zoom);const x=(lng+180)/360*world;const y=mercatorY(Math.max(-85,Math.min(85,lat)))*world;
 const cx=(v.centerLng+180)/360*world;const cy=mercatorY(v.centerLat)*world;
 return{x:v.width/2+(x-cx),y:v.height/2+(y-cy)};
}

export function staticMapUrl(jobs:Job[],geometry?:string,token=mapboxToken()){
 if(!token||!jobs.length||jobs.some(j=>!hasCoords(j)))return'';
 const v=mapViewport(jobs);if(!v)return'';
 const overlays:string[]=[];
 if(geometry)overlays.push('path-4+19a37f-0.85('+encodeURIComponent(geometry)+')');
 jobs.slice(0,99).forEach((j,i)=>overlays.push('pin-s-'+String(i+1)+'+'+markerColour(j)+'('+j.longitude+','+j.latitude+')'));
 const camera=[v.centerLng.toFixed(6),v.centerLat.toFixed(6),v.zoom.toFixed(2),'0'].join(',');
 return 'https://api.mapbox.com/styles/v1/mapbox/dark-v11/static/'+overlays.join(',')+'/'+camera+'/'+v.width+'x'+v.height+'@2x?access_token='+encodeURIComponent(token);
}

export function missingGeocodes(jobs:Job[]){return jobs.filter(j=>!hasCoords(j)&&(j.address||j.area));}
