import {roundMoney, localDateISO} from './invoiceMath';
import {addDaysISO, displayDate, isISODate, parseLegacyDate} from './dates';
import {businessHeader, esc, money, PDF_STYLE} from './invoiceHtml';
import {normalizeProfile} from './profile';
import type {Invoice, Job, Quote, QuoteStatus} from './types';

export const QUOTE_VALIDITY_DAYS = 30;
export type QuoteDisplayStatus = QuoteStatus | 'expired';
export const quoteRef = (q: Quote) => q.number ? 'Q-' + String(q.number).padStart(5, '0') : 'Quote';

/** Validates/normalises the stored quote list (v0.3.1 quotes have no number/expiry). */
export function normalizeQuotes(raw: unknown): Quote[] {
  if (!Array.isArray(raw)) throw new Error('Quotes data is not a list.');
  let last = Math.max(0, ...raw.map((q: any) => Number.isSafeInteger(q?.number) ? q.number : 0));
  const used = new Set<number>();
  return [...raw].reverse().map((q: any) => {
    if (!q || typeof q.id !== 'string' || typeof q.customer !== 'string' || !Number.isFinite(q.amount) || q.amount < 0) throw new Error('A stored quote is invalid.');
    let number = Number.isSafeInteger(q.number) && q.number > 0 && !used.has(q.number) ? q.number : ++last;
    used.add(number);
    const status: QuoteStatus = ['draft', 'sent', 'accepted', 'declined'].includes(q.status) ? q.status : 'draft';
    const created = isISODate(q.created) ? q.created : parseLegacyDate(q.created) || localDateISO(new Date());
    return {...q, number, status, created, description: typeof q.description === 'string' ? q.description : ''} as Quote;
  }).reverse();
}

export const nextQuoteNumber = (quotes: Quote[]) => Math.max(0, ...quotes.map(q => q.number || 0)) + 1;

export function newQuote(quotes: Quote[], input: {customer: string; description: string; amount: number; validDays?: number}, today: string, id: string): Quote {
  if (!input.customer.trim()) throw new Error('Enter a customer.');
  if (!Number.isFinite(input.amount) || input.amount <= 0) throw new Error('Enter a valid amount.');
  return {
    id, number: nextQuoteNumber(quotes), customer: input.customer.trim(), description: input.description.trim() || 'Window cleaning',
    amount: roundMoney(input.amount), status: 'draft', created: today, validUntil: addDaysISO(today, input.validDays ?? QUOTE_VALIDITY_DAYS),
    history: [{at: displayDate(today), label: 'Created'}],
  };
}

export function quoteDisplayStatus(q: Quote, today: string): QuoteDisplayStatus {
  if ((q.status === 'draft' || q.status === 'sent') && q.validUntil && isISODate(q.validUntil) && q.validUntil < today) return 'expired';
  return q.status;
}

/** Status changes allowed from the UI. Accepting an expired quote requires extending it first. */
export function setQuoteStatus(q: Quote, status: QuoteStatus, today: string, links: {jobId?: string; invoiceId?: string}): Quote {
  if (status === q.status) return q;
  if (status === 'accepted' && quoteDisplayStatus(q, today) === 'expired') throw new Error('This quote has expired. Extend it before marking it accepted.');
  if (q.status === 'accepted' && (links.jobId || links.invoiceId)) throw new Error('This quote has already been converted. Its status can no longer change.');
  return {...q, status, history: [...(q.history || []), {at: displayDate(today), label: 'Status → ' + status}]};
}

export const extendQuote = (q: Quote, today: string, days = QUOTE_VALIDITY_DAYS): Quote =>
  ({...q, validUntil: addDaysISO(today, days), history: [...(q.history || []), {at: displayDate(today), label: 'Validity extended'}]});

/** Conversion state is read from the core ledger (job.quoteId / invoice.quoteId), the single source of truth. */
export function quoteLinks(q: Quote, jobs: Pick<Job, 'id' | 'quoteId'>[], invoices: Pick<Invoice, 'id' | 'quoteId' | 'invoiceNo' | 'voided'>[]) {
  const job = jobs.find(j => j.quoteId === q.id);
  const invoice = invoices.find(i => i.quoteId === q.id && !i.voided);
  return {jobId: job?.id, invoiceId: invoice?.id, invoiceNo: invoice?.invoiceNo};
}

export function quoteHtml(q: Quote, profileRaw: unknown, today: string) {
  const p = normalizeProfile(profileRaw);
  const status = quoteDisplayStatus(q, today);
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${PDF_STYLE}.box{margin-top:24px;border:1px solid #dfe7e4;border-radius:12px;padding:18px}.total{font-size:24px;font-weight:700}</style></head><body><header>${businessHeader(p)}<div class="r"><b>QUOTE ${esc(quoteRef(q))}</b><p>Issued ${esc(displayDate(q.created))}${q.validUntil ? `<br>Valid until ${esc(displayDate(q.validUntil))}` : ''}</p></div></header><h3>Prepared for</h3><b>${esc(q.customer)}</b><div class="box"><b class="text">${esc(q.description)}</b><p class="total">${money(q.amount)}${p.vat && p.defaultTaxRate ? ` <span class="muted">+ VAT @ ${esc(p.defaultTaxRate)}%</span>` : ''}</p><p>Status: ${esc(status.toUpperCase())}</p></div>${p.invoiceFooter.trim() ? `<footer class="text muted">${esc(p.invoiceFooter)}</footer>` : ''}</body></html>`;
}
