import {localDateISO} from './invoiceMath';

/** Central business + payment profile. Stored under `roundflow.profile` (same key as v0.3.1). */
export type BusinessProfile = {
  businessName: string;
  /** Owner / contact name (kept as `name` for v0.3.1 compatibility). */
  name: string;
  phone: string;
  email: string;
  address: string;
  industry: string;
  employees: string;
  vat: boolean;
  vatNumber: string;
  /** Default tax/VAT % applied to new invoices. 0 unless the user sets it. */
  defaultTaxRate: number;
  cis: boolean;
  bankAccountName: string;
  sortCode: string;
  accountNumber: string;
  /** Optional link the business already uses (e.g. SumUp/PayPal.me). Shown, never generated. */
  paymentUrl: string;
  /** Days from issue to due date for new invoices. v0.3.1 behaviour was 7. */
  paymentTermsDays: number;
  invoiceFooter: string;
};

export const DEFAULT_PROFILE: BusinessProfile = {
  businessName: '', name: '', phone: '', email: '', address: '', industry: 'Window cleaning', employees: '1',
  vat: false, vatNumber: '', defaultTaxRate: 0, cis: false,
  bankAccountName: '', sortCode: '', accountNumber: '', paymentUrl: '', paymentTermsDays: 7, invoiceFooter: '',
};

const str = (v: unknown, fallback = '') => typeof v === 'string' ? v : fallback;
const num = (v: unknown, fallback: number, min: number, max: number) => {
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() ? Number(v) : NaN;
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

/** Accepts anything stored by v0.3.1 or v0.4.0 and returns a complete profile. Unknown keys are kept. */
export function normalizeProfile(raw: unknown): BusinessProfile {
  const r = (raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}) as Record<string, unknown>;
  return {
    ...r,
    businessName: str(r.businessName), name: str(r.name), phone: str(r.phone), email: str(r.email), address: str(r.address),
    industry: str(r.industry, DEFAULT_PROFILE.industry), employees: str(r.employees, DEFAULT_PROFILE.employees),
    vat: r.vat === true, vatNumber: str(r.vatNumber), defaultTaxRate: num(r.defaultTaxRate, 0, 0, 100), cis: r.cis === true,
    bankAccountName: str(r.bankAccountName), sortCode: str(r.sortCode), accountNumber: str(r.accountNumber),
    paymentUrl: str(r.paymentUrl), paymentTermsDays: Math.round(num(r.paymentTermsDays, 7, 0, 365)), invoiceFooter: str(r.invoiceFooter),
  } as BusinessProfile;
}

const digits = (s: string) => s.replace(/[\s-]/g, '');
export const formatSortCode = (s: string) => {
  const d = digits(s);
  return /^\d{6}$/.test(d) ? `${d.slice(0, 2)}-${d.slice(2, 4)}-${d.slice(4)}` : s.trim();
};

/** Returns human-readable problems; an empty list means the profile is usable on invoices. */
export function validateProfile(p: BusinessProfile): string[] {
  const errors: string[] = [];
  if (p.sortCode.trim() && !/^\d{6}$/.test(digits(p.sortCode))) errors.push('Sort code must be 6 digits, e.g. 12-34-56.');
  if (p.accountNumber.trim() && !/^\d{8}$/.test(digits(p.accountNumber))) errors.push('UK account number must be 8 digits.');
  if ((p.sortCode.trim() || p.accountNumber.trim()) && !(p.sortCode.trim() && p.accountNumber.trim())) errors.push('Enter both sort code and account number, or neither.');
  if (p.paymentUrl.trim() && !/^https:\/\/[^\s/$.?#].[^\s]*$/i.test(p.paymentUrl.trim())) errors.push('Payment link must start with https://');
  if (p.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.email.trim())) errors.push('Business email address looks invalid.');
  if (p.vat && !p.vatNumber.trim()) errors.push('VAT registered businesses should show their VAT number on invoices.');
  if (p.vatNumber.trim() && !/^(GB)?(\d{9}|\d{12})$/i.test(digits(p.vatNumber))) errors.push('UK VAT number should be GB followed by 9 (or 12) digits.');
  if (!p.vat && p.defaultTaxRate > 0) errors.push('A default tax rate is set but the business is not marked VAT registered.');
  return errors;
}

/** Lines printed on invoices, statements and payment requests. */
export function paymentDetailsLines(p: BusinessProfile, reference?: string): string[] {
  const lines: string[] = [];
  if (p.bankAccountName.trim()) lines.push('Account name: ' + p.bankAccountName.trim());
  if (p.sortCode.trim()) lines.push('Sort code: ' + formatSortCode(p.sortCode));
  if (p.accountNumber.trim()) lines.push('Account number: ' + digits(p.accountNumber));
  if (reference && lines.length) lines.push('Reference: ' + reference);
  if (p.paymentUrl.trim()) lines.push('Pay online: ' + p.paymentUrl.trim());
  return lines;
}

export const defaultDueDate = (p: BusinessProfile, from = new Date()) => {
  const d = new Date(from);
  d.setDate(d.getDate() + p.paymentTermsDays);
  return localDateISO(d);
};

export const displayBusinessName = (p: Partial<BusinessProfile>) => p.businessName?.trim() || 'RoundFlow';
