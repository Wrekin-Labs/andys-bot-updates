import React,{useMemo,useState}from'react';
import{Alert,ScrollView,StyleSheet,Text,TextInput,TouchableOpacity,View}from'react-native';
import * as Print from'expo-print';
import * as Sharing from'expo-sharing';
import {useStoredState,asList} from './useStoredState';
import Insights from './Insights';
import {Chip,C} from './ui';
import type {Tone} from './ui';
import {localDateISO} from '../lib/invoiceMath';
import {normalizeQuotes,newQuote,quoteDisplayStatus,setQuoteStatus,extendQuote,quoteLinks,quoteHtml,quoteRef} from '../lib/quotes';
import {invoiceRef} from '../lib/invoiceHtml';
import {displayDate,isISODate} from '../lib/dates';
import {newId} from '../lib/ledger';
import type {BusinessProfile} from '../lib/profile';
import type {Expense,Invoice,Job,Quote,QuoteStatus} from '../lib/types';

type Round={id:string;name:string;area:string;frequency:string;jobIds:string[]};
type Template={id:string;name:string;text:string};

const money=(n:number)=>'£'+n.toFixed(2);
const today=()=>localDateISO(new Date());
const DEFAULT_TEMPLATES:Template[]=[
 {id:'1',name:'On my way',text:'Hi {name}, just letting you know we are on our way for your window clean.'},
 {id:'2',name:'Payment reminder',text:'Hi {name}, a quick reminder that {balance} is still outstanding. Thank you.'},
 {id:'3',name:'Reschedule',text:'Hi {name}, we need to move your clean to {date}. Please let us know if that causes a problem.'},
];
const quoteTone:Record<string,Tone>={draft:'grey',sent:'info',accepted:'ok',declined:'danger',expired:'warn'};

export default function BusinessHub({jobs,invoices,profile,onBulkPriceChange,onCreateJobFromQuote,onInvoiceQuote}:{jobs:Job[];invoices:Invoice[];profile:BusinessProfile;onBulkPriceChange?:(percent:number)=>void;onCreateJobFromQuote?:(quote:Quote)=>void;onInvoiceQuote?:(quote:Quote)=>void}){
 const[section,setSection]=useState<'quotes'|'expenses'|'reports'|'rounds'|'messages'>('quotes');
 const[rounds,setRounds,roundsState]=useStoredState<Round[]>('roundflow.rounds',[],asList);
 const[quotes,setQuotes,quotesState]=useStoredState<Quote[]>('roundflow.quotes',[],normalizeQuotes);
 const[expenses,setExpenses,expensesState]=useStoredState<Expense[]>('roundflow.expenses',[],asList);
 const[templates,setTemplates,templatesState]=useStoredState<Template[]>('roundflow.templates',DEFAULT_TEMPLATES,asList);
 const[rName,setRName]=useState('');const[rArea,setRArea]=useState('');const[rFreq,setRFreq]=useState('4-weekly');
 const[qCustomer,setQCustomer]=useState('');const[qDesc,setQDesc]=useState('');const[qAmount,setQAmount]=useState('');const[qDays,setQDays]=useState('30');
 const[eSupplier,setESupplier]=useState('');const[eCategory,setECategory]=useState('Fuel');const[eAmount,setEAmount]=useState('');const[eNotes,setENotes]=useState('');const[eDate,setEDate]=useState(today());
 const[tName,setTName]=useState('');const[tText,setTText]=useState('');
 const[pricePct,setPricePct]=useState('5');
 const t=today();
 const errors=[roundsState.error,quotesState.error,expensesState.error,templatesState.error].filter(Boolean);

 const activeJobs=jobs.filter(j=>!j.archived);
 const expenseTotal=useMemo(()=>expenses.reduce((a,e)=>a+(Number.isFinite(e.amount)?e.amount:0),0),[expenses]);
 const projected=useMemo(()=>activeJobs.reduce((a,j)=>a+j.price,0),[activeJobs]);

 const addRound=()=>{if(!rName.trim())return Alert.alert('Round name needed');setRounds(v=>[...v,{id:newId('r'),name:rName.trim(),area:rArea.trim()||'Unassigned',frequency:rFreq,jobIds:[]}]);setRName('');setRArea('');};
 const addQuote=()=>{try{const days=Math.round(Number(qDays));if(!Number.isFinite(days)||days<1||days>365)throw new Error('Validity must be 1–365 days.');const q=newQuote(quotes,{customer:qCustomer,description:qDesc,amount:Number(qAmount),validDays:days},t,newId('q'));setQuotes(v=>[q,...v]);setQCustomer('');setQDesc('');setQAmount('');}catch(e:any){Alert.alert('Check quote',e.message);}};
 const changeStatus=(q:Quote,st:QuoteStatus)=>{try{const next=setQuoteStatus(q,st,t,quoteLinks(q,jobs,invoices));setQuotes(v=>v.map(x=>x.id===q.id?next:x));}catch(e:any){Alert.alert('Quote',e.message);}};
 const extend=(q:Quote)=>setQuotes(v=>v.map(x=>x.id===q.id?extendQuote(x,t):x));
 const deleteQuote=(q:Quote)=>{if(quoteLinks(q,jobs,invoices).invoiceId||quoteLinks(q,jobs,invoices).jobId)return Alert.alert('Quote','Converted quotes are kept for your records.');Alert.alert('Delete quote?',quoteRef(q)+' will be removed.',[{text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress:()=>setQuotes(v=>v.filter(x=>x.id!==q.id))}]);};
 const shareQuote=async(q:Quote)=>{try{const out=await Print.printToFileAsync({html:quoteHtml(q,profile,t)});if(await Sharing.isAvailableAsync())await Sharing.shareAsync(out.uri,{mimeType:'application/pdf',dialogTitle:quoteRef(q)+' - '+q.customer});if(q.status==='draft')changeStatus(q,'sent');}catch(e:any){Alert.alert('Quote PDF failed',e?.message||String(e));}};
 const addExpense=()=>{const n=Number(eAmount);if(!eSupplier.trim()||!Number.isFinite(n)||n<=0)return Alert.alert('Check expense','Enter supplier and valid amount.');if(!isISODate(eDate))return Alert.alert('Check expense','Date must be YYYY-MM-DD.');setExpenses(v=>[{id:newId('e'),supplier:eSupplier.trim(),category:eCategory.trim()||'Other',amount:Math.round(n*100)/100,date:eDate,notes:eNotes.trim()},...v]);setESupplier('');setEAmount('');setENotes('');};
 const deleteExpense=(e:Expense)=>Alert.alert('Delete expense?',e.supplier+' '+money(e.amount),[{text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress:()=>setExpenses(v=>v.filter(x=>x.id!==e.id))}]);
 const addTemplate=()=>{if(!tName.trim()||!tText.trim())return Alert.alert('Template details needed');setTemplates(v=>[...v,{id:newId('t'),name:tName.trim(),text:tText.trim()}]);setTName('');setTText('');};
 const applyBulkPrices=()=>{const pct=Number(pricePct);if(!Number.isFinite(pct)||pct<=-100||pct===0)return Alert.alert('Price update','Enter a valid percentage, for example 5 or -5.');if(!onBulkPriceChange)return Alert.alert('Price update','Bulk price updates are not available in this build.');Alert.alert('Update all active prices?',`${pct>0?'+':''}${pct}% will be applied to ${activeJobs.length} active customers/jobs.`,[{text:'Cancel',style:'cancel'},{text:'Apply',onPress:()=>onBulkPriceChange(pct)}]);};

 const Tabs=()=> <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.tabs}>{([
  ['quotes','Quotes'],['expenses','Expenses'],['reports','Reports'],['rounds','Rounds'],['messages','Messages']
 ] as const).map(([k,l])=><TouchableOpacity key={k} accessibilityRole="tab" accessibilityState={{selected:section===k}} onPress={()=>setSection(k)} style={[s.tab,section===k&&s.tabOn]}><Text style={[s.tabTxt,section===k&&s.tabTxtOn]}>{l}</Text></TouchableOpacity>)}</ScrollView>;

 return <View style={s.wrap}><Text accessibilityRole="header" style={s.title}>Business hub</Text><Text style={s.sub}>Quotes, expenses, reports, rounds and message templates.</Text><Tabs/>
 {errors.map(e=><View key={e} style={[s.card,{borderColor:'#f1c8c8'}]}><Text style={s.dangerTxt}>{e}</Text></View>)}
 {section==='rounds'&&<View>
  <View style={s.card}><Text style={s.h}>Create round</Text><TextInput style={s.input} placeholder="Round name" value={rName} onChangeText={setRName}/><TextInput style={s.input} placeholder="Area / postcode" value={rArea} onChangeText={setRArea}/><View style={s.rowWrap}>{['2-weekly','4-weekly','6-weekly','8-weekly'].map(f=><TouchableOpacity key={f} accessibilityRole="button" onPress={()=>setRFreq(f)} style={[s.chip,rFreq===f&&s.chipOn]}><Text style={rFreq===f?s.chipTxtOn:s.chipTxt}>{f}</Text></TouchableOpacity>)}</View><TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addRound}><Text style={s.primaryTxt}>Add round</Text></TouchableOpacity></View>
  {rounds.map(r=><View key={r.id} style={s.card}><Text style={s.h}>{r.name}</Text><Text style={s.meta}>{r.area} · {r.frequency}</Text><Text style={s.meta}>{activeJobs.filter(j=>j.area.toLowerCase().includes(r.area.toLowerCase())||r.jobIds.includes(j.id)).length} matching/assigned jobs</Text><TouchableOpacity accessibilityRole="button" style={s.dangerLink} onPress={()=>setRounds(v=>v.filter(x=>x.id!==r.id))}><Text style={s.dangerTxt}>Delete round</Text></TouchableOpacity></View>)}
  {rounds.length===0&&<View style={s.card}><Text style={s.meta}>No named rounds yet. Create rounds by area, day or frequency.</Text></View>}
 </View>}
 {section==='quotes'&&<View>
  <View style={s.card}><Text style={s.h}>New quote / estimate</Text><TextInput style={s.input} placeholder="Customer" value={qCustomer} onChangeText={setQCustomer}/><TextInput style={[s.input,{minHeight:60,textAlignVertical:'top'}]} multiline placeholder="Work description" value={qDesc} onChangeText={setQDesc}/><View style={s.split}><TextInput style={[s.input,{flex:1}]} placeholder="Amount £" keyboardType="decimal-pad" value={qAmount} onChangeText={setQAmount}/><TextInput style={[s.input,{width:110}]} placeholder="Valid days" keyboardType="number-pad" value={qDays} onChangeText={setQDays} accessibilityLabel="Valid for days"/></View><TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addQuote}><Text style={s.primaryTxt}>Create quote</Text></TouchableOpacity></View>
  {quotes.length===0&&<View style={s.card}><Text style={s.meta}>No quotes yet. Accepted quotes can become a recurring job and/or an invoice — each only once.</Text></View>}
  {quotes.map(q=>{const st=quoteDisplayStatus(q,t);const links=quoteLinks(q,jobs,invoices);return <View key={q.id} style={s.card}><View style={s.split}><View style={{flex:1}}><Text style={s.meta}>{quoteRef(q)}</Text><Text style={s.h}>{q.customer}</Text><Text style={s.meta} numberOfLines={3}>{q.description}</Text><Text style={s.meta}>Issued {displayDate(q.created)}{q.validUntil?' · valid until '+displayDate(q.validUntil):''}</Text></View><View style={{alignItems:'flex-end',gap:6}}><Text style={s.money}>{money(q.amount)}</Text><Chip label={st.toUpperCase()} tone={quoteTone[st]}/></View></View>
   {(links.jobId||links.invoiceId)&&<Text style={[s.meta,{color:C.brand,fontWeight:'800'}]}>{links.jobId?'✓ Recurring job created':''}{links.jobId&&links.invoiceId?' · ':''}{links.invoiceId?'✓ Invoiced as '+invoiceRef(links.invoiceNo):''}</Text>}
   {!(links.jobId||links.invoiceId)&&<View style={s.rowWrap}>{(['draft','sent','accepted','declined'] as const).map(x=><TouchableOpacity key={x} accessibilityRole="button" accessibilityState={{selected:q.status===x}} onPress={()=>changeStatus(q,x)} style={[s.chip,q.status===x&&s.chipOn]}><Text style={q.status===x?s.chipTxtOn:s.chipTxt}>{x}</Text></TouchableOpacity>)}</View>}
   {st==='expired'&&<TouchableOpacity accessibilityRole="button" style={s.secondaryQuote} onPress={()=>extend(q)}><Text style={s.secondaryQuoteTxt}>Extend validity 30 days</Text></TouchableOpacity>}
   <TouchableOpacity accessibilityRole="button" style={s.secondaryQuote} onPress={()=>shareQuote(q)}><Text style={s.secondaryQuoteTxt}>PDF / Share quote</Text></TouchableOpacity>
   {q.status==='accepted'&&!links.jobId&&onCreateJobFromQuote&&<TouchableOpacity accessibilityRole="button" style={s.primary} onPress={()=>onCreateJobFromQuote(q)}><Text style={s.primaryTxt}>Create recurring job from quote</Text></TouchableOpacity>}
   {q.status==='accepted'&&!links.invoiceId&&onInvoiceQuote&&<TouchableOpacity accessibilityRole="button" style={s.primary} onPress={()=>onInvoiceQuote(q)}><Text style={s.primaryTxt}>Create invoice from quote</Text></TouchableOpacity>}
   {!(links.jobId||links.invoiceId)&&<TouchableOpacity accessibilityRole="button" style={s.dangerLink} onPress={()=>deleteQuote(q)}><Text style={s.dangerTxt}>Delete quote</Text></TouchableOpacity>}
  </View>;})}
 </View>}
 {section==='expenses'&&<View>
  <View style={s.card}><Text style={s.h}>Add expense</Text><TextInput style={s.input} placeholder="Supplier" value={eSupplier} onChangeText={setESupplier}/><TextInput style={s.input} placeholder="Category e.g. Fuel, Water, Equipment" value={eCategory} onChangeText={setECategory}/><View style={s.rowWrap}>{['Fuel','Water','Equipment','Insurance','Vehicle','Other'].map(c=><TouchableOpacity key={c} accessibilityRole="button" onPress={()=>setECategory(c)} style={[s.chip,eCategory===c&&s.chipOn]}><Text style={eCategory===c?s.chipTxtOn:s.chipTxt}>{c}</Text></TouchableOpacity>)}</View><View style={s.split}><TextInput style={[s.input,{flex:1}]} placeholder="Amount £" keyboardType="decimal-pad" value={eAmount} onChangeText={setEAmount}/><TextInput style={[s.input,{width:130}]} placeholder="YYYY-MM-DD" value={eDate} onChangeText={setEDate} accessibilityLabel="Expense date"/></View><TextInput style={s.input} placeholder="Notes / receipt reference" value={eNotes} onChangeText={setENotes}/><TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addExpense}><Text style={s.primaryTxt}>Save expense</Text></TouchableOpacity></View>
  <View style={s.card}><View style={s.split}><Text style={s.h}>Expense total</Text><Text style={s.money}>{money(expenseTotal)}</Text></View></View>
  {expenses.slice(0,50).map(e=><View key={e.id} style={s.card}><View style={s.split}><View style={{flex:1}}><Text style={s.h}>{e.supplier}</Text><Text style={s.meta}>{e.category} · {displayDate(e.date)}</Text>{!!e.notes&&<Text style={s.meta}>{e.notes}</Text>}</View><Text style={s.money}>{money(e.amount)}</Text></View><TouchableOpacity accessibilityRole="button" style={s.dangerLink} onPress={()=>deleteExpense(e)}><Text style={s.dangerTxt}>Delete</Text></TouchableOpacity></View>)}
 </View>}
 {section==='messages'&&<View>
  <View style={s.card}><Text style={s.h}>Message templates</Text><Text style={s.meta}>Use tokens like {'{name}'}, {'{balance}'} and {'{date}'}. Payment reminders use the reminder templates in Money.</Text><TextInput style={s.input} placeholder="Template name" value={tName} onChangeText={setTName}/><TextInput style={[s.input,{minHeight:80,textAlignVertical:'top'}]} multiline placeholder="Message" value={tText} onChangeText={setTText}/><TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addTemplate}><Text style={s.primaryTxt}>Add template</Text></TouchableOpacity></View>
  {templates.map(x=><View key={x.id} style={s.card}><Text style={s.h}>{x.name}</Text><Text style={s.meta}>{x.text}</Text><TouchableOpacity accessibilityRole="button" style={s.dangerLink} onPress={()=>setTemplates(v=>v.filter(y=>y.id!==x.id))}><Text style={s.dangerTxt}>Delete</Text></TouchableOpacity></View>)}
 </View>}
 {section==='reports'&&<View>
  <Insights jobs={jobs} invoices={invoices} today={t} profile={profile} expenses={expenses}/>
  <View style={s.card}><Text style={s.h}>Bulk price update</Text><Text style={s.meta}>Apply a percentage change to every active customer/job price. Existing invoices are not changed.</Text><TextInput style={s.input} keyboardType="decimal-pad" value={pricePct} onChangeText={setPricePct} placeholder="Percentage e.g. 5"/><Text style={s.meta}>Preview: {money(projected)} → {money(projected*(1+(Number(pricePct)||0)/100))}</Text><TouchableOpacity accessibilityRole="button" style={s.primary} onPress={applyBulkPrices}><Text style={s.primaryTxt}>Apply price update</Text></TouchableOpacity></View>
 </View>}
 </View>;
}

const s=StyleSheet.create({
 wrap:{marginTop:12},title:{fontSize:20,fontWeight:'900',color:C.ink},sub:{fontSize:12,color:C.muted,marginTop:3,marginBottom:10},
 tabs:{gap:7,paddingBottom:10},tab:{paddingVertical:9,paddingHorizontal:12,borderRadius:10,backgroundColor:'#eef3f2'},tabOn:{backgroundColor:C.brand},tabTxt:{fontSize:12,fontWeight:'800',color:'#54645f'},tabTxtOn:{color:'#fff'},
 card:{backgroundColor:'#fff',borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,marginBottom:10},h:{fontSize:15,fontWeight:'900',color:C.ink},meta:{fontSize:12,color:C.muted,marginTop:4},input:{backgroundColor:'#f8faf9',borderWidth:1,borderColor:C.line,borderRadius:10,padding:10,marginTop:9,fontSize:14,color:C.ink},
 primary:{backgroundColor:C.accent,padding:11,borderRadius:10,alignItems:'center',marginTop:10},primaryTxt:{color:'#fff',fontWeight:'900'},secondaryQuote:{backgroundColor:'#eef3f2',padding:10,borderRadius:10,alignItems:'center',marginTop:9},secondaryQuoteTxt:{color:C.brand,fontWeight:'800'},rowWrap:{flexDirection:'row',flexWrap:'wrap',gap:6,marginTop:9},chip:{paddingVertical:7,paddingHorizontal:9,borderRadius:9,backgroundColor:'#eef3f2'},chipOn:{backgroundColor:C.brand},chipTxt:{fontSize:11,color:'#425650'},chipTxtOn:{fontSize:11,color:'#fff',fontWeight:'800'},
 split:{flexDirection:'row',justifyContent:'space-between',gap:8},money:{fontSize:16,fontWeight:'900',color:C.ink},dangerLink:{marginTop:8,alignSelf:'flex-start',paddingVertical:4},dangerTxt:{fontSize:11,fontWeight:'800',color:C.danger},
});
