import React from'react';
import{Alert,StyleSheet,Text,TouchableOpacity,View}from'react-native';
import AsyncStorage from'@react-native-async-storage/async-storage';
import*as DocumentPicker from'expo-document-picker';
import*as Sharing from'expo-sharing';
import{cacheDirectory,EncodingType,readAsStringAsync,writeAsStringAsync}from'expo-file-system/legacy';
import{BACKUP_KEYS,buildBackup,planRestore}from'../lib/backup';
import{localDateISO}from'../lib/invoiceMath';
import{APP_VERSION}from'../lib/version';

export default function FullBackup({beforeTransfer,onRestored}:{beforeTransfer:()=>Promise<void>;onRestored:()=>void}){
 const exportBackup=async()=>{
  try{
   await beforeTransfer();
   const pairs=await AsyncStorage.multiGet([...BACKUP_KEYS]);
   const{json,warnings}=buildBackup(pairs,{appVersion:APP_VERSION});
   const path=(cacheDirectory||'')+'RoundFlow-backup-'+localDateISO(new Date())+'.json';
   await writeAsStringAsync(path,json,{encoding:EncodingType.UTF8});
   if(warnings.length)Alert.alert('Backup includes damaged sections','These could not be read and were saved as raw text for recovery: '+warnings.join(', '));
   if(await Sharing.isAvailableAsync())await Sharing.shareAsync(path,{mimeType:'application/json',dialogTitle:'RoundFlow full backup'});else Alert.alert('Backup ready',path);
  }catch(e:any){Alert.alert('Backup failed',e?.message||String(e));}
 };
 const importBackup=async()=>{
  try{
   const r=await DocumentPicker.getDocumentAsync({type:['application/json','text/plain'],copyToCacheDirectory:true});
   if(r.canceled)return;
   const plan=planRestore(await readAsStringAsync(r.assets[0].uri,{encoding:EncodingType.UTF8}));
   Alert.alert('Restore full backup?',`${plan.summary.customers} customers, ${plan.summary.invoices} invoices and ${plan.summary.sections} data sections will replace the matching data on this device. Sections not in the backup are left as they are.${plan.warnings.length?'\n\n'+plan.warnings.join('\n'):''}`,[
    {text:'Cancel',style:'cancel'},
    {text:'Restore',style:'destructive',onPress:async()=>{try{await beforeTransfer();await AsyncStorage.multiSet(plan.ops);onRestored();Alert.alert('Backup restored','Your restored data is now loaded.');}catch(e:any){Alert.alert('Restore failed',e?.message||String(e));}}}
   ]);
  }catch(e:any){Alert.alert('Restore failed',e?.message||String(e));}
 };
 return <View style={s.box}><Text style={s.title}>Full local backup</Text><Text style={s.muted}>Back up customers, invoices, rounds, quotes, expenses, message templates, business profile, users and water fills to one JSON file. Invoice attachment files are not included.</Text><View style={s.row}><TouchableOpacity accessibilityRole="button" style={s.btn} onPress={exportBackup}><Text style={s.btnText}>Export full backup</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" style={s.btn} onPress={importBackup}><Text style={s.btnText}>Restore backup</Text></TouchableOpacity></View></View>;
}
const s=StyleSheet.create({box:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:16,padding:14,marginBottom:10},title:{fontSize:16,fontWeight:'800',color:'#15302a',marginBottom:6},muted:{fontSize:12,color:'#5f6f6b'},row:{flexDirection:'row',gap:8,marginTop:12},btn:{flex:1,backgroundColor:'#eef3f2',padding:12,borderRadius:12,alignItems:'center'},btnText:{fontWeight:'800',fontSize:12,color:'#15302a'}});
