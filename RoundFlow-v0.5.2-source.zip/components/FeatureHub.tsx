import React,{useMemo,useState} from 'react';
import {Alert,StyleSheet,Text,TextInput,TouchableOpacity,View} from 'react-native';
import {useStoredState,asList} from './useStoredState';
import {C,Chip,SectionHeader} from './ui';
import {newId} from '../lib/ledger';

type Status='live'|'local'|'cloud'|'planned';
type Draft={id:string;title:string;body:string;created:string};
type MarketDraft={id:string;title:string;area:string;price:string;notes:string;created:string};

const tone=(s:Status)=>s==='live'?'ok':s==='local'?'info':s==='cloud'?'warn':'grey';
const badge=(s:Status)=>s==='live'?'LIVE':s==='local'?'LOCAL':s==='cloud'?'CLOUD REQUIRED':'PLANNED';

export default function FeatureHub({onToday,onCapacity,onMap,onCustomers,onMoney,onBusiness,onWater}:{onToday:()=>void;onCapacity:()=>void;onMap:()=>void;onCustomers:()=>void;onMoney:()=>void;onBusiness:()=>void;onWater:()=>void}){
 const[open,setOpen]=useState<string|null>('Job Management & Scheduling');
 const[campaigns,setCampaigns]=useStoredState<Draft[]>('roundflow.campaignDrafts',[],asList);
 const[listings,setListings]=useStoredState<MarketDraft[]>('roundflow.marketplaceDrafts',[],asList);
 const[cTitle,setCTitle]=useState('');const[cBody,setCBody]=useState('');
 const[mTitle,setMTitle]=useState('');const[mArea,setMArea]=useState('');const[mPrice,setMPrice]=useState('');const[mNotes,setMNotes]=useState('');

 const groups=useMemo(()=>[
  {title:'Job Management & Scheduling',subtitle:'Plan, schedule and manage work efficiently in one place.',items:[
   ['Job records and tracking','Customer, completion and invoice history.','live',onToday],
   ['Add and edit jobs','Recurring and one-off work with service, price and duration.','live',onToday],
   ['Attach job files and pictures','Photos, PDFs and documents stay with the job.','local',onCustomers],
   ['Custom forms & checklists','Site-specific fields and completion checklists.','local',onCustomers],
   ['Forward capacity','Four-week load view with jobs, minutes, value and team capacity.','live',onCapacity],
   ['Job time recording','Start/stop timer with local time-entry history.','local',onCustomers],
   ['Hazards & risks','Store safety/access risks against each job.','local',onCustomers],
   ['Bulk price changes','Apply percentage changes to active customer prices.','live',onBusiness],
   ['Group jobs into rounds','Named rounds by area/frequency.','live',onBusiness],
   ['Replan jobs','Move visits by day or reorder the round.','live',onToday],
   ['Required skills for a job','Record skills needed for the visit.','local',onCustomers],
   ['View and plan jobs on a map','Colour-coded numbered route plan plus Google Maps hand-off.','live',onMap],
  ]},
  {title:'Customer Management',subtitle:'Keep customer, service and account information together.',items:[
   ['Unlimited local customers','No local customer-count restriction in this build.','local',onCustomers],
   ['Manage customer details','Address, access notes, contact, service and recurrence.','live',onCustomers],
   ['Statements & account history','Running balances and PDF statements.','live',onCustomers],
   ['Customer portal','Secure hosted invoice/quote/payment links.','cloud',undefined],
  ]},
  {title:'Work Assignment & Scheduling',subtitle:'Assign work and organise the team.',items:[
   ['Assign work to users and teams','Worker field works locally; real team permissions need cloud auth.','local',onCustomers],
   ['Optimised route navigation','Area ordering works offline; RoundFlow-managed road optimisation, map, distance and ETA switch on automatically when the managed routing service is enabled. Larger/time-window/multi-worker routes use the advanced backend.','live',onToday],
   ['Real-time worker updates','Live cross-device status and sync.','cloud',undefined],
   ['User roles','Owner/Admin/Planner/Worker model prepared for cloud memberships.','cloud',onBusiness],
  ]},
  {title:'Business Management',subtitle:'Quotes, expenses, invoicing and operating controls.',items:[
   ['Expenses','Record supplier/category/date/cost.','live',onBusiness],
   ['Invoicing','PDF invoices, VAT, partial payments, reversals and void audit.','live',onMoney],
   ['Payments','Local records + business payment URL; provider webhooks next.','local',onMoney],
   ['Quotes / estimates','Numbered quotes with expiry and conversion.','live',onBusiness],
   ['Pure-water management','Fill ledger and cost per litre.','live',onWater],
  ]},
  {title:'Financials & Reporting',subtitle:'See business performance and outstanding debt.',items:[
   ['Finance dashboard','Received, invoiced, expenses, net and aged debt.','live',onMoney],
   ['Bookkeeping records','Cash-basis management records and PDF report.','live',onMoney],
   ['VAT / CIS settings','Operational fields only; not statutory filing.','local',onBusiness],
   ['Cloud accounting export','Provider integration / formal accounting exports.','planned',undefined],
  ]},
  {title:'Customer Services',subtitle:'Customer communication and self-service.',items:[
   ['Customer messaging','Call, SMS/email composer and reminder templates.','live',onCustomers],
   ['Self-service customer portal','Hosted customer page for invoices, quotes and payments.','cloud',undefined],
   ['Automatic email attachments','Server-side delivery with invoice/statement attachments.','cloud',undefined],
  ]},
  {title:'Messaging & Communication Tools',subtitle:'Templates now; automation after production backend.',items:[
   ['Message templates','Reusable local message templates.','live',onBusiness],
   ['Automated reminders','Scheduled SMS/email, retries and delivery status.','cloud',undefined],
   ['Marketing campaign drafts','Prepare campaign copy locally without sending automatically.','local',undefined],
  ]},
  {title:'Marketplace',subtitle:'Prepare work/round listings locally; public marketplace needs backend.',items:[
   ['Marketplace listing drafts','Draft a round/job listing with area and price.','local',undefined],
   ['Buy / sell rounds and jobs','Public search, offers and transfer workflow.','cloud',undefined],
  ]},
 ] as const,[onToday,onCapacity,onMap,onCustomers,onMoney,onBusiness,onWater]);

 const addCampaign=()=>{if(!cTitle.trim()||!cBody.trim())return Alert.alert('Campaign','Add a title and message.');setCampaigns(v=>[{id:newId('mc'),title:cTitle.trim(),body:cBody.trim(),created:new Date().toISOString()},...v]);setCTitle('');setCBody('');};
 const addListing=()=>{if(!mTitle.trim()||!mArea.trim())return Alert.alert('Marketplace','Add a title and area.');setListings(v=>[{id:newId('ml'),title:mTitle.trim(),area:mArea.trim(),price:mPrice.trim(),notes:mNotes.trim(),created:new Date().toISOString()},...v]);setMTitle('');setMArea('');setMPrice('');setMNotes('');};

 return <View style={s.wrap}>
  <Text accessibilityRole="header" style={s.title}>RoundFlow features</Text>
  <Text style={s.sub}>Phone, tablet and PC capability map. Live/local items work without pretending cloud services are connected.</Text>

  {groups.map(g=><View key={g.title} style={s.group}>
   <TouchableOpacity accessibilityRole="button" accessibilityState={{expanded:open===g.title}} onPress={()=>setOpen(open===g.title?null:g.title)} style={s.groupHead}>
    <View style={{flex:1}}><Text style={s.groupTitle}>{g.title}</Text><Text style={s.groupSub}>{g.subtitle}</Text></View><Text style={s.chev}>{open===g.title?'⌃':'⌄'}</Text>
   </TouchableOpacity>
   {open===g.title&&<View>{g.items.map(([title,desc,status,action])=><TouchableOpacity key={title} accessibilityRole="button" disabled={!action} onPress={action} style={s.item}>
    <View style={s.icon}><Text style={s.iconText}>◆</Text></View><View style={{flex:1}}><Text style={s.itemTitle}>{title}</Text><Text style={s.itemDesc}>{desc}</Text></View><Chip label={badge(status as Status)} tone={tone(status as Status)}/><Text style={s.arrow}>{action?'›':''}</Text>
   </TouchableOpacity>)}</View>}
  </View>)}

  <View style={s.card}>
   <SectionHeader title="MARKETING CAMPAIGN DRAFTS" right={<Chip label={String(campaigns.length)} tone="info"/>}/>
   <TextInput style={s.input} value={cTitle} onChangeText={setCTitle} placeholder="Campaign title"/>
   <TextInput style={[s.input,s.multi]} multiline value={cBody} onChangeText={setCBody} placeholder="Message / offer / customer update"/>
   <TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addCampaign}><Text style={s.primaryText}>Save campaign draft</Text></TouchableOpacity>
   {campaigns.slice(0,8).map(x=><View key={x.id} style={s.draft}><View style={{flex:1}}><Text style={s.itemTitle}>{x.title}</Text><Text style={s.itemDesc}>{x.body}</Text></View><TouchableOpacity accessibilityRole="button" onPress={()=>setCampaigns(v=>v.filter(y=>y.id!==x.id))}><Text style={s.delete}>Delete</Text></TouchableOpacity></View>)}
   <Text style={s.note}>Drafts only. RoundFlow does not bulk-send marketing messages in this local build.</Text>
  </View>

  <View style={s.card}>
   <SectionHeader title="MARKETPLACE LISTING DRAFTS" right={<Chip label={String(listings.length)} tone="info"/>}/>
   <TextInput style={s.input} value={mTitle} onChangeText={setMTitle} placeholder="Round / work listing title"/>
   <View style={s.split}><TextInput style={[s.input,{flex:1}]} value={mArea} onChangeText={setMArea} placeholder="Area"/><TextInput style={[s.input,{flex:1}]} value={mPrice} onChangeText={setMPrice} placeholder="Price / value"/></View>
   <TextInput style={[s.input,s.multi]} multiline value={mNotes} onChangeText={setMNotes} placeholder="Jobs, frequency, notes, reason for sale…"/>
   <TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addListing}><Text style={s.primaryText}>Save listing draft</Text></TouchableOpacity>
   {listings.slice(0,8).map(x=><View key={x.id} style={s.draft}><View style={{flex:1}}><Text style={s.itemTitle}>{x.title}</Text><Text style={s.itemDesc}>{x.area}{x.price?' · '+x.price:''}</Text><Text style={s.itemDesc}>{x.notes}</Text></View><TouchableOpacity accessibilityRole="button" onPress={()=>setListings(v=>v.filter(y=>y.id!==x.id))}><Text style={s.delete}>Delete</Text></TouchableOpacity></View>)}
   <Text style={s.note}>Public marketplace/search/offers require the production cloud service.</Text>
  </View>
 </View>;
}

const s=StyleSheet.create({
 wrap:{marginTop:12},title:{fontSize:20,fontWeight:'900',color:C.ink},sub:{fontSize:12,color:C.muted,lineHeight:17,marginTop:3,marginBottom:10},
 group:{backgroundColor:C.card,borderWidth:1,borderColor:C.line,borderRadius:14,overflow:'hidden',marginBottom:9},groupHead:{flexDirection:'row',alignItems:'center',padding:12,gap:8},groupTitle:{fontSize:14,fontWeight:'900',color:C.ink},groupSub:{fontSize:11,color:C.muted,lineHeight:15,marginTop:3},chev:{fontSize:18,fontWeight:'900',color:C.brand},
 item:{flexDirection:'row',alignItems:'center',gap:9,padding:11,borderTopWidth:1,borderTopColor:C.grey},icon:{width:28,height:28,borderRadius:8,backgroundColor:C.brandSoft,alignItems:'center',justifyContent:'center'},iconText:{color:C.brand,fontSize:10},itemTitle:{fontSize:12,fontWeight:'900',color:C.ink},itemDesc:{fontSize:10.5,color:C.muted,lineHeight:14,marginTop:2},arrow:{fontSize:18,color:C.muted},
 card:{backgroundColor:C.card,borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,marginTop:10},input:{backgroundColor:'#f8faf9',borderWidth:1,borderColor:C.line,borderRadius:10,padding:10,marginBottom:8,fontSize:13,color:C.ink},multi:{minHeight:74,textAlignVertical:'top'},primary:{backgroundColor:C.accent,borderRadius:10,padding:11,alignItems:'center'},primaryText:{color:'#fff',fontWeight:'900'},draft:{flexDirection:'row',gap:10,paddingVertical:10,borderTopWidth:1,borderTopColor:C.grey},delete:{fontSize:11,fontWeight:'800',color:C.danger},note:{fontSize:10.5,color:C.muted,lineHeight:15,marginTop:8},split:{flexDirection:'row',gap:8}
});
