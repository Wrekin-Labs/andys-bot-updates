import React, {useEffect, useRef, useState} from 'react';
import {Alert, TextInput} from 'react-native';
import type {TextInputProps} from 'react-native';

export type CommitOptions = {silent?: boolean};

/**
 * Numeric input that keeps a text draft while typing.
 * - commitOnChange (default true, used by the invoice editor so values are committed
 *   before switching to Preview): intermediate keystrokes are committed *silently* —
 *   the parent must not raise alerts for them; validation alerts happen on blur.
 * - commitOnChange=false: commits only on blur/submit (used for minutes, terms, %).
 */
export default function DecimalInput({value,onCommit,commitOnChange=true,min=0,max,integer=false,...props}:Omit<TextInputProps,'value'|'onChangeText'|'onBlur'> & {value:number;onCommit:(value:number,options?:CommitOptions)=>boolean|void;commitOnChange?:boolean;min?:number;max?:number;integer?:boolean}) {
  const [draft,setDraft]=useState(String(value));
  const focused=useRef(false);
  useEffect(()=>{if(!focused.current)setDraft(String(value));},[value]);
  const parse=(text:string)=>{const n=Number(text.trim());return text.trim()&&Number.isFinite(n)&&n>=min&&(max===undefined||n<=max)&&(!integer||Number.isInteger(n))?n:null;};
  const commit=()=>{
    focused.current=false;
    const n=parse(draft);
    if(n===null){setDraft(String(value));Alert.alert('Invalid amount',`Enter a valid ${integer?'whole ':''}number${max!==undefined?` from ${min} to ${max}`:min>0?` of at least ${min}`:' of zero or more'}.`);return;}
    const accepted=onCommit(n);
    // Keep the entered decimal visible while the parent validates the change.
    setDraft(String(accepted===false?value:n));
  };
  return <TextInput {...props} value={draft} keyboardType={integer?'number-pad':'decimal-pad'} onFocus={()=>{focused.current=true;}} onChangeText={text=>{setDraft(text);if(!commitOnChange)return;const n=parse(text);if(n!==null&&!text.endsWith('.'))onCommit(n,{silent:true});}} onBlur={commit} onSubmitEditing={commit}/>;
}
