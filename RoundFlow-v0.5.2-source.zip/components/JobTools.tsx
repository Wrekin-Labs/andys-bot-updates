import React,{useMemo,useState} from 'react';
import {Alert,StyleSheet,Text,TextInput,TouchableOpacity,View} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import {C,Chip,SectionHeader} from './ui';
import {newId} from '../lib/ledger';
import type {Job,JobAttachment,JobChecklistItem,JobFormField,JobTimeEntry} from '../lib/types';

const nowISO=()=>new Date().toISOString();
const minutesBetween=(a:string,b:string)=>Math.max(0,Math.round((new Date(b).getTime()-new Date(a).getTime())/60000));
const totalMinutes=(entries:JobTimeEntry[])=>entries.reduce((sum,e)=>sum+(e.minutes??(e.endISO?minutesBetween(e.startISO,e.endISO):0)),0);

export default function JobTools({job,onChange}:{job:Job;onChange:(patch:Partial<Job>)=>void}){
 const[checkText,setCheckText]=useState('');
 const[fieldLabel,setFieldLabel]=useState('');
 const[fieldValue,setFieldValue]=useState('');
 const attachments=job.jobAttachments||[];
 const checklist=job.checklist||[];
 const formFields=job.formFields||[];
 const timeEntries=job.timeEntries||[];
 const active=timeEntries.find(e=>!e.endISO);
 const minutes=useMemo(()=>totalMinutes(timeEntries),[timeEntries]);

 const addFiles=async()=>{try{
  const result=await DocumentPicker.getDocumentAsync({multiple:true,copyToCacheDirectory:true});
  if(result.canceled)return;
  const added:JobAttachment[]=result.assets.map(a=>({id:newId('ja'),name:a.name||'Attachment',uri:a.uri,mimeType:a.mimeType||undefined,addedAt:nowISO()}));
  onChange({jobAttachments:[...attachments,...added]});
 }catch(e:any){Alert.alert('Attachment',e?.message||String(e));}};
 const removeFile=(id:string)=>onChange({jobAttachments:attachments.filter(x=>x.id!==id)});

 const startTimer=()=>{if(active)return;onChange({timeEntries:[...timeEntries,{id:newId('te'),startISO:nowISO()}]});};
 const stopTimer=()=>{if(!active)return;const endISO=nowISO();onChange({timeEntries:timeEntries.map(e=>e.id===active.id?{...e,endISO,minutes:minutesBetween(e.startISO,endISO)}:e)});};

 const addCheck=()=>{const text=checkText.trim();if(!text)return;const item:JobChecklistItem={id:newId('ci'),text,done:false};onChange({checklist:[...checklist,item]});setCheckText('');};
 const toggleCheck=(id:string)=>onChange({checklist:checklist.map(x=>x.id===id?{...x,done:!x.done}:x)});
 const removeCheck=(id:string)=>onChange({checklist:checklist.filter(x=>x.id!==id)});

 const addField=()=>{const label=fieldLabel.trim();if(!label)return;const item:JobFormField={id:newId('ff'),label,value:fieldValue.trim()};onChange({formFields:[...formFields,item]});setFieldLabel('');setFieldValue('');};
 const updateField=(id:string,value:string)=>onChange({formFields:formFields.map(x=>x.id===id?{...x,value}:x)});
 const removeField=(id:string)=>onChange({formFields:formFields.filter(x=>x.id!==id)});

 return <View>
  <View style={s.card}>
   <SectionHeader title="JOB FILES & PHOTOS" right={<Chip label={String(attachments.length)} tone={attachments.length?'info':'grey'}/>}/>
   <Text style={s.meta}>Attach pictures, PDFs, worksheets or other job files from the device.</Text>
   <TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addFiles}><Text style={s.primaryText}>＋ Add files / pictures</Text></TouchableOpacity>
   {attachments.map(a=><View key={a.id} style={s.row}><View style={{flex:1}}><Text style={s.rowTitle} numberOfLines={1}>{a.name}</Text><Text style={s.meta}>{a.mimeType||'File'}</Text></View><TouchableOpacity accessibilityRole="button" onPress={()=>removeFile(a.id)} style={s.remove}><Text style={s.removeText}>Remove</Text></TouchableOpacity></View>)}
  </View>

  <View style={s.card}>
   <SectionHeader title="JOB TIME" right={<Chip label={minutes+' min'} tone={active?'warn':'grey'}/>}/>
   <Text style={s.meta}>Record time spent on the job. Timer entries stay with this customer/job locally.</Text>
   <View style={s.actions}>{active?<TouchableOpacity accessibilityRole="button" style={s.stop} onPress={stopTimer}><Text style={s.stopText}>■ Stop timer</Text></TouchableOpacity>:<TouchableOpacity accessibilityRole="button" style={s.primary} onPress={startTimer}><Text style={s.primaryText}>▶ Start timer</Text></TouchableOpacity>}</View>
   {[...timeEntries].reverse().slice(0,8).map(e=><View key={e.id} style={s.row}><Text style={s.rowTitle}>{new Date(e.startISO).toLocaleString('en-GB')}</Text><Text style={s.rowTitle}>{e.endISO?(e.minutes??minutesBetween(e.startISO,e.endISO))+' min':'Running'}</Text></View>)}
  </View>

  <View style={s.card}>
   <SectionHeader title="MAP & APPOINTMENT WINDOW" right={<Chip label={job.latitude!==undefined&&job.longitude!==undefined?'LOCATED':'UNPINNED'} tone={job.latitude!==undefined&&job.longitude!==undefined?'ok':'warn'}/>}/>
   <Text style={s.meta}>Day Pilot stores a real latitude/longitude after geocoding. Fixed windows can be respected by the advanced optimiser or ignored for a Squeegee-style fastest route.</Text>
   <View style={s.coordRow}><Text style={s.coordText}>{job.latitude!==undefined&&job.longitude!==undefined?job.latitude.toFixed(6)+', '+job.longitude.toFixed(6):'No map coordinates saved yet'}</Text></View>
   {!!job.geocodeLabel&&<Text style={s.meta}>{job.geocodeLabel}</Text>}
   <TouchableOpacity accessibilityRole="switch" accessibilityState={{checked:!!job.fixedAppointment}} onPress={()=>onChange({fixedAppointment:!job.fixedAppointment})} style={[s.toggle,job.fixedAppointment&&s.toggleOn]}><Text style={[s.toggleText,job.fixedAppointment&&s.toggleTextOn]}>Fixed appointment {job.fixedAppointment?'ON':'OFF'}</Text></TouchableOpacity>
   {job.fixedAppointment&&<View style={s.addRow}><TextInput style={[s.input,{flex:1,marginBottom:0}]} value={job.timeWindowStart||''} onChangeText={v=>onChange({timeWindowStart:v})} placeholder="Start e.g. 09:00" accessibilityLabel="Appointment window start"/><TextInput style={[s.input,{flex:1,marginBottom:0}]} value={job.timeWindowEnd||''} onChangeText={v=>onChange({timeWindowEnd:v})} placeholder="End e.g. 10:00" accessibilityLabel="Appointment window end"/></View>}
  </View>

  <View style={s.card}>
   <SectionHeader title="HAZARDS & REQUIRED SKILLS"/>
   <Text style={s.label}>Hazards / risks</Text>
   <TextInput accessibilityLabel="Hazards and risks" style={[s.input,s.multi]} multiline value={job.hazards||''} onChangeText={v=>onChange({hazards:v})} placeholder="Ladders, dog, fragile roof, traffic, locked gate…"/>
   <Text style={s.label}>Required skills</Text>
   <TextInput accessibilityLabel="Required skills" style={s.input} value={(job.requiredSkills||[]).join(', ')} onChangeText={v=>onChange({requiredSkills:v.split(',').map(x=>x.trim()).filter(Boolean)})} placeholder="e.g. WFP, ladder, commercial, MEWP"/>
   <View style={s.chips}>{(job.requiredSkills||[]).map(x=><Chip key={x} label={x.toUpperCase()} tone="info"/>)}</View>
  </View>

  <View style={s.card}>
   <SectionHeader title="CHECKLIST / CUSTOM FORM"/>
   <Text style={s.meta}>Use this for site checks, access steps, completion checks or custom information.</Text>
   {checklist.map(x=><View key={x.id} style={s.row}><TouchableOpacity accessibilityRole="checkbox" accessibilityState={{checked:x.done}} style={{flex:1}} onPress={()=>toggleCheck(x.id)}><Text style={[s.rowTitle,x.done&&s.done]}>{x.done?'✓ ':'○ '}{x.text}</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" onPress={()=>removeCheck(x.id)} style={s.remove}><Text style={s.removeText}>×</Text></TouchableOpacity></View>)}
   <View style={s.addRow}><TextInput style={[s.input,{flex:1,marginBottom:0}]} value={checkText} onChangeText={setCheckText} placeholder="Checklist item"/><TouchableOpacity accessibilityRole="button" style={s.addBtn} onPress={addCheck}><Text style={s.primaryText}>Add</Text></TouchableOpacity></View>
   <View style={{height:14}}/>
   {formFields.map(x=><View key={x.id} style={s.field}><View style={s.fieldTop}><Text style={s.rowTitle}>{x.label}</Text><TouchableOpacity accessibilityRole="button" onPress={()=>removeField(x.id)}><Text style={s.removeText}>Remove</Text></TouchableOpacity></View><TextInput style={[s.input,{marginBottom:0}]} value={x.value} onChangeText={v=>updateField(x.id,v)} placeholder="Value"/></View>)}
   <View style={s.addRow}><TextInput style={[s.input,{flex:1,marginBottom:0}]} value={fieldLabel} onChangeText={setFieldLabel} placeholder="Custom field"/><TextInput style={[s.input,{flex:1,marginBottom:0}]} value={fieldValue} onChangeText={setFieldValue} placeholder="Value"/><TouchableOpacity accessibilityRole="button" style={s.addBtn} onPress={addField}><Text style={s.primaryText}>Add</Text></TouchableOpacity></View>
  </View>

  <View style={s.card}>
   <SectionHeader title="VISIT / JOB HISTORY" right={<Chip label={String((job.visitHistory||[]).length)} tone={(job.visitHistory||[]).length?'info':'grey'}/>}/>
   {(job.visitHistory||[]).length===0?<Text style={s.meta}>No visit events recorded yet. Completing, skipping, reopening or bulk-replanning a job adds an entry here.</Text>:[...(job.visitHistory||[])].reverse().slice(0,30).map(v=><View key={v.id} style={s.row}><View style={{flex:1}}><Text style={s.rowTitle}>{v.status.toUpperCase()}</Text><Text style={s.meta}>{new Date(v.atISO).toLocaleString('en-GB')}{v.worker?' · '+v.worker:''}</Text>{v.note?<Text style={s.meta}>{v.note}</Text>:null}</View></View>)}
  </View>
 </View>;
}

const s=StyleSheet.create({
 card:{backgroundColor:C.card,borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,marginBottom:10},
 meta:{fontSize:11,color:C.muted,lineHeight:16},label:{fontSize:11,fontWeight:'900',color:C.muted,marginTop:10,marginBottom:5},
 input:{backgroundColor:'#f8faf9',borderWidth:1,borderColor:C.line,borderRadius:10,padding:10,fontSize:13,color:C.ink,marginBottom:8},
 multi:{minHeight:70,textAlignVertical:'top'},primary:{backgroundColor:C.accent,borderRadius:10,paddingVertical:10,paddingHorizontal:12,alignItems:'center',marginTop:8},
 primaryText:{color:'#fff',fontWeight:'900',fontSize:12},stop:{backgroundColor:C.dangerSoft,borderRadius:10,paddingVertical:10,paddingHorizontal:12,alignItems:'center',marginTop:8},stopText:{color:C.danger,fontWeight:'900'},
 actions:{alignItems:'stretch'},row:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:10,paddingVertical:9,borderBottomWidth:1,borderBottomColor:C.grey},
 rowTitle:{fontSize:12,fontWeight:'800',color:C.ink},done:{textDecorationLine:'line-through',color:C.muted},remove:{padding:6},removeText:{fontSize:11,fontWeight:'800',color:C.danger},
 addRow:{flexDirection:'row',gap:6,alignItems:'stretch',marginTop:8},addBtn:{backgroundColor:C.brand,borderRadius:10,paddingHorizontal:12,justifyContent:'center'},chips:{flexDirection:'row',flexWrap:'wrap',gap:5},
 field:{marginTop:8},fieldTop:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:4},coordRow:{backgroundColor:'#eef3f2',borderRadius:9,padding:9,marginTop:8},coordText:{fontSize:11,fontWeight:'800',color:C.ink},toggle:{alignSelf:'flex-start',paddingVertical:7,paddingHorizontal:9,borderRadius:9,backgroundColor:'#eef3f2',marginTop:9,borderWidth:1,borderColor:C.line},toggleOn:{backgroundColor:C.brand,borderColor:C.brand},toggleText:{fontSize:10,fontWeight:'900',color:C.muted},toggleTextOn:{color:'#fff'}
});
