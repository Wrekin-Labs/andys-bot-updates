import React,{useState}from'react';
import{Alert,StyleSheet,Text,TextInput,TouchableOpacity,View}from'react-native';
import {useStoredState,asList} from './useStoredState';
import DecimalInput from './DecimalInput';
import {Avatar,C} from './ui';
import {validateProfile,formatSortCode} from '../lib/profile';
import type {BusinessProfile} from '../lib/profile';
import type {TeamRole,TeamUser} from '../lib/types';

// Defined at module level so inputs keep focus across re-renders.
const Field=({label,value,onChange,...rest}:{label:string;value:string;onChange:(v:string)=>void}&Record<string,any>)=><><Text style={s.label}>{label}</Text><TextInput style={s.input} value={value} onChangeText={onChange} accessibilityLabel={label} {...rest}/></>;
const Toggle=({label,on,onPress}:{label:string;on:boolean;onPress:()=>void})=><TouchableOpacity accessibilityRole="switch" accessibilityState={{checked:on}} accessibilityLabel={label} onPress={onPress} style={s.toggleRow}><Text style={s.toggleLabel}>{label}</Text><View style={[s.toggle,on&&s.toggleOn]}><View style={[s.knob,on&&s.knobOn]}/></View></TouchableOpacity>;

export default function TeamSettings({profile,profileError,onProfileChange,users:usersProp,onUsersChange}:{profile:BusinessProfile;profileError?:string;onProfileChange:(p:BusinessProfile)=>void;users?:TeamUser[];onUsersChange?:(users:TeamUser[])=>void}){
 const[storedUsers,setStoredUsers,usersState]=useStoredState<TeamUser[]>('roundflow.users',[{id:'owner',name:profile.name||'Andy',email:'',active:true,roles:['Owner','Administrator','Creator','Planner'],skills:[],dailyCapacityMin:480}],asList);
 const users=usersProp||storedUsers;
 const setUsers:React.Dispatch<React.SetStateAction<TeamUser[]>>=next=>{if(onUsersChange){onUsersChange(typeof next==='function'?(next as (v:TeamUser[])=>TeamUser[])(users):next);}else setStoredUsers(next);};
 const[newName,setNewName]=useState('');const[newEmail,setNewEmail]=useState('');
 const set=(p:Partial<BusinessProfile>)=>onProfileChange({...profile,...p});
 const problems=validateProfile(profile);
 const toggleRole=(id:string,role:TeamRole)=>setUsers(v=>v.map(u=>u.id!==id?u:{...u,roles:u.roles.includes(role)?u.roles.filter(r=>r!==role):[...u.roles,role]}));
 const addUser=()=>{if(!newName.trim()||!newEmail.trim())return Alert.alert('Add user','Enter a name and email address.');setUsers(v=>[...v,{id:Date.now().toString(),name:newName.trim(),email:newEmail.trim(),active:true,roles:['Worker'],skills:[],dailyCapacityMin:480}]);setNewName('');setNewEmail('');};
 const roles:TeamRole[]=['Owner','Administrator','Creator','Planner','Worker'];
 return <View>
  <View style={s.card}><Text accessibilityRole="header" style={s.title}>Business & payment profile</Text><Text style={s.meta}>Shown automatically on invoices, statements, quotes and payment reminders.</Text>
   {!!profileError&&<Text style={s.error}>{profileError}</Text>}
   <Field label="Business / trading name" value={profile.businessName} onChange={v=>set({businessName:v})}/>
   <Field label="Owner / contact name" value={profile.name} onChange={v=>set({name:v})}/>
   <Field label="Phone" value={profile.phone} onChange={v=>set({phone:v})} keyboardType="phone-pad"/>
   <Field label="Email" value={profile.email} onChange={v=>set({email:v})} keyboardType="email-address" autoCapitalize="none"/>
   <Field label="Business address" value={profile.address} onChange={v=>set({address:v})} multiline/>
   <Field label="Industry" value={profile.industry} onChange={v=>set({industry:v})}/>
   <Field label="Employees including yourself" value={profile.employees} onChange={v=>set({employees:v})} keyboardType="number-pad"/>
   <Text style={s.group}>Getting paid</Text>
   <Field label="Bank account name" value={profile.bankAccountName} onChange={v=>set({bankAccountName:v})}/>
   <View style={s.row}><View style={{flex:1}}><Field label="Sort code" value={profile.sortCode} onChange={v=>set({sortCode:v})} onBlur={()=>set({sortCode:formatSortCode(profile.sortCode)})} keyboardType="number-pad" placeholder="12-34-56"/></View><View style={{flex:1.3}}><Field label="Account number" value={profile.accountNumber} onChange={v=>set({accountNumber:v.replace(/[^\d ]/g,'')})} keyboardType="number-pad" placeholder="8 digits"/></View></View>
   <Field label="Payment link (optional, your own e.g. SumUp/PayPal.me)" value={profile.paymentUrl} onChange={v=>set({paymentUrl:v.trim()})} autoCapitalize="none" keyboardType="url" placeholder="https://"/>
   <Text style={s.label}>Default payment terms (days)</Text><DecimalInput style={s.input} value={profile.paymentTermsDays} integer min={0} max={365} commitOnChange={false} onCommit={v=>set({paymentTermsDays:v})} accessibilityLabel="Default payment terms in days"/>
   <Field label="Invoice footer" value={profile.invoiceFooter} onChange={v=>set({invoiceFooter:v})} multiline placeholder="e.g. Thank you for your business. Company no. 01234567"/>
   <Text style={s.group}>Tax</Text>
   <Toggle label="VAT registered" on={profile.vat} onPress={()=>set({vat:!profile.vat})}/>
   {profile.vat&&<><Field label="VAT number" value={profile.vatNumber} onChange={v=>set({vatNumber:v.toUpperCase()})} autoCapitalize="characters" placeholder="GB123456789"/><Text style={s.label}>Default VAT % for new invoices</Text><DecimalInput style={s.input} value={profile.defaultTaxRate} min={0} max={100} commitOnChange={false} onCommit={v=>set({defaultTaxRate:v})} accessibilityLabel="Default VAT percent"/><Text style={s.help}>Job prices are treated as net; VAT is added on the invoice. Invoices are titled "VAT invoice" and show your VAT number. RoundFlow does not file VAT returns.</Text></>}
   <Toggle label="CIS (record only)" on={profile.cis} onPress={()=>set({cis:!profile.cis})}/>
   <Text style={s.help}>RoundFlow does not calculate CIS deductions. Record any deduction as a discount or note and check with your accountant.</Text>
   {problems.length>0&&<View style={s.warnBox}>{problems.map(p=><Text key={p} style={s.warnTxt}>• {p}</Text>)}</View>}
  </View>
  <View style={s.card}><Text accessibilityRole="header" style={s.title}>Users & roles</Text><Text style={s.meta}>Labels on this device only — they do not restrict access until cloud accounts are live.</Text>
   {!!usersState.error&&<Text style={s.error}>{usersState.error}</Text>}
   {users.map(u=><View key={u.id} style={s.userBox}><View style={s.userHead}><Avatar name={u.name} size={38}/><View style={{flex:1}}><Text style={s.userName}>{u.name}</Text><Text style={s.meta}>{u.email||'No email set'}</Text></View><TouchableOpacity accessibilityRole="switch" accessibilityState={{checked:u.active}} onPress={()=>setUsers(v=>v.map(x=>x.id===u.id?{...x,active:!x.active}:x))}><Text style={[s.state,u.active?s.active:s.inactive]}>{u.active?'ACTIVE':'INACTIVE'}</Text></TouchableOpacity></View>
    <View style={s.roles}>{roles.map(r=><TouchableOpacity key={r} accessibilityRole="button" accessibilityState={{selected:u.roles.includes(r)}} onPress={()=>toggleRole(u.id,r)} style={[s.role,u.roles.includes(r)&&s.roleOn]}><Text style={[s.roleTxt,u.roles.includes(r)&&s.roleTxtOn]}>{r}</Text></TouchableOpacity>)}</View>
    <Text style={s.label}>Skills (comma separated)</Text><TextInput style={s.input} value={(u.skills||[]).join(', ')} onChangeText={v=>setUsers(rows=>rows.map(x=>x.id===u.id?{...x,skills:v.split(',').map(s=>s.trim()).filter(Boolean)}:x))} placeholder="WFP, ladder, commercial, MEWP"/>
    <Text style={s.label}>Daily capacity (minutes)</Text><DecimalInput style={s.input} value={u.dailyCapacityMin||480} integer min={30} max={1440} commitOnChange={false} onCommit={v=>setUsers(rows=>rows.map(x=>x.id===u.id?{...x,dailyCapacityMin:v}:x))} accessibilityLabel={u.name+' daily capacity minutes'}/>
    <Text style={s.label}>Default route start address</Text><TextInput style={s.input} value={u.startAddress||''} onChangeText={v=>setUsers(rows=>rows.map(x=>x.id===u.id?{...x,startAddress:v,startLatitude:undefined,startLongitude:undefined}:x))} placeholder="Home / depot / business address" accessibilityLabel={u.name+' route start address'}/>
    <Text style={s.label}>Default route end address</Text><TextInput style={s.input} value={u.endAddress||''} onChangeText={v=>setUsers(rows=>rows.map(x=>x.id===u.id?{...x,endAddress:v,endLatitude:undefined,endLongitude:undefined}:x))} placeholder="Home / depot / business address" accessibilityLabel={u.name+' route end address'}/>
   </View>)}
   <TextInput style={s.input} placeholder="New user name" value={newName} onChangeText={setNewName}/>
   <TextInput style={s.input} placeholder="New user email" autoCapitalize="none" keyboardType="email-address" value={newEmail} onChangeText={setNewEmail}/>
   <TouchableOpacity accessibilityRole="button" style={s.primary} onPress={addUser}><Text style={s.primaryTxt}>Add user</Text></TouchableOpacity>
  </View>
 </View>
}
const s=StyleSheet.create({
 card:{backgroundColor:'#fff',borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,marginBottom:10},
 title:{fontSize:17,fontWeight:'900',color:C.ink},meta:{fontSize:12,color:C.muted,marginTop:3},label:{fontSize:11,fontWeight:'800',color:'#60736e',marginTop:10},input:{backgroundColor:'#f8faf9',borderWidth:1,borderColor:C.line,borderRadius:10,padding:10,marginTop:5,fontSize:14,color:C.ink},row:{flexDirection:'row',gap:8},group:{fontSize:12,fontWeight:'900',color:C.brand,marginTop:16,letterSpacing:0.5},
 toggleRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginTop:12,minHeight:36},toggleLabel:{fontSize:14,fontWeight:'800',color:C.ink},toggle:{width:46,height:26,borderRadius:13,backgroundColor:'#b8c2bf',padding:3},toggleOn:{backgroundColor:C.brand},knob:{width:20,height:20,borderRadius:10,backgroundColor:'#fff'},knobOn:{alignSelf:'flex-end'},help:{fontSize:11,color:C.muted,marginTop:5},
 warnBox:{backgroundColor:C.warnSoft,borderRadius:10,padding:10,marginTop:12},warnTxt:{fontSize:12,color:C.warn,marginTop:2},error:{fontSize:12,color:C.danger,marginTop:8,fontWeight:'700'},
 userBox:{borderTopWidth:1,borderTopColor:'#eef3f2',paddingTop:10,marginTop:10},userHead:{flexDirection:'row',alignItems:'center',gap:8},userName:{fontSize:15,fontWeight:'900',color:C.ink},state:{fontSize:10,fontWeight:'900',padding:6},active:{color:C.brand},inactive:{color:'#9a3d3d'},
 roles:{flexDirection:'row',flexWrap:'wrap',gap:5,marginTop:9},role:{paddingVertical:6,paddingHorizontal:8,borderRadius:7,backgroundColor:'#eef3f2'},roleOn:{backgroundColor:'#5a6066'},roleTxt:{fontSize:10,color:'#50605c'},roleTxtOn:{color:'#fff',fontWeight:'800'},primary:{backgroundColor:C.accent,padding:11,borderRadius:10,alignItems:'center',marginTop:10},primaryTxt:{color:'#fff',fontWeight:'900'}
});
