import React,{useEffect,useMemo,useState} from 'react';
import {Alert,Image,StyleSheet,Text,TextInput,TouchableOpacity,View} from 'react-native';
import {C,Chip} from './ui';
import {formatDistance,formatDuration,furthestByRoad,geocodeAddress,getRoadRoute,hasCoords,liveRoutingReady,mapboxToken as envMapboxToken,mapViewport,missingGeocodes,optimiseMapbox,projectMapPoint,staticMapUrl} from '../lib/routing';
import type {GeoPoint,RouteLeg,RouteMetrics} from '../lib/routing';
import {normalizeClock} from '../lib/routingSettings';
import type {Job} from '../lib/types';

type Props={
 jobs:Job[];startId:string|null;endId:string|null;workerStartAddress?:string;workerEndAddress?:string;
 managedToken?:string;routeStartTime:string;onRouteStartTimeChange:(v:string)=>void;
 onGeocoded:(id:string,patch:Partial<Job>)=>void;onApply:(ids:string[])=>void;onOpenJob:(id:string)=>void;
};

const clockToMin=(v:string)=>{const m=v.match(/^(\d{1,2}):(\d{2})$/);if(!m)return null;const h=Number(m[1]),n=Number(m[2]);return h>=0&&h<24&&n>=0&&n<60?h*60+n:null;};
const minToClock=(v:number)=>{const n=((Math.round(v)%1440)+1440)%1440;return String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0');};
const friendly=(e:any)=>String(e?.message||e||'Routing failed.').replace(/Mapbox/gi,'routing service');

export default function GeoRoutePanel({jobs,startId,endId,workerStartAddress,workerEndAddress,managedToken='',routeStartTime,onRouteStartTimeChange,onGeocoded,onApply,onOpenJob}:Props){
 const[busy,setBusy]=useState(false);
 const[error,setError]=useState('');
 const[geometry,setGeometry]=useState<string|undefined>();
 const[distance,setDistance]=useState(0);
 const[duration,setDuration]=useState(0);
 const[legs,setLegs]=useState<RouteLeg[]>([]);
 const[routeOrderIds,setRouteOrderIds]=useState<string[]>([]);
 const[lastExternalEndpoints,setLastExternalEndpoints]=useState(false);
 const[ignoreTime,setIgnoreTime]=useState(true);
 const[startFurthest,setStartFurthest]=useState(false);
 const[startTimeDraft,setStartTimeDraft]=useState(routeStartTime);
 useEffect(()=>setStartTimeDraft(routeStartTime),[routeStartTime]);
 const[workerStartPoint,setWorkerStartPoint]=useState<GeoPoint|null>(null);
 const[workerEndPoint,setWorkerEndPoint]=useState<GeoPoint|null>(null);
 const effectiveToken=managedToken.trim()||envMapboxToken();
 const live=liveRoutingReady(effectiveToken);
 const missing=useMemo(()=>missingGeocodes(jobs),[jobs]);
 const routeOrderJobs=useMemo(()=>routeOrderIds.length?routeOrderIds.map(id=>jobs.find(j=>j.id===id)).filter(Boolean) as Job[]:jobs,[routeOrderIds,jobs]);
 const allLocated=routeOrderJobs.length>0&&routeOrderJobs.every(hasCoords);
 const viewport=useMemo(()=>allLocated?mapViewport(routeOrderJobs):null,[routeOrderJobs,allLocated]);
 const mapUrl=useMemo(()=>allLocated?staticMapUrl(routeOrderJobs,geometry,effectiveToken):'',[routeOrderJobs,geometry,allLocated,effectiveToken]);
 const areaPalette=['#2563eb','#7c3aed','#db2777','#ea580c','#0891b2','#16a34a','#ca8a04','#dc2626'];
 const pinFill=(j:Job)=>areaPalette[[...(j.area||'Unassigned')].reduce((n,c)=>(n*31+c.charCodeAt(0))>>>0,7)%areaPalette.length];
 const pinBorder=(j:Job)=>j.done?C.accent:j.skipped?'#9aa7a3':j.owing>0?C.danger:C.info;
 const fixed=jobs.filter(j=>j.fixedAppointment);
 const externalEndpointMode=!startId&&!endId&&!!workerStartAddress?.trim()&&!!workerEndAddress?.trim();

 const commitStartTime=()=>{const v=normalizeClock(startTimeDraft);if(!v){Alert.alert('Route start time','Use a valid 24-hour time such as 08:00.');setStartTimeDraft(routeStartTime);return;}setStartTimeDraft(v);onRouteStartTimeChange(v);};
 const pseudoJob=(id:string,name:string,p:GeoPoint):Job=>({id,name,area:'Route endpoint',address:name,price:0,owing:0,freq:'One-off',tags:[],done:false,latitude:p.lat,longitude:p.lng,geocodeProvider:'mapbox',geocodeLabel:p.label});
 const applyMetrics=(m:RouteMetrics,ids:string[],external:boolean)=>{setGeometry(m.geometry);setDistance(m.distanceM);setDuration(m.durationS);setLegs(m.legs||[]);setRouteOrderIds(ids);setLastExternalEndpoints(external);};

 const ensureLocated=async()=>{
  let located=[...jobs];
  for(const j of missing){
   const p=await geocodeAddress((j.address||j.area||'')+', UK',effectiveToken);
   if(!p)throw new Error('No map match for '+j.name+'. Check the customer address.');
   const patch:Partial<Job>={latitude:p.lat,longitude:p.lng,geocodeLabel:p.label,geocodeProvider:'mapbox',geocodedAt:new Date().toISOString()};
   onGeocoded(j.id,patch);
   located=located.map(x=>x.id===j.id?{...x,...patch}:x);
  }
  return located;
 };

 const resolveWorkerEndpoints=async()=>{
  if(!externalEndpointMode)return null;
  let a=workerStartPoint,b=workerEndPoint;
  if(!a){a=await geocodeAddress(workerStartAddress!+', UK',effectiveToken);if(a)setWorkerStartPoint(a);}
  if(!b){b=await geocodeAddress(workerEndAddress!+', UK',effectiveToken);if(b)setWorkerEndPoint(b);}
  return a&&b?{start:a,end:b}:null;
 };

 const preview=async()=>{
  if(!live)return Alert.alert('Live routing not enabled','This build still has local Day Pilot planning and Google Maps navigation. Live road routing will switch on automatically when RoundFlow/Wrekin Labs enables the managed routing service.');
  if(!jobs.length)return Alert.alert('No route','There are no jobs in this Day Pilot view.');
  setBusy(true);setError('');
  try{
   let actual=await ensureLocated();let input=[...actual];let external=false;
   const endpoints=await resolveWorkerEndpoints();
   if(endpoints){external=true;input=[pseudoJob('__start',workerStartAddress!,endpoints.start),...input,pseudoJob('__end',workerEndAddress!,endpoints.end)];}
   const r=await getRoadRoute(input,effectiveToken);
   applyMetrics(r,actual.map(j=>j.id),external);
  }catch(e:any){setError(friendly(e));}
  finally{setBusy(false);}
 };

 const optimise=async()=>{
  if(!live)return Alert.alert('Live routing not enabled','This build still has local Day Pilot planning and Google Maps navigation. Live optimisation will switch on automatically when RoundFlow/Wrekin Labs enables the managed routing service.');
  if(!jobs.length)return Alert.alert('No route','There are no jobs in this Day Pilot view.');
  if(!ignoreTime&&fixed.length)return Alert.alert('Advanced optimiser needed','This day contains fixed appointments. Turn on Ignore time for fastest-road optimisation, or use the advanced RoundFlow routing service for true time-window optimisation.');
  setBusy(true);setError('');
  try{
   let input=await ensureLocated();
   const endpoints=await resolveWorkerEndpoints();
   if(endpoints&&!startId&&!endId){
    if(input.length+2>12)throw new Error('This route is too large for the standard optimiser. RoundFlow advanced routing is required for larger days.');
    const startPseudo=pseudoJob('__start',workerStartAddress!,endpoints.start);
    const endPseudo=pseudoJob('__end',workerEndAddress!,endpoints.end);
    if(startFurthest){
     const farthest=await furthestByRoad(input,endpoints.start,effectiveToken);
     if(farthest){
      const sub=[farthest,...input.filter(j=>j.id!==farthest.id),endPseudo];
      const optimised=await optimiseMapbox(sub,farthest.id,'__end',effectiveToken);
      const actual=optimised.jobs.filter(j=>j.id!=='__end'&&j.id!=='__start');
      const road=await getRoadRoute([startPseudo,...actual,endPseudo],effectiveToken);
      applyMetrics(road,actual.map(j=>j.id),true);onApply(actual.map(j=>j.id));return;
     }
    }
    const optimised=await optimiseMapbox([startPseudo,...input,endPseudo],'__start','__end',effectiveToken);
    const actual=optimised.jobs.filter(j=>j.id!=='__start'&&j.id!=='__end');
    applyMetrics(optimised.metrics,actual.map(j=>j.id),true);onApply(actual.map(j=>j.id));return;
   }
   if(input.length>12)throw new Error('This route is too large for the standard optimiser. RoundFlow advanced routing is required for larger days.');
   if(startFurthest){
    if(!startId)throw new Error('Choose a route start job, or configure the worker start/end addresses.');
    const start=input.find(j=>j.id===startId);
    if(start&&hasCoords(start)){
     const candidates=input.filter(j=>j.id!==start.id);
     const farthest=await furthestByRoad(candidates,{lat:start.latitude!,lng:start.longitude!},effectiveToken);
     if(farthest)input=[farthest,...input.filter(j=>j.id!==farthest.id)];
    }
   }
   const optimised=await optimiseMapbox(input,startFurthest?input[0]?.id:startId,endId,effectiveToken);
   applyMetrics(optimised.metrics,optimised.jobs.map(j=>j.id),false);onApply(optimised.jobs.map(j=>j.id));
  }catch(e:any){setError(friendly(e));}
  finally{setBusy(false);}
 };

 const schedule=useMemo(()=>{
  const start=clockToMin(routeStartTime);if(start===null||!legs.length||!routeOrderJobs.length)return[] as {job:Job;eta:string;drive:number;wait:number;late:boolean}[];
  let t=start;
  return routeOrderJobs.map((j,idx)=>{
   const legIndex=lastExternalEndpoints?idx:(idx===0?-1:idx-1);
   const drive=legIndex>=0&&legs[legIndex]?Math.round(legs[legIndex].durationS/60):0;
   t+=drive;let wait=0,late=false;
   if(!ignoreTime&&j.fixedAppointment){
    const ws=clockToMin(j.timeWindowStart||'');const we=clockToMin(j.timeWindowEnd||'');
    if(ws!==null&&t<ws){wait=ws-t;t=ws;}
    if(we!==null&&t>we)late=true;
   }
   const eta=minToClock(t);t+=j.durationMin||30;
   return{job:j,eta,drive,wait,late};
  });
 },[routeOrderJobs,legs,routeStartTime,lastExternalEndpoints,ignoreTime]);
 const finalReturn=lastExternalEndpoints&&legs.length>routeOrderJobs.length?legs[legs.length-1]:undefined;

 return <View style={s.card}>
  <View style={s.head}><View style={{flex:1}}><Text style={s.title}>ROUNDFLOW ROUTING</Text><Text style={s.sub}>Managed road planning and navigation</Text></View><Chip label={live?'LIVE READY':'LOCAL MODE'} tone={live?'ok':'grey'}/></View>
  <Text style={s.note}>{live?'No mapping setup is required. Missing customer locations are prepared automatically when you preview or optimise the route.':'Local Day Pilot planning and Google Maps navigation are ready. Live road maps, mileage and ETAs will enable automatically when the managed routing service is connected.'}</Text>
  {jobs.length>0&&<><View style={s.startRow}><View style={{flex:1}}><Text style={s.smallLabel}>ROUTE START TIME</Text><TextInput style={s.timeInput} value={startTimeDraft} onChangeText={setStartTimeDraft} onBlur={commitStartTime} placeholder="08:00" accessibilityLabel="Route start time"/></View><View style={{flex:2}}><Text style={s.smallLabel}>PLANNING OPTIONS</Text><View style={s.opts}><TouchableOpacity accessibilityRole="switch" accessibilityState={{checked:ignoreTime}} onPress={()=>setIgnoreTime(v=>!v)} style={[s.opt,ignoreTime&&s.optOn]}><Text style={[s.optText,ignoreTime&&s.optTextOn]}>Ignore time {ignoreTime?'ON':'OFF'}</Text></TouchableOpacity><TouchableOpacity accessibilityRole="switch" accessibilityState={{checked:startFurthest}} onPress={()=>setStartFurthest(v=>!v)} style={[s.opt,startFurthest&&s.optOn]}><Text style={[s.optText,startFurthest&&s.optTextOn]}>Start furthest {startFurthest?'ON':'OFF'}</Text></TouchableOpacity></View></View></View>
  {fixed.length>0&&<Text style={s.note}>{fixed.length} fixed appointment{fixed.length===1?'':'s'} on this route. With Ignore time OFF, ETA preview honours windows and flags lateness.</Text>}
  <View style={s.buttons}><TouchableOpacity accessibilityRole="button" style={s.secondary} disabled={busy} onPress={preview}><Text style={s.secondaryText}>{busy?'Preparing…':'Road preview'}</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" style={s.primary} disabled={busy} onPress={optimise}><Text style={s.primaryText}>{busy?'Preparing…':'Optimise road order'}</Text></TouchableOpacity></View></>}
  {!!error&&<Text style={s.error}>{error}</Text>}
  {!!mapUrl&&<View style={s.mapWrap}><Image source={{uri:mapUrl}} resizeMode="cover" style={s.map} accessibilityLabel="Real geographic route map"/>{viewport&&routeOrderJobs.map((j,i)=>{const p=projectMapPoint(j.latitude!,j.longitude!,viewport);const left=(p.x/viewport.width*100)+'%';const top=(p.y/viewport.height*100)+'%';return <TouchableOpacity key={j.id} accessibilityRole="button" accessibilityLabel={'Stop '+(i+1)+' '+j.name} onPress={()=>onOpenJob(j.id)} style={[s.livePin,{left:left as any,top:top as any,backgroundColor:pinFill(j),borderColor:pinBorder(j)}]}><Text style={s.livePinText}>{i+1}</Text></TouchableOpacity>})}</View>}
  {(distance>0||duration>0)&&<View style={s.metrics}><View><Text style={s.metric}>{formatDistance(distance)}</Text><Text style={s.metricLabel}>ROAD DISTANCE</Text></View><View><Text style={s.metric}>{formatDuration(duration)}</Text><Text style={s.metricLabel}>DRIVE TIME</Text></View><View><Text style={s.metric}>{routeOrderJobs.length}</Text><Text style={s.metricLabel}>STOPS</Text></View></View>}
  {schedule.length>0&&<View style={s.schedule}><Text style={s.scheduleTitle}>STOP ETA / DRIVE</Text>{schedule.map((x,i)=><View key={x.job.id} style={s.scheduleRow}><View style={s.no}><Text style={s.noText}>{i+1}</Text></View><View style={{flex:1,minWidth:0}}><Text numberOfLines={1} style={s.stopName}>{x.job.name}</Text><Text style={s.stopMeta}>{x.drive?x.drive+'m drive':'route start'}{x.wait?' · '+x.wait+'m wait':''}{x.job.fixedAppointment?' · fixed '+(x.job.timeWindowStart||'?')+'–'+(x.job.timeWindowEnd||'?'):''}</Text></View><Text style={[s.eta,x.late&&s.late]}>{x.late?'LATE ':''}{x.eta}</Text></View>)}{finalReturn&&<Text style={s.returnText}>After last job: {Math.round(finalReturn.durationS/60)}m drive to route end.</Text>}</View>}
  <Text style={s.footer}>Live road metrics and ETAs are calculated by RoundFlow's managed routing service. Local route planning continues to work without it.</Text>
 </View>;
}

const s=StyleSheet.create({
 card:{backgroundColor:'#071322',borderRadius:14,padding:12,borderWidth:1,borderColor:'#20334d',marginTop:10},head:{flexDirection:'row',gap:8,alignItems:'center'},title:{color:'#fff',fontSize:13,fontWeight:'900',letterSpacing:.6},sub:{color:'#9eb2c9',fontSize:10.5,marginTop:2},note:{fontSize:10.5,color:'#9eb2c9',lineHeight:15,marginTop:9},startRow:{flexDirection:'row',gap:8,marginTop:10,alignItems:'flex-start'},smallLabel:{fontSize:8.5,fontWeight:'900',color:'#7890a8',marginBottom:4},timeInput:{backgroundColor:'#102137',borderWidth:1,borderColor:'#29405e',borderRadius:9,padding:8,color:'#fff',fontWeight:'900',fontSize:12},opts:{flexDirection:'row',flexWrap:'wrap',gap:6},opt:{paddingVertical:7,paddingHorizontal:9,borderRadius:9,backgroundColor:'#13243b',borderWidth:1,borderColor:'#29405e'},optOn:{backgroundColor:'#0b6b57',borderColor:'#19a37f'},optText:{fontSize:10,fontWeight:'900',color:'#aebed0'},optTextOn:{color:'#fff'},buttons:{flexDirection:'row',gap:7,marginTop:10},secondary:{flex:1,backgroundColor:'#18304b',padding:10,borderRadius:10,alignItems:'center'},secondaryText:{color:'#dce8f5',fontWeight:'900',fontSize:11},primary:{flex:1.2,backgroundColor:C.accent,padding:10,borderRadius:10,alignItems:'center'},primaryText:{color:'#fff',fontWeight:'900',fontSize:11},error:{color:'#ff9da5',fontSize:11,marginTop:9},mapWrap:{width:'100%',aspectRatio:700/420,borderRadius:12,marginTop:10,overflow:'hidden',position:'relative',backgroundColor:'#102137'},map:{width:'100%',height:'100%',backgroundColor:'#102137'},livePin:{position:'absolute',width:34,height:34,borderRadius:17,marginLeft:-17,marginTop:-17,alignItems:'center',justifyContent:'center',borderWidth:3,elevation:5},livePinText:{color:'#fff',fontSize:11,fontWeight:'900'},metrics:{flexDirection:'row',gap:18,marginTop:10},metric:{color:'#fff',fontSize:17,fontWeight:'900'},metricLabel:{color:'#8fa5ba',fontSize:8.5,fontWeight:'900',letterSpacing:.5},schedule:{marginTop:12,borderTopWidth:1,borderTopColor:'#20334d',paddingTop:9},scheduleTitle:{fontSize:9,fontWeight:'900',color:'#7890a8',letterSpacing:.7,marginBottom:4},scheduleRow:{flexDirection:'row',alignItems:'center',gap:8,paddingVertical:7,borderBottomWidth:1,borderBottomColor:'#12243b'},no:{width:24,height:24,borderRadius:12,backgroundColor:'#173151',alignItems:'center',justifyContent:'center'},noText:{color:'#fff',fontSize:10,fontWeight:'900'},stopName:{fontSize:11.5,fontWeight:'900',color:'#eef6ff'},stopMeta:{fontSize:9.5,color:'#8fa5ba',marginTop:2},eta:{fontSize:12,fontWeight:'900',color:'#7fe0bd'},late:{color:'#ff8b95'},returnText:{fontSize:10,color:'#9eb2c9',marginTop:8},footer:{fontSize:9.5,color:'#7890a8',lineHeight:13,marginTop:9}
});
