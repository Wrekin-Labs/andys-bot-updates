import React from'react';
import{Alert,StyleSheet,Text,TouchableOpacity,View}from'react-native';
import*as DocumentPicker from'expo-document-picker';
import*as Sharing from'expo-sharing';
import{cacheDirectory,EncodingType,readAsStringAsync,writeAsStringAsync}from'expo-file-system/legacy';
import{parseCsv,csvCell,parseFrequency}from'../lib/csv';
import{isISODate}from'../lib/dates';
import{newId}from'../lib/ledger';
import type{Job}from'../lib/types';

export default function DataTransfer({jobs,onImport}:{jobs:Job[];onImport:(fresh:Job[])=>void}){
 const importCsv=async()=>{
  try{
   const res=await DocumentPicker.getDocumentAsync({type:['text/csv','text/comma-separated-values','text/plain'],copyToCacheDirectory:true});
   if(res.canceled)return;
   const text=await readAsStringAsync(res.assets[0].uri,{encoding:EncodingType.UTF8});
   const records=parseCsv(text.replace(/^﻿/,''));if(records.length<2)throw new Error('CSV has no rows');
   const heads=records[0].map(x=>x.trim().toLowerCase());
   const col=(names:string[])=>heads.findIndex(h=>names.includes(h));
   const ix={name:col(['name','customer','customer name']),area:col(['area','town','round','postcode']),address:col(['address','full address']),phone:col(['phone','mobile','telephone']),email:col(['email','email address','e-mail']),notes:col(['notes','access notes']),price:col(['price','amount','job price']),freq:col(['frequency','frequency weeks','freq']),owing:col(['owing','balance','outstanding']),service:col(['service']),worker:col(['worker','assigned worker']),next:col(['next visit','next due','due date'])};
   if(ix.name<0)throw new Error('Could not find a Name/Customer column');
   // Undo the formula-injection guard RoundFlow adds on export.
   const imported:Job[]=records.slice(1).map((c,n)=>{const val=(i:number)=>i>=0?(c[i]??'').trim().replace(/^'(?=[=+\-@\t\r])/,''):'';const rawPrice=val(ix.price);const rawOwing=val(ix.owing);const parsedPrice=rawPrice===''?0:Number(rawPrice.replace(/[^0-9.-]/g,''));const parsedOwing=rawOwing===''?0:Number(rawOwing.replace(/[^0-9.-]/g,''));if(rawPrice!==''&&(!Number.isFinite(parsedPrice)||parsedPrice<0))throw new Error('Invalid price on CSV row '+(n+2));if(rawOwing!==''&&(!Number.isFinite(parsedOwing)||parsedOwing<0))throw new Error('Invalid balance on CSV row '+(n+2));const next=val(ix.next);return{id:newId('csv'),name:val(ix.name),area:val(ix.area)||'Unassigned',address:val(ix.address),phone:val(ix.phone),email:val(ix.email),notes:val(ix.notes),price:Math.round(parsedPrice*100)/100,owing:Math.round(parsedOwing*100)/100,freq:parseFrequency(val(ix.freq)),tags:['Imported'],done:false,service:val(ix.service)||undefined,worker:val(ix.worker)||undefined,dueDate:isISODate(next)?next:undefined};}).filter(x=>x.name);
   if(!imported.length)throw new Error('No customer rows found');
   const norm=(v?:string)=>String(v||'').trim().toLowerCase().replace(/\s+/g,' ');const keys=new Set(jobs.map(j=>[norm(j.name),norm(j.address||j.area),norm(j.phone)].join('|')));const fresh:Job[]=[];let skipped=0;for(const j of imported){const key=[norm(j.name),norm(j.address||j.area),norm(j.phone)].join('|');if(keys.has(key)){skipped++;continue;}keys.add(key);fresh.push(j);}if(!fresh.length)throw new Error('All imported rows already exist');
   const opening=fresh.reduce((a,j)=>a+j.owing,0);const oneOff=fresh.filter(j=>j.freq==='One-off').length;
   Alert.alert('Import customers',fresh.length+' new rows found'+(skipped?' ('+skipped+' duplicates skipped)':'')+'.'+(opening?` Balances totalling £${opening.toFixed(2)} will be recorded as opening balances.`:'')+(oneOff?` ${oneOff} one-off.`:'')+' Add them to RoundFlow?',[{text:'Cancel',style:'cancel'},{text:'Import',onPress:()=>onImport(fresh)}]);
  }catch(e:any){Alert.alert('Import failed',e?.message||String(e));}
 };
 const exportCsv=async()=>{
  try{
   const head=['Name','Area','Address','Phone','Email','Notes','Price','Frequency','Owing','Service','Worker','Next visit','Status'];
   const rows=jobs.map(j=>[j.name,j.area,j.address,j.phone,j.email,j.notes,j.price,j.freq,j.owing,j.service,j.worker,j.dueDate,j.archived?'Archived':j.paused?'Paused':'Active'].map(csvCell).join(','));
   const csv='﻿'+head.join(',')+'\r\n'+rows.join('\r\n');
   const path=(cacheDirectory||'')+'roundflow-customers.csv';
   await writeAsStringAsync(path,csv,{encoding:EncodingType.UTF8});
   if(await Sharing.isAvailableAsync())await Sharing.shareAsync(path,{mimeType:'text/csv',dialogTitle:'Export RoundFlow customers'});else Alert.alert('Export ready',path);
  }catch(e:any){Alert.alert('Export failed',e?.message||String(e));}
 };
 return <View style={s.box}><Text style={s.title}>Import / Export</Text><Text style={s.muted}>Import spreadsheet CSV data (e.g. exported from another round app). Maps customer, address, phone, email, price, frequency, balance, service, worker and next-visit columns, keeps one-off work one-off, and skips likely duplicates.</Text><View style={s.row}><TouchableOpacity accessibilityRole="button" style={s.btn} onPress={importCsv}><Text style={s.btnText}>Import CSV</Text></TouchableOpacity><TouchableOpacity accessibilityRole="button" style={s.btn} onPress={exportCsv}><Text style={s.btnText}>Export CSV</Text></TouchableOpacity></View></View>;
}
const s=StyleSheet.create({box:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:16,padding:14,marginBottom:10},title:{fontSize:16,fontWeight:'800',color:'#15302a',marginBottom:6},muted:{fontSize:12,color:'#5f6f6b'},row:{flexDirection:'row',gap:8,marginTop:12},btn:{flex:1,backgroundColor:'#eef3f2',padding:12,borderRadius:12,alignItems:'center'},btnText:{fontWeight:'800',color:'#15302a'}});
