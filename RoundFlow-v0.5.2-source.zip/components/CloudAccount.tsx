import React,{useEffect,useState}from'react';
import{Alert,StyleSheet,Text,TextInput,TouchableOpacity,View}from'react-native';
import type{Session}from'@supabase/supabase-js';
import{cloudConfigured,supabase}from'../lib/supabase';

export default function CloudAccount(){
 const[session,setSession]=useState<Session|null>(null);
 const[email,setEmail]=useState('');const[password,setPassword]=useState('');const[busy,setBusy]=useState(false);
 useEffect(()=>{if(!supabase)return;supabase.auth.getSession().then(({data})=>setSession(data.session));const{data}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));return()=>data.subscription.unsubscribe();},[]);
 if(!cloudConfigured)return <View style={s.box}><Text style={s.title}>Cloud account</Text><Text style={s.muted}>Backend is ready to connect. A dedicated RoundFlow Supabase project still needs to be created and linked.</Text></View>;
 const signIn=async()=>{if(!supabase)return;setBusy(true);const{error}=await supabase.auth.signInWithPassword({email,password});setBusy(false);if(error)Alert.alert('Sign in failed',error.message);};
 const signUp=async()=>{if(!supabase)return;setBusy(true);const{error}=await supabase.auth.signUp({email,password});setBusy(false);if(error)Alert.alert('Sign up failed',error.message);else Alert.alert('Account created','Check your email if confirmation is enabled.');};
 const signOut=()=>supabase?.auth.signOut();
 if(session)return <View style={s.box}><Text style={s.title}>Cloud account</Text><Text style={s.good}>Signed in</Text><Text style={s.muted}>{session.user.email}</Text><TouchableOpacity style={s.btn} onPress={signOut}><Text style={s.btnText}>Sign out</Text></TouchableOpacity></View>;
 return <View style={s.box}><Text style={s.title}>Cloud account</Text><TextInput style={s.input} autoCapitalize="none" keyboardType="email-address" placeholder="Email" value={email} onChangeText={setEmail}/><TextInput style={s.input} autoCapitalize="none" secureTextEntry placeholder="Password" value={password} onChangeText={setPassword}/><TouchableOpacity style={s.primary} disabled={busy} onPress={signIn}><Text style={s.primaryText}>{busy?'Please wait…':'Sign in'}</Text></TouchableOpacity><TouchableOpacity style={s.btn} disabled={busy} onPress={signUp}><Text style={s.btnText}>Create account</Text></TouchableOpacity></View>;
}
const s=StyleSheet.create({box:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:16,padding:14,marginBottom:10},title:{fontSize:16,fontWeight:'800',color:'#15302a',marginBottom:8},muted:{fontSize:12,color:'#6f7f7b'},good:{fontSize:12,fontWeight:'800',color:'#0b6b57',marginBottom:4},input:{borderWidth:1,borderColor:'#dfe7e4',borderRadius:12,padding:12,marginBottom:10},primary:{backgroundColor:'#19a37f',padding:12,borderRadius:12,alignItems:'center',marginBottom:8},primaryText:{color:'#fff',fontWeight:'800'},btn:{backgroundColor:'#eef3f2',padding:12,borderRadius:12,alignItems:'center',marginTop:8},btnText:{fontWeight:'800',color:'#15302a'}});
