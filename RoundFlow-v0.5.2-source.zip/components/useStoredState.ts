import {useEffect, useRef, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * AsyncStorage-backed state that never overwrites data it could not read.
 * v0.3.1 components fell back to defaults on a parse error and then saved those
 * defaults over the user's stored data; here saving stays disabled until the
 * stored value has been read successfully (or did not exist).
 */
export function useStoredState<T>(key: string, initial: T, parse: (raw: unknown) => T, generation = 0) {
  const [value, setValue] = useState<T>(initial);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState('');
  const writable = useRef(false);
  const parseRef = useRef(parse);
  const initialRef = useRef(initial);
  useEffect(() => {
    let active = true;
    writable.current = false;
    setLoaded(false);
    setError('');
    AsyncStorage.getItem(key).then(raw => {
      if (!active) return;
      setValue(raw != null ? parseRef.current(JSON.parse(raw)) : initialRef.current);
      writable.current = true;
      setLoaded(true);
    }).catch((e: any) => {
      if (!active) return;
      setError((e?.message || 'Unreadable data') + ' — stored data was left untouched. Restore a backup to recover it.');
      setLoaded(true);
    });
    return () => { active = false; };
  }, [key, generation]);
  useEffect(() => {
    if (!loaded || !writable.current) return;
    AsyncStorage.setItem(key, JSON.stringify(value)).then(() => setError(e => e.startsWith('Could not save') ? '' : e)).catch(() => setError('Could not save ' + key.replace('roundflow.', '') + ' changes. Free device storage and try again.'));
  }, [key, value, loaded]);
  return [value, setValue, {loaded, error, writable: writable.current}] as const;
}

export const asList = <T,>(raw: unknown): T[] => {
  if (!Array.isArray(raw)) throw new Error('Stored list is not valid');
  return raw as T[];
};
