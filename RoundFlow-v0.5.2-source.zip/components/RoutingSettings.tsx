import React,{useEffect,useMemo,useState} from 'react';
import {Alert,StyleSheet,Text,TextInput,View} from 'react-native';
import {C,Chip,SectionHeader} from './ui';
import {liveRoutingReady,mapboxToken as envMapboxToken,missingGeocodes} from '../lib/routing';
import {normalizeClock} from '../lib/routingSettings';
import type {RoutingSettings as RoutingSettingsType} from '../lib/routingSettings';
import type {Job} from '../lib/types';

export default function RoutingSettings({settings,onChange,jobs}:{settings:RoutingSettingsType;onChange:(v:RoutingSettingsType)=>void;jobs:Job[]}){
 const[timeDraft,setTimeDraft]=useState(settings.defaultRouteStartTime);
 useEffect(()=>setTimeDraft(settings.defaultRouteStartTime),[settings.defaultRouteStartTime]);
 const effectiveToken=settings.mapboxToken.trim()||envMapboxToken();
 const live=liveRoutingReady(effectiveToken);
 const unpinned=useMemo(()=>missingGeocodes(jobs.filter(j=>!j.archived)),[jobs]);
 const located=jobs.filter(j=>!j.archived&&j.latitude!==undefined&&j.longitude!==undefined).length;
 const commitTime=()=>{const v=normalizeClock(timeDraft);if(!v){Alert.alert('Route start time','Use a valid 24-hour time such as 08:00.');setTimeDraft(settings.defaultRouteStartTime);return;}setTimeDraft(v);onChange({...settings,defaultRouteStartTime:v});};

 return <View style={s.card}>
  <SectionHeader title="ROUTING" right={<Chip label={live?'LIVE READY':'LOCAL MODE'} tone={live?'ok':'grey'}/>}/>
  <Text style={s.meta}>Routing is managed by RoundFlow. Cleaners do not need a mapping account, API key or provider setup.</Text>
  <View style={s.statusBox}><Text style={s.statusTitle}>{live?'Live road routing ready':'Local routing ready'}</Text><Text style={s.statusText}>{live?'Addresses are located automatically when needed. Road distance, drive time, ETAs and route optimisation are available from Day Pilot.':'Day Pilot, area planning and Google Maps navigation still work. Live road maps and ETAs will switch on automatically when this RoundFlow build is connected to the managed routing service.'}</Text></View>
  <Text style={s.label}>Default route start time</Text>
  <TextInput style={s.input} value={timeDraft} onChangeText={setTimeDraft} onBlur={commitTime} placeholder="08:00" keyboardType="numbers-and-punctuation" accessibilityLabel="Default route start time"/>
  <View style={s.summary}><Text style={s.summaryStrong}>{located}</Text><Text style={s.summaryText}> located customers</Text><Text style={s.summaryStrong}> · {unpinned.length}</Text><Text style={s.summaryText}> will be located automatically when routing needs them</Text></View>
  <Text style={s.help}>Provider credentials are controlled by RoundFlow/Wrekin Labs and are not shown to cleaners.</Text>
 </View>;
}

const s=StyleSheet.create({
 card:{backgroundColor:C.card,borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,marginBottom:10},
 meta:{fontSize:11,color:C.muted,lineHeight:16},label:{fontSize:11,fontWeight:'900',color:C.muted,marginTop:10,marginBottom:5},
 input:{backgroundColor:'#f8faf9',borderWidth:1,borderColor:C.line,borderRadius:10,padding:10,fontSize:13,color:C.ink,marginBottom:4},
 statusBox:{backgroundColor:'#f8faf9',borderWidth:1,borderColor:C.line,borderRadius:10,padding:10,marginTop:10},
 statusTitle:{fontSize:12,fontWeight:'900',color:C.ink},statusText:{fontSize:10.5,color:C.muted,lineHeight:15,marginTop:3},
 help:{fontSize:10.5,color:C.muted,lineHeight:15,marginTop:9},summary:{flexDirection:'row',flexWrap:'wrap',marginTop:10,alignItems:'center'},summaryStrong:{fontSize:12,fontWeight:'900',color:C.ink},summaryText:{fontSize:11,color:C.muted}
});
