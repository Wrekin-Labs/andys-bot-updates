import React,{useEffect,useMemo,useState}from'react';
import{Alert,StyleSheet,Text,TouchableOpacity,View}from'react-native';
import AsyncStorage from'@react-native-async-storage/async-storage';
import * as Print from'expo-print';
import * as Sharing from'expo-sharing';
import {buildReport} from '../lib/reports';
import {businessHeader,esc,PDF_STYLE} from '../lib/invoiceHtml';
import {displayDate} from '../lib/dates';
import type {Expense,Invoice,Job} from '../lib/types';
import {BarChart,C,SectionHeader,Segmented,StatCard,Avatar} from './ui';

const money=(n:number)=>'£'+n.toFixed(2);
const short=(n:number)=>Math.abs(n)>=1000?'£'+(n/1000).toFixed(1)+'k':'£'+Math.round(n);
const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const monthLabel=(m:string)=>MONTHS[Number(m.slice(5,7))-1]||m;
const lastMonths=(today:string,n:number)=>{const y=Number(today.slice(0,4)),m=Number(today.slice(5,7));return Array.from({length:n},(_,i)=>{const d=new Date(y,m-1-(n-1-i),1);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');});};

/** Business insights dashboard: revenue, outstanding, overdue, aged debt, workers, round value. */
export default function Insights({jobs,invoices,today,profile,expenses:expensesProp,onOpenOverdue,onOpenCustomer}:{jobs:Job[];invoices:Invoice[];today:string;profile:unknown;expenses?:Expense[];onOpenOverdue?:()=>void;onOpenCustomer?:(id:string)=>void}){
 const[stored,setStored]=useState<Expense[]>([]);
 const[metric,setMetric]=useState<'received'|'invoiced'|'net'>('received');
 useEffect(()=>{if(expensesProp)return;AsyncStorage.getItem('roundflow.expenses').then(v=>{const p=v?JSON.parse(v):[];if(Array.isArray(p))setStored(p);}).catch(()=>{});},[expensesProp]);
 const expenses=expensesProp||stored;
 const r=useMemo(()=>buildReport({jobs,invoices,expenses,today}),[jobs,invoices,expenses,today]);
 const months=lastMonths(today,6);
 const chart=months.map(m=>{const row=r.monthly.find(x=>x.month===m);return{label:monthLabel(m),value:row?row[metric]:0};});
 const thisMonth=r.monthly.find(x=>x.month===today.slice(0,7));
 const shareReport=async()=>{try{
  const rows=r.monthly.slice(0,12).map(m=>`<tr><td>${esc(m.month)}</td><td class="r">${money(m.invoiced)}</td><td class="r">${money(m.received)}</td><td class="r">${money(m.expenses)}</td><td class="r">${money(m.net)}</td></tr>`).join('');
  const html=`<!doctype html><html><head><meta charset="utf-8"><style>${PDF_STYLE}.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}.box{border:1px solid #dfe7e4;border-radius:10px;padding:12px}.big{font-size:20px;font-weight:700}</style></head><body><header>${businessHeader(profile)}<div class="r"><b>BUSINESS REPORT</b><p>${esc(displayDate(today))}</p></div></header><div class="grid"><div class="box">Received<div class="big">${money(r.received)}</div></div><div class="box">Expenses<div class="big">${money(r.expenses)}</div></div><div class="box">Net<div class="big">${money(r.net)}</div></div><div class="box">Outstanding<div class="big">${money(r.outstanding)}</div></div><div class="box">Overdue (${r.overdueCount})<div class="big">${money(r.overdue)}</div></div><div class="box">Monthly round value<div class="big">${money(r.round.monthlyRoundValue)}</div></div></div><h3>By month</h3><table><tr><th>Month</th><th class="r">Invoiced</th><th class="r">Received</th><th class="r">Expenses</th><th class="r">Net</th></tr>${rows}</table><h3>Aged debt</h3><p>Current ${money(r.aged.current)} · 1–30 days ${money(r.aged.d1_30)} · 31–60 ${money(r.aged.d31_60)} · 61–90 ${money(r.aged.d61_90)} · 90+ ${money(r.aged.d90plus)}</p><h3>Workers</h3><p>${r.workers.map(w=>`${esc(w.worker)}: ${w.visits} invoices, ${money(w.invoiced)} invoiced, ${money(w.collected)} collected`).join('<br>')||'—'}</p><p class="muted">Management figures from RoundFlow records (cash basis for income). Not statutory accounts or a tax return.</p></body></html>`;
  const out=await Print.printToFileAsync({html});if(await Sharing.isAvailableAsync())await Sharing.shareAsync(out.uri,{mimeType:'application/pdf',dialogTitle:'RoundFlow business report'});else Alert.alert('Report created',out.uri);
 }catch(e:any){Alert.alert('Report failed',e?.message||String(e));}};

 return <View>
  <View style={s.row}><StatCard label="Total received" value={money(r.received)} sub={thisMonth?'This month '+money(thisMonth.received):'This month £0.00'} tone="ok"/><StatCard label="Jobs invoiced" value={String(r.workers.reduce((a,w)=>a+w.visits,0))} sub={r.round.activeCustomers+' active customers'} tone="info"/></View>
  <View style={s.row}><StatCard label="Outstanding" value={money(r.outstanding)} sub={money(r.outstandingInvoices)+' on invoices'} tone="warn"/><StatCard label="Overdue" value={money(r.overdue)} sub={r.overdueCount+' invoice'+(r.overdueCount===1?'':'s')} tone={r.overdueCount?'danger':'grey'} onPress={onOpenOverdue}/></View>
  <View style={s.card}><SectionHeader title="LAST 6 MONTHS"/><Segmented options={[['received','Received'],['invoiced','Invoiced'],['net','Net']] as const} value={metric} onChange={setMetric}/><View style={{height:12}}/><BarChart data={chart} format={short}/></View>
  <View style={s.row}><StatCard label="Expenses" value={money(r.expenses)} tone="grey"/><StatCard label="Net (received − expenses)" value={money(r.net)} tone={r.net<0?'danger':'ok'}/></View>
  <View style={s.card}><SectionHeader title="AGED DEBT"/>{([['Not yet due',r.aged.current],['1–30 days',r.aged.d1_30],['31–60 days',r.aged.d31_60],['61–90 days',r.aged.d61_90],['90+ days',r.aged.d90plus]] as const).map(([l,v])=><View key={l} style={s.line}><Text style={s.meta}>{l}</Text><Text style={[s.val,v>0&&l!=='Not yet due'&&{color:C.danger}]}>{money(v)}</Text></View>)}</View>
  {r.topBalances.length>0&&<View style={s.card}><SectionHeader title="HIGHEST BALANCES"/>{r.topBalances.slice(0,5).map(b=><TouchableOpacity key={b.id} accessibilityRole="button" disabled={!onOpenCustomer} onPress={()=>onOpenCustomer?.(b.id)} style={s.custRow}><Avatar name={b.name} size={30}/><Text style={[s.val,{flex:1,fontWeight:'700'}]} numberOfLines={1}>{b.name}{b.archived?' (archived)':''}</Text><Text style={[s.val,{color:C.danger}]}>{money(b.owing)}</Text></TouchableOpacity>)}</View>}
  <View style={s.card}><SectionHeader title="ROUND"/><View style={s.line}><Text style={s.meta}>Monthly recurring value</Text><Text style={s.val}>{money(r.round.monthlyRoundValue)}</Text></View><View style={s.line}><Text style={s.meta}>Recurring / one-off / paused</Text><Text style={s.val}>{r.round.recurring} / {r.round.oneOff} / {r.round.paused}</Text></View><View style={s.line}><Text style={s.meta}>Average job price</Text><Text style={s.val}>{money(r.round.averagePrice)}</Text></View></View>
  {r.workers.length>0&&<View style={s.card}><SectionHeader title="WORKERS"/>{r.workers.map(w=><View key={w.worker} style={s.line}><Text style={s.meta}>{w.worker} · {w.visits} invoices</Text><Text style={s.val}>{money(w.invoiced)} · {money(w.collected)} paid</Text></View>)}</View>}
  <TouchableOpacity accessibilityRole="button" style={s.btn} onPress={shareReport}><Text style={s.btnTxt}>PDF business report</Text></TouchableOpacity>
  <Text style={s.note}>Management figures only (income counted when payment is recorded). Not statutory accounts, a VAT return or Making Tax Digital filing.</Text>
 </View>;
}
const s=StyleSheet.create({row:{flexDirection:'row',gap:8,marginBottom:8},card:{backgroundColor:'#fff',borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,marginBottom:8},line:{flexDirection:'row',justifyContent:'space-between',paddingVertical:7,borderBottomWidth:1,borderBottomColor:'#eef3f2',gap:8},meta:{fontSize:12,color:C.muted,flexShrink:1},val:{fontSize:13,fontWeight:'900',color:C.ink},custRow:{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:6},btn:{backgroundColor:C.accent,padding:12,borderRadius:12,alignItems:'center',marginTop:4},btnTxt:{color:'#fff',fontWeight:'900'},note:{fontSize:11,color:C.muted,marginTop:8,marginBottom:12}});
