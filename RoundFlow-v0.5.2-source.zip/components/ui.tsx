import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import type {StyleProp, ViewStyle} from 'react-native';

/** RoundFlow design tokens (own palette; deep teal + clear status colours). */
export const C = {
  brand: '#0b6b57', brandDark: '#084f41', brandSoft: '#e6f4ef', accent: '#19a37f',
  ink: '#15302a', muted: '#5f6f6b', line: '#dfe7e4', bg: '#f4f7f6', card: '#ffffff',
  danger: '#b42323', dangerSoft: '#fdecec', warn: '#8a6200', warnSoft: '#fff4d6',
  info: '#2f5f98', infoSoft: '#e8f0fb', ok: '#0b6b57', okSoft: '#e2f5ec', grey: '#eef3f2',
};

const AVATAR = ['#0b6b57', '#2f5f98', '#7655c8', '#b0533a', '#a1306b', '#3d7d2a', '#8a6200', '#3b6e8f'];
export const initials = (name: string) => name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase() || '?';
export const avatarColor = (name: string) => AVATAR[[...name].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7) % AVATAR.length];

export function Avatar({name, size = 40}: {name: string; size?: number}) {
  return <View accessibilityElementsHidden importantForAccessibility="no" style={{width: size, height: size, borderRadius: size / 2, backgroundColor: avatarColor(name), alignItems: 'center', justifyContent: 'center'}}>
    <Text style={{color: '#fff', fontWeight: '900', fontSize: size * 0.38}}>{initials(name)}</Text>
  </View>;
}

export type Tone = 'ok' | 'danger' | 'warn' | 'info' | 'grey' | 'brand';
const toneColors: Record<Tone, [string, string]> = {
  ok: [C.okSoft, C.ok], danger: [C.dangerSoft, C.danger], warn: [C.warnSoft, C.warn], info: [C.infoSoft, C.info], grey: [C.grey, C.muted], brand: [C.brand, '#fff'],
};
export function Chip({label, tone = 'grey'}: {label: string; tone?: Tone}) {
  const [bg, fg] = toneColors[tone];
  return <View style={[u.chip, {backgroundColor: bg}]}><Text style={[u.chipText, {color: fg}]}>{label}</Text></View>;
}

export function Segmented<T extends string>({options, value, onChange, dark}: {options: readonly (readonly [T, string])[]; value: T; onChange: (v: T) => void; dark?: boolean}) {
  return <View style={[u.seg, dark && {backgroundColor: 'rgba(255,255,255,0.14)'}]} accessibilityRole="tablist">
    {options.map(([k, l]) => {
      const on = k === value;
      return <TouchableOpacity key={k} accessibilityRole="tab" accessibilityState={{selected: on}} onPress={() => onChange(k)} style={[u.segItem, on && (dark ? u.segOnDark : u.segOn)]}>
        <Text numberOfLines={1} style={[u.segText, dark && {color: '#d6eee7'}, on && (dark ? {color: C.brand} : {color: '#fff'})]}>{l}</Text>
      </TouchableOpacity>;
    })}
  </View>;
}

export function StatCard({label, value, sub, tone, onPress, style}: {label: string; value: string; sub?: string; tone?: Tone; onPress?: () => void; style?: StyleProp<ViewStyle>}) {
  const bar = tone ? toneColors[tone][1] : C.brand;
  const body = <><Text numberOfLines={1} style={u.statLabel}>{label}</Text><Text numberOfLines={1} adjustsFontSizeToFit style={[u.statValue, tone === 'danger' && {color: C.danger}]}>{value}</Text>{!!sub && <Text numberOfLines={1} style={u.statSub}>{sub}</Text>}</>;
  return onPress
    ? <TouchableOpacity accessibilityRole="button" accessibilityLabel={label + ' ' + value + (sub ? ', ' + sub : '')} onPress={onPress} style={[u.stat, {borderLeftColor: bar}, style]}>{body}</TouchableOpacity>
    : <View accessible accessibilityLabel={label + ' ' + value + (sub ? ', ' + sub : '')} style={[u.stat, {borderLeftColor: bar}, style]}>{body}</View>;
}

/** Dependency-free bar chart (no native chart library needed). */
export function BarChart({data, height = 120, format}: {data: {label: string; value: number}[]; height?: number; format: (n: number) => string}) {
  const max = Math.max(1, ...data.map(d => Math.abs(d.value)));
  if (!data.length) return <Text style={u.statSub}>No data yet.</Text>;
  return <View accessible accessibilityLabel={'Chart: ' + data.map(d => d.label + ' ' + format(d.value)).join(', ')}>
    <View style={[u.chartRow, {height}]}>
      {data.map(d => <View key={d.label} style={u.chartCol}>
        <Text numberOfLines={1} adjustsFontSizeToFit style={u.chartVal}>{d.value ? format(d.value) : ''}</Text>
        <View style={[u.chartBar, {height: Math.max(2, Math.round((height - 22) * Math.abs(d.value) / max)), backgroundColor: d.value < 0 ? C.danger : C.accent}]} />
      </View>)}
    </View>
    <View style={u.chartLabels}>{data.map(d => <Text key={d.label} numberOfLines={1} style={u.chartLabel}>{d.label}</Text>)}</View>
  </View>;
}

export function SectionHeader({title, right}: {title: string; right?: React.ReactNode}) {
  return <View style={u.section}><Text accessibilityRole="header" style={u.sectionText}>{title}</Text>{right}</View>;
}

export function Empty({title, text}: {title: string; text?: string}) {
  return <View style={u.empty}><Text style={u.emptyTitle}>{title}</Text>{!!text && <Text style={u.emptyText}>{text}</Text>}</View>;
}

export function Fab({label, onPress}: {label: string; onPress: () => void}) {
  return <TouchableOpacity accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={u.fab}><Text style={u.fabText}>＋ {label}</Text></TouchableOpacity>;
}

export const u = StyleSheet.create({
  chip: {paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999, alignSelf: 'flex-start'},
  chipText: {fontSize: 10, fontWeight: '900', letterSpacing: 0.3},
  seg: {flexDirection: 'row', backgroundColor: C.grey, borderRadius: 12, padding: 3, gap: 3},
  segItem: {flex: 1, alignItems: 'center', paddingVertical: 9, borderRadius: 10, minHeight: 38, justifyContent: 'center'},
  segOn: {backgroundColor: C.brand}, segOnDark: {backgroundColor: '#fff'},
  segText: {fontSize: 12, fontWeight: '800', color: C.muted},
  stat: {flex: 1, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.line, borderLeftWidth: 4, minHeight: 74},
  statLabel: {fontSize: 11, color: C.muted, fontWeight: '700'}, statValue: {fontSize: 20, fontWeight: '900', color: C.ink, marginTop: 4}, statSub: {fontSize: 11, color: C.muted, marginTop: 2},
  chartRow: {flexDirection: 'row', alignItems: 'flex-end', gap: 6}, chartCol: {flex: 1, alignItems: 'center', justifyContent: 'flex-end'},
  chartBar: {width: '80%', borderTopLeftRadius: 6, borderTopRightRadius: 6}, chartVal: {fontSize: 9, color: C.muted, marginBottom: 3},
  chartLabels: {flexDirection: 'row', gap: 6, marginTop: 4}, chartLabel: {flex: 1, textAlign: 'center', fontSize: 10, color: C.muted, fontWeight: '700'},
  section: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 6, marginBottom: 8},
  sectionText: {fontSize: 12, fontWeight: '900', color: C.ink, letterSpacing: 0.6},
  empty: {alignItems: 'center', padding: 28, backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.line},
  emptyTitle: {fontSize: 16, fontWeight: '900', color: C.ink, textAlign: 'center'}, emptyText: {fontSize: 12, color: C.muted, marginTop: 6, textAlign: 'center'},
  fab: {position: 'absolute', right: 16, bottom: 16, backgroundColor: C.accent, borderRadius: 28, paddingVertical: 14, paddingHorizontal: 20, elevation: 6, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 6, shadowOffset: {width: 0, height: 3}},
  fabText: {color: '#fff', fontWeight: '900', fontSize: 14},
});
