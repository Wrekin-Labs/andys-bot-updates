import React,{useMemo,useState}from'react';
import{Alert,Linking,ScrollView,StyleSheet,Text,TextInput,TouchableOpacity,View}from'react-native';
import {useStoredState,asList} from './useStoredState';
import {localDateISO} from '../lib/invoiceMath';
import {isISODate} from '../lib/dates';

type WaterFill={id:string;date:string;litres:number;cost:number;station:string;vehicle?:string;notes?:string};
const KEY='roundflow.waterFills';
const today=()=>localDateISO(new Date());
const money=(n:number)=>'£'+n.toFixed(2);

export default function WaterHub(){
 const[fills,setFills,store]=useStoredState<WaterFill[]>(KEY,[],asList);
 const[date,setDate]=useState(today());
 const[litres,setLitres]=useState('');
 const[cost,setCost]=useState('');
 const[station,setStation]=useState('');
 const[vehicle,setVehicle]=useState('');
 const[notes,setNotes]=useState('');


 const stats=useMemo(()=>{const totalLitres=fills.reduce((a,f)=>a+f.litres,0);const totalCost=fills.reduce((a,f)=>a+f.cost,0);
  const month=today().slice(0,7),monthFills=fills.filter(f=>f.date.startsWith(month));
  return{totalLitres,totalCost,avg:totalLitres?totalCost/totalLitres:0,monthLitres:monthFills.reduce((a,f)=>a+f.litres,0),monthCost:monthFills.reduce((a,f)=>a+f.cost,0)};},[fills]);
 const addFill=()=>{const l=Number(litres),c=Number(cost);
  if(!isISODate(date)||!Number.isFinite(l)||l<=0||!Number.isFinite(c)||c<0)return Alert.alert('Fill details','Enter a date as YYYY-MM-DD, litres and total cost.');
  const next:WaterFill={id:'wf'+Date.now(),date,litres:l,cost:c,station:station.trim()||'Unspecified station',vehicle:vehicle.trim(),notes:notes.trim()};
  setFills(v=>[next,...v]);setLitres('');setCost('');setStation('');setNotes('');
 };
 const removeFill=(id:string)=>Alert.alert('Delete water fill?','This removes the fill from the local water ledger.',[
  {text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress:()=>setFills(v=>v.filter(f=>f.id!==id))}
 ]);
 const openSpotless=()=>Linking.openURL('https://www.spotlesswater.co.uk/Locations/').catch(()=>Alert.alert('Could not open Spotless Water'));

 return <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.pad}>
  <View style={s.hero}><Text style={s.heroTitle}>Water</Text><Text style={s.heroSub}>Pure-water fills, cost and usage in one place.</Text>
   <TouchableOpacity style={s.spotlessBtn} onPress={openSpotless}><Text style={s.spotlessText}>Find Spotless Water station ↗</Text></TouchableOpacity>
  </View>
  {!!store.error&&<View style={s.card}><Text style={[s.muted,{color:'#a12626'}]}>{store.error}</Text></View>}
  <View style={s.grid}>
   <View style={s.metric}><Text style={s.metricLabel}>This month</Text><Text style={s.metricValue}>{stats.monthLitres.toFixed(0)} L</Text><Text style={s.metricSub}>{money(stats.monthCost)}</Text></View>
   <View style={s.metric}><Text style={s.metricLabel}>All fills</Text><Text style={s.metricValue}>{stats.totalLitres.toFixed(0)} L</Text><Text style={s.metricSub}>{money(stats.totalCost)}</Text></View>
   <View style={s.metric}><Text style={s.metricLabel}>Average</Text><Text style={s.metricValue}>{stats.avg?money(stats.avg):'£0.00'}</Text><Text style={s.metricSub}>per litre</Text></View>
  </View>
  <View style={s.card}><Text style={s.title}>Record a fill</Text>
   <TextInput style={s.input} value={date} onChangeText={setDate} placeholder="YYYY-MM-DD"/>
   <View style={s.row}><TextInput style={[s.input,s.half]} value={litres} onChangeText={setLitres} keyboardType="decimal-pad" placeholder="Litres"/><TextInput style={[s.input,s.half]} value={cost} onChangeText={setCost} keyboardType="decimal-pad" placeholder="Total cost £"/></View>
   <TextInput style={s.input} value={station} onChangeText={setStation} placeholder="Station e.g. Kingswinford"/>
   <TextInput style={s.input} value={vehicle} onChangeText={setVehicle} placeholder="Vehicle / tank (optional)"/>
   <TextInput style={[s.input,{minHeight:72,textAlignVertical:'top'}]} value={notes} onChangeText={setNotes} multiline placeholder="Notes (optional)"/>
   <TouchableOpacity style={s.primary} onPress={addFill}><Text style={s.primaryText}>Save water fill</Text></TouchableOpacity>
  </View>
  <Text style={s.section}>RECENT FILLS</Text>
  {fills.length===0?<View style={s.card}><Text style={s.muted}>No fills recorded yet. Your first fill will appear here.</Text></View>:fills.map(f=>
   <View key={f.id} style={s.fill}><View style={{flex:1}}><Text style={s.fillTitle}>{f.station}</Text><Text style={s.muted}>{f.date}{f.vehicle?' · '+f.vehicle:''}</Text>{!!f.notes&&<Text style={s.notes}>{f.notes}</Text>}</View>
    <View style={s.fillRight}><Text style={s.litres}>{f.litres.toFixed(0)} L</Text><Text style={s.cost}>{money(f.cost)}</Text><Text style={s.perL}>{f.litres?money(f.cost/f.litres)+'/L':''}</Text><TouchableOpacity onPress={()=>removeFill(f.id)}><Text style={s.delete}>Delete</Text></TouchableOpacity></View>
   </View>)}
 </ScrollView>;
}

const s=StyleSheet.create({
 pad:{padding:12,paddingBottom:28},hero:{backgroundColor:'#0b6b57',borderRadius:18,padding:18,marginBottom:12},heroTitle:{fontSize:30,fontWeight:'900',color:'#fff'},heroSub:{color:'#d6eee7',marginTop:4},
 spotlessBtn:{marginTop:14,alignSelf:'flex-start',backgroundColor:'#fff',paddingVertical:9,paddingHorizontal:12,borderRadius:10},spotlessText:{fontSize:12,fontWeight:'900',color:'#0b6b57'},
 grid:{flexDirection:'row',gap:8,marginBottom:12},metric:{flex:1,backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:14,padding:11},metricLabel:{fontSize:10,fontWeight:'800',color:'#6f7f7b'},metricValue:{fontSize:18,fontWeight:'900',color:'#15302a',marginTop:3},metricSub:{fontSize:10,color:'#0b6b57',fontWeight:'800',marginTop:2},
 card:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:16,padding:14,marginBottom:12},title:{fontSize:17,fontWeight:'900',color:'#15302a',marginBottom:10},input:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:11,padding:11,marginBottom:9,fontSize:15},row:{flexDirection:'row',gap:8},half:{flex:1},
 primary:{backgroundColor:'#19a37f',padding:13,borderRadius:11,alignItems:'center'},primaryText:{fontWeight:'900',color:'#fff'},section:{fontSize:12,fontWeight:'900',color:'#15302a',marginBottom:8},
 fill:{backgroundColor:'#fff',borderWidth:1,borderColor:'#dfe7e4',borderRadius:14,padding:13,marginBottom:8,flexDirection:'row',gap:10},fillTitle:{fontSize:15,fontWeight:'900',color:'#15302a'},muted:{fontSize:12,color:'#6f7f7b',marginTop:2},notes:{fontSize:12,color:'#54645f',marginTop:5},fillRight:{alignItems:'flex-end'},litres:{fontSize:17,fontWeight:'900',color:'#15302a'},cost:{fontSize:13,fontWeight:'900',color:'#0b6b57'},perL:{fontSize:10,color:'#6f7f7b',marginTop:2},delete:{fontSize:11,fontWeight:'800',color:'#a12626',marginTop:8}
});
