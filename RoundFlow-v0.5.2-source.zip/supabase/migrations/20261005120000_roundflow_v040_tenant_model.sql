-- RoundFlow v0.4.0 — tenant-safe cloud data model (DRAFT, not applied to any project)
--
-- For a NEW, dedicated RoundFlow Supabase project. It supersedes the draft in
-- /supabase-schema.sql (which was never deployed). Do not run it against an
-- unrelated project. Verified locally on PostgreSQL 16 with an auth stub —
-- see supabase/tests/rls_test.sql and CLAUDE-ROUNDFLOW-TESTS.md.
--
-- Principles
--  * Every exposed table has RLS; access is by organisation membership.
--  * Roles: owner > admin > planner > worker. Workers read their org and may only
--    update visit status on jobs assigned to them.
--  * Cross-tenant references are impossible: child rows use composite foreign keys
--    (organization_id, parent_id).
--  * Issued invoices and payments are never deleted (void / reversal instead).
--  * Payments are idempotent on (organization_id, provider_ref) for webhook retries.
--  * Plan/subscription state is written only by the service role (billing webhooks).
--  * Sync metadata: client_id (device-generated id, idempotent upsert), version
--    (bumped on every update), updated_at, deleted_at (soft delete tombstones).

create extension if not exists pgcrypto;
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

-- ---------------------------------------------------------------- organisations
create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 200),
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.memberships (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','planner','worker')),
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);
create index memberships_user_idx on public.memberships(user_id);

create table public.invitations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  email text not null check (position('@' in email) > 1),
  role text not null check (role in ('admin','planner','worker')),
  token_hash text not null unique,
  invited_by uuid not null default auth.uid() references auth.users(id),
  expires_at timestamptz not null default now() + interval '7 days',
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);

-- Billing state: written by the service role only (Stripe/Paddle/Play billing webhook).
create table public.subscriptions (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  provider text,
  provider_customer_id text,
  provider_subscription_id text,
  plan text not null default 'starter' check (plan in ('starter','solo','pro','team')),
  status text not null default 'inactive',
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------- helpers
create or replace function private.org_role(org uuid)
returns text language sql stable security definer set search_path = '' as $$
  select m.role from public.memberships m where m.organization_id = org and m.user_id = auth.uid()
$$;
create or replace function private.has_role(org uuid, roles text[])
returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce(private.org_role(org) = any(roles), false)
$$;
create or replace function private.is_member(org uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select private.org_role(org) is not null
$$;
revoke all on function private.org_role(uuid), private.has_role(uuid,text[]), private.is_member(uuid) from public, anon;
grant execute on function private.org_role(uuid), private.has_role(uuid,text[]), private.is_member(uuid) to authenticated;

-- Sync bookkeeping: bump version + updated_at, never allow organization_id to move.
create or replace function private.touch_row()
returns trigger language plpgsql set search_path = '' as $$
begin
  if tg_op = 'UPDATE' then
    if new.organization_id is distinct from old.organization_id then
      raise exception 'organization_id cannot change' using errcode = '42501';
    end if;
    new.version := old.version + 1;
  end if;
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------- business data
create table public.business_profiles (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  business_name text not null default '',
  contact_name text not null default '',
  phone text not null default '',
  email text not null default '',
  address text not null default '',
  vat_registered boolean not null default false,
  vat_number text not null default '',
  default_tax_rate numeric(5,2) not null default 0 check (default_tax_rate between 0 and 100),
  bank_account_name text not null default '',
  sort_code text not null default '' check (sort_code = '' or sort_code ~ '^\d{2}-?\d{2}-?\d{2}$'),
  account_number text not null default '' check (account_number = '' or account_number ~ '^\d{8}$'),
  payment_url text not null default '' check (payment_url = '' or payment_url ~* '^https://'),
  payment_terms_days int not null default 7 check (payment_terms_days between 0 and 365),
  invoice_footer text not null default '',
  version bigint not null default 1,
  updated_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  client_id text,
  name text not null,
  area text, address text, phone text, email text, notes text,
  price numeric(12,2) not null default 0 check (price >= 0),
  frequency text not null default '4-weekly',
  balance_adjustment numeric(12,2) not null default 0,
  service text, worker_user_id uuid references auth.users(id),
  paused boolean not null default false,
  archived boolean not null default false,
  next_due date,
  quote_id uuid,
  version bigint not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, id),
  unique (organization_id, client_id)
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  customer_id uuid not null,
  client_id text,
  due_date date,
  status text not null default 'scheduled' check (status in ('scheduled','done','skipped','cancelled')),
  route_order int not null default 0,
  amount numeric(12,2) not null default 0 check (amount >= 0),
  completed_at timestamptz,
  assigned_to uuid references auth.users(id),
  notes text,
  version bigint not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, id),
  unique (organization_id, client_id),
  foreign key (organization_id, customer_id) references public.customers(organization_id, id) on delete cascade
);

create table public.quotes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  client_id text,
  quote_number bigint not null,
  customer_id uuid,
  customer_name text not null,
  description text not null default '',
  amount numeric(12,2) not null check (amount >= 0),
  status text not null default 'draft' check (status in ('draft','sent','accepted','declined')),
  valid_until date,
  version bigint not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, id),
  unique (organization_id, client_id),
  unique (organization_id, quote_number),
  foreign key (organization_id, customer_id) references public.customers(organization_id, id)
);

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  customer_id uuid not null,
  job_id uuid,
  quote_id uuid,
  client_id text,
  invoice_number bigint,
  issued_on date not null default current_date,
  due_on date,
  discount numeric(12,2) not null default 0 check (discount >= 0),
  tax_rate numeric(5,2) not null default 0 check (tax_rate between 0 and 100),
  deposit numeric(12,2) not null default 0 check (deposit >= 0),
  notes text, payment_info text, payment_schedule text,
  voided_at timestamptz, void_reason text,
  version bigint not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, id),
  unique (organization_id, client_id),
  unique (organization_id, invoice_number),
  check ((voided_at is null) = (void_reason is null)),
  foreign key (organization_id, customer_id) references public.customers(organization_id, id),
  foreign key (organization_id, job_id) references public.jobs(organization_id, id),
  foreign key (organization_id, quote_id) references public.quotes(organization_id, id)
);

create table public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  invoice_id uuid not null,
  position int not null default 0,
  description text not null default '',
  qty numeric(12,3) not null check (qty >= 0),
  rate numeric(12,2) not null check (rate >= 0),
  version bigint not null default 1,
  updated_at timestamptz not null default now(),
  foreign key (organization_id, invoice_id) references public.invoices(organization_id, id) on delete cascade
);

-- Payments are an append-only ledger. Reversals/refunds are negative rows.
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  invoice_id uuid not null,
  client_id text,
  amount numeric(12,2) not null check (amount <> 0),
  method text not null,
  kind text not null default 'payment' check (kind in ('payment','reversal','refund')),
  provider text,
  provider_ref text,
  received_on date not null default current_date,
  recorded_by uuid default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  unique (organization_id, client_id),
  unique (organization_id, provider_ref),
  check ((kind = 'payment') = (amount > 0)),
  foreign key (organization_id, invoice_id) references public.invoices(organization_id, id)
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  client_id text,
  supplier text not null, category text not null default 'Other',
  amount numeric(12,2) not null check (amount > 0),
  spent_on date not null default current_date,
  notes text,
  version bigint not null default 1,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, client_id)
);

create table public.reminders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  invoice_id uuid not null,
  channel text not null check (channel in ('sms','email')),
  template text not null,
  status text not null default 'composer_opened' check (status in ('composer_opened','queued','sent','failed')),
  created_by uuid default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  foreign key (organization_id, invoice_id) references public.invoices(organization_id, id)
);

create table public.water_fills (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  client_id text,
  fill_date date not null default current_date,
  litres numeric(10,2) not null check (litres > 0),
  total_cost numeric(10,2) not null default 0 check (total_cost >= 0),
  station text, vehicle text, notes text,
  created_by uuid default auth.uid() references auth.users(id),
  version bigint not null default 1,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, client_id)
);

create table public.audit_events (
  id bigint generated always as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor uuid,
  table_name text not null,
  row_id text,
  action text not null,
  at timestamptz not null default now()
);

-- ---------------------------------------------------------------- triggers
do $$ declare t text; begin
  foreach t in array array['customers','jobs','quotes','invoices','invoice_items','expenses','water_fills','business_profiles'] loop
    execute format('create trigger %I_touch before update on public.%I for each row execute function private.touch_row()', t, t);
  end loop;
end $$;

-- Invoice numbers: clients may supply one (offline-issued) or leave it null.
-- The per-org counter always moves above the highest number seen, so server
-- allocation can never collide with a number already issued offline.
create table private.org_counters (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  last_invoice bigint not null default 0,
  last_quote bigint not null default 0
);
create or replace function private.assign_invoice_number()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n bigint;
begin
  insert into private.org_counters(organization_id) values (new.organization_id) on conflict do nothing;
  if new.invoice_number is null then
    update private.org_counters set last_invoice = last_invoice + 1 where organization_id = new.organization_id returning last_invoice into n;
    new.invoice_number := n;
  else
    if new.invoice_number <= 0 then raise exception 'invoice_number must be positive'; end if;
    update private.org_counters set last_invoice = greatest(last_invoice, new.invoice_number) where organization_id = new.organization_id;
  end if;
  return new;
end $$;
create trigger invoices_number before insert on public.invoices for each row execute function private.assign_invoice_number();

-- Issued invoices are immutable in their identity; amounts cannot change once paid or void.
create or replace function private.guard_invoice()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.invoice_number is distinct from old.invoice_number or new.customer_id is distinct from old.customer_id then
    raise exception 'invoice number/customer cannot change' using errcode = '42501';
  end if;
  if old.voided_at is not null then
    raise exception 'void invoices cannot be edited' using errcode = '42501';
  end if;
  if new.voided_at is not null and exists (select 1 from public.payments p where p.invoice_id = old.id having sum(p.amount) <> 0) then
    raise exception 'reverse payments before voiding' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger invoices_guard before update on public.invoices for each row execute function private.guard_invoice();

-- Workers may only change status/completion/notes on jobs assigned to them.
create or replace function private.guard_worker_job_update()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if private.org_role(old.organization_id) = 'worker' then
    if old.assigned_to is distinct from auth.uid()
       or (to_jsonb(new) - array['status','completed_at','notes','version','updated_at'])
          is distinct from (to_jsonb(old) - array['status','completed_at','notes','version','updated_at']) then
      raise exception 'workers can only update status on their own jobs' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
create trigger jobs_worker_guard before update on public.jobs for each row execute function private.guard_worker_job_update();

-- Memberships: never leave an organisation without an owner; only owners grant owner.
create or replace function private.guard_membership()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op in ('UPDATE','DELETE') and old.role = 'owner'
     and (tg_op = 'DELETE' or new.role <> 'owner')
     and not exists (select 1 from public.memberships m where m.organization_id = old.organization_id and m.role = 'owner' and m.user_id <> old.user_id) then
    raise exception 'an organisation must keep at least one owner' using errcode = '42501';
  end if;
  if tg_op in ('UPDATE','DELETE') and old.role = 'owner' and auth.uid() is not null and old.user_id <> auth.uid()
     and coalesce(private.org_role(old.organization_id), '') <> 'owner' then
    raise exception 'only owners can change another owner' using errcode = '42501';
  end if;
  if tg_op in ('INSERT','UPDATE') and new.role = 'owner' and auth.uid() is not null
     and coalesce(private.org_role(new.organization_id), '') <> 'owner'
     and not (tg_op = 'INSERT' and current_setting('roundflow.bootstrap', true) = 'on') then
    raise exception 'only owners can grant owner' using errcode = '42501';
  end if;
  return coalesce(new, old);
end $$;
create trigger memberships_guard before insert or update or delete on public.memberships for each row execute function private.guard_membership();

create or replace function private.audit()
returns trigger language plpgsql security definer set search_path = '' as $$
declare r record;
begin
  r := coalesce(new, old);
  insert into public.audit_events(organization_id, actor, table_name, row_id, action)
  values (r.organization_id, auth.uid(), tg_table_name, r.id::text, lower(tg_op));
  return coalesce(new, old);
end $$;
do $$ declare t text; begin
  foreach t in array array['customers','invoices','payments','quotes','expenses'] loop
    execute format('create trigger %I_audit after insert or update or delete on public.%I for each row execute function private.audit()', t, t);
  end loop;
end $$;

-- ---------------------------------------------------------------- RPCs
-- Creates an organisation and its owner membership atomically.
create or replace function public.create_organization(org_name text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare org uuid;
begin
  if auth.uid() is null then raise exception 'sign in required' using errcode = '42501'; end if;
  insert into public.organizations(name, created_by) values (org_name, auth.uid()) returning id into org;
  perform set_config('roundflow.bootstrap', 'on', true);
  insert into public.memberships(organization_id, user_id, role) values (org, auth.uid(), 'owner');
  perform set_config('roundflow.bootstrap', 'off', true);
  insert into public.business_profiles(organization_id, business_name) values (org, org_name);
  insert into public.subscriptions(organization_id) values (org);
  return org;
end $$;

-- Invitation acceptance: the raw token is only ever sent by email; we store its hash.
create or replace function public.accept_invitation(token text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare inv public.invitations;
begin
  if auth.uid() is null then raise exception 'sign in required' using errcode = '42501'; end if;
  select * into inv from public.invitations
   where token_hash = encode(extensions.digest(token, 'sha256'), 'hex') and accepted_at is null and expires_at > now()
   for update;
  if inv.id is null then raise exception 'invitation invalid or expired' using errcode = '42501'; end if;
  if lower(inv.email) <> lower(coalesce((select u.email from auth.users u where u.id = auth.uid()), '')) then
    raise exception 'invitation was sent to a different email address' using errcode = '42501';
  end if;
  insert into public.memberships(organization_id, user_id, role) values (inv.organization_id, auth.uid(), inv.role)
    on conflict (organization_id, user_id) do nothing;
  update public.invitations set accepted_at = now() where id = inv.id;
  return inv.organization_id;
end $$;
revoke all on function public.create_organization(text), public.accept_invitation(text) from public, anon;
grant execute on function public.create_organization(text), public.accept_invitation(text) to authenticated;

-- ---------------------------------------------------------------- RLS
alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.invitations enable row level security;
alter table public.subscriptions enable row level security;
alter table public.business_profiles enable row level security;
alter table public.customers enable row level security;
alter table public.jobs enable row level security;
alter table public.quotes enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;
alter table public.payments enable row level security;
alter table public.expenses enable row level security;
alter table public.reminders enable row level security;
alter table public.water_fills enable row level security;
alter table public.audit_events enable row level security;

revoke all on all tables in schema public from anon;
revoke all on all tables in schema public from authenticated;
grant select on all tables in schema public to authenticated;
grant update (name) on public.organizations to authenticated;
grant insert, update, delete on public.memberships, public.invitations to authenticated;
grant insert, update on public.business_profiles to authenticated;
grant insert, update, delete on public.customers, public.jobs, public.quotes, public.expenses, public.water_fills, public.invoice_items to authenticated;
grant insert, update on public.invoices to authenticated;      -- no delete: void instead
grant insert on public.payments, public.reminders to authenticated; -- append-only

-- Read: any member of the organisation.
create policy org_read on public.organizations for select to authenticated using (private.is_member(id));
create policy org_rename on public.organizations for update to authenticated using (private.has_role(id, array['owner'])) with check (private.has_role(id, array['owner']));
create policy members_read on public.memberships for select to authenticated using (private.is_member(organization_id));
create policy members_manage on public.memberships for all to authenticated
  using (private.has_role(organization_id, array['owner','admin']))
  with check (private.has_role(organization_id, array['owner','admin']));
create policy invites_manage on public.invitations for all to authenticated
  using (private.has_role(organization_id, array['owner','admin']))
  with check (private.has_role(organization_id, array['owner','admin']));
create policy subs_read on public.subscriptions for select to authenticated using (private.is_member(organization_id));
create policy audit_read on public.audit_events for select to authenticated using (private.has_role(organization_id, array['owner','admin']));

do $$ declare t text; begin
  foreach t in array array['business_profiles','customers','jobs','quotes','invoices','invoice_items','payments','expenses','reminders','water_fills'] loop
    execute format('create policy %I_read on public.%I for select to authenticated using (private.is_member(organization_id))', t, t);
  end loop;
  -- Office roles manage schedule, customers and quotes.
  foreach t in array array['customers','quotes','water_fills'] loop
    execute format('create policy %I_write on public.%I for all to authenticated using (private.has_role(organization_id, array[''owner'',''admin'',''planner''])) with check (private.has_role(organization_id, array[''owner'',''admin'',''planner'']))', t, t);
  end loop;
  -- Money: owner/admin/planner issue invoices; only owner/admin edit profile, expenses and record payments.
  foreach t in array array['invoices','invoice_items','reminders'] loop
    execute format('create policy %I_write on public.%I for all to authenticated using (private.has_role(organization_id, array[''owner'',''admin'',''planner''])) with check (private.has_role(organization_id, array[''owner'',''admin'',''planner'']))', t, t);
  end loop;
  foreach t in array array['business_profiles','expenses','payments'] loop
    execute format('create policy %I_write on public.%I for all to authenticated using (private.has_role(organization_id, array[''owner'',''admin''])) with check (private.has_role(organization_id, array[''owner'',''admin'']))', t, t);
  end loop;
end $$;
-- Jobs: office roles fully; workers may update (guarded by trigger to status on their own jobs).
create policy jobs_office on public.jobs for all to authenticated
  using (private.has_role(organization_id, array['owner','admin','planner']))
  with check (private.has_role(organization_id, array['owner','admin','planner']));
create policy jobs_worker_update on public.jobs for update to authenticated
  using (private.has_role(organization_id, array['worker']) and assigned_to = (select auth.uid()))
  with check (private.has_role(organization_id, array['worker']) and assigned_to = (select auth.uid()));

-- ---------------------------------------------------------------- indexes
create index customers_org_idx on public.customers(organization_id) where deleted_at is null;
create index customers_sync_idx on public.customers(organization_id, updated_at);
create index jobs_org_due_idx on public.jobs(organization_id, due_date);
create index jobs_sync_idx on public.jobs(organization_id, updated_at);
create index invoices_org_customer_idx on public.invoices(organization_id, customer_id);
create index invoices_sync_idx on public.invoices(organization_id, updated_at);
create index payments_invoice_idx on public.payments(organization_id, invoice_id);
create index invoice_items_invoice_idx on public.invoice_items(organization_id, invoice_id);
create index reminders_invoice_idx on public.reminders(organization_id, invoice_id);
create index water_fills_org_date_idx on public.water_fills(organization_id, fill_date desc);
create index audit_org_at_idx on public.audit_events(organization_id, at desc);
