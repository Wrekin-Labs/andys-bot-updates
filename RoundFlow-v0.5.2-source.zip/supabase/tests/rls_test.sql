-- RLS / tenant isolation tests. Run after auth_stub.sql + the migration. Fails loudly on any breach.
\set ON_ERROR_STOP on
insert into auth.users values
 ('00000000-0000-0000-0000-00000000000a','owner.a@example.com'),
 ('00000000-0000-0000-0000-00000000000b','owner.b@example.com'),
 ('00000000-0000-0000-0000-00000000000c','worker.c@example.com'),
 ('00000000-0000-0000-0000-00000000000d','admin.d@example.com');

create function pg_temp.as_user(uid text) returns void language sql as $$
  select set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, false) $$;
create function pg_temp.expect_fail(q text, label text) returns void language plpgsql as $$
begin
  begin execute q; exception when others then raise notice 'PASS (blocked): % — %', label, sqlerrm; return; end;
  raise exception 'FAIL: % was allowed', label;
end $$;
create function pg_temp.expect(cond boolean, label text) returns void language plpgsql as $$
begin if cond then raise notice 'PASS: %', label; else raise exception 'FAIL: %', label; end if; end $$;
grant execute on function pg_temp.as_user(text), pg_temp.expect_fail(text,text), pg_temp.expect(boolean,text) to authenticated, anon;
create table public._ids(k text primary key, v uuid); grant select, insert on public._ids to authenticated;

set role authenticated;
select null from pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
insert into public._ids select 'orgA', public.create_organization('Shine A');
with x as (insert into public.customers(organization_id,name,price) select v,'Jane',20 from public._ids where k='orgA' returning id) insert into public._ids select 'custA', id from x;
with x as (insert into public.jobs(organization_id,customer_id,assigned_to) select (select v from public._ids where k='orgA'),(select v from public._ids where k='custA'),'00000000-0000-0000-0000-00000000000c' returning id) insert into public._ids select 'jobA', id from x;
with x as (insert into public.invoices(organization_id,customer_id) select (select v from public._ids where k='orgA'),(select v from public._ids where k='custA') returning id) insert into public._ids select 'invA', id from x;
insert into public.memberships(organization_id,user_id,role) select v,'00000000-0000-0000-0000-00000000000c','worker' from public._ids where k='orgA';
insert into public.memberships(organization_id,user_id,role) select v,'00000000-0000-0000-0000-00000000000d','admin' from public._ids where k='orgA';
select pg_temp.expect((select invoice_number from public.invoices) = 1, 'server assigns invoice number 1');
insert into public.invoices(organization_id,customer_id,invoice_number) select (select v from public._ids where k='orgA'),(select v from public._ids where k='custA'),40;
insert into public.invoices(organization_id,customer_id) select (select v from public._ids where k='orgA'),(select v from public._ids where k='custA');
select pg_temp.expect((select max(invoice_number) from public.invoices) = 41, 'offline-issued number 40 moves the counter (next = 41)');
select pg_temp.expect_fail($q$insert into public.invoices(organization_id,customer_id,invoice_number) select (select v from public._ids where k='orgA'),(select v from public._ids where k='custA'),40$q$, 'duplicate invoice number');
insert into public.payments(organization_id,invoice_id,amount,method,provider,provider_ref) select (select v from public._ids where k='orgA'),(select v from public._ids where k='invA'),10,'Card','stripe','stripe:pi_1';
select pg_temp.expect_fail($q$insert into public.payments(organization_id,invoice_id,amount,method,provider,provider_ref) select (select v from public._ids where k='orgA'),(select v from public._ids where k='invA'),10,'Card','stripe','stripe:pi_1'$q$, 'duplicate provider payment (webhook retry)');
select pg_temp.expect_fail($q$insert into public.payments(organization_id,invoice_id,amount,method,kind) select (select v from public._ids where k='orgA'),(select v from public._ids where k='invA'),-5,'Cash','payment'$q$, 'negative amount labelled as payment');
select pg_temp.expect_fail($q$update public.invoices set voided_at=now(), void_reason='x' where id=(select v from public._ids where k='invA')$q$, 'void while payments recorded');
select pg_temp.expect_fail($q$delete from public.invoices where id=(select v from public._ids where k='invA')$q$, 'owner deleting an issued invoice');
select pg_temp.expect_fail($q$delete from public.payments$q$, 'deleting payments');
select pg_temp.expect_fail($q$update public.invoices set invoice_number=99 where id=(select v from public._ids where k='invA')$q$, 'renumbering an invoice');
select pg_temp.expect_fail($q$update public.subscriptions set plan='team'$q$, 'owner upgrading own plan from the client');
select pg_temp.expect_fail($q$update public.organizations set created_by='00000000-0000-0000-0000-00000000000b'$q$, 'changing organisation creator');
select pg_temp.expect_fail($q$delete from public.memberships where user_id='00000000-0000-0000-0000-00000000000a'$q$, 'removing the last owner');
update public.customers set price = 22 where name='Jane';
select pg_temp.expect((select version from public.customers where name='Jane') = 2, 'sync version bumps on update');
select pg_temp.expect((select count(*) from public.audit_events) >= 4, 'audit trail written');

-- Tenant B
select null from pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
insert into public._ids select 'orgB', public.create_organization('Other B');
select pg_temp.expect((select count(*) from public.customers) = 0, 'B cannot see A customers');
select pg_temp.expect((select count(*) from public.invoices) = 0, 'B cannot see A invoices');
select pg_temp.expect((select count(*) from public.organizations) = 1, 'B sees only own organisation');
select pg_temp.expect((select count(*) from public.audit_events) = 0, 'B cannot read A audit trail');
select pg_temp.expect_fail($q$insert into public.customers(organization_id,name) select v,'Intruder' from public._ids where k='orgA'$q$, 'B inserting into A');
select pg_temp.expect_fail($q$insert into public.memberships(organization_id,user_id,role) select v,'00000000-0000-0000-0000-00000000000b','owner' from public._ids where k='orgA'$q$, 'B adding self to A');
select pg_temp.expect_fail($q$insert into public.invoices(organization_id,customer_id) select (select v from public._ids where k='orgB'),(select v from public._ids where k='custA')$q$, 'B invoicing A''s customer from B (cross-tenant FK)');
with u as (update public.customers set name='hacked' returning 1) select pg_temp.expect((select count(*) from u)=0, 'B update of A rows affects nothing');

-- Worker C in A
select null from pg_temp.as_user('00000000-0000-0000-0000-00000000000c');
select pg_temp.expect((select count(*) from public.customers) = 1, 'worker reads own org customers');
select pg_temp.expect_fail($q$insert into public.invoices(organization_id,customer_id) select (select v from public._ids where k='orgA'),(select v from public._ids where k='custA')$q$, 'worker issuing invoices');
select pg_temp.expect_fail($q$insert into public.payments(organization_id,invoice_id,amount,method) select (select v from public._ids where k='orgA'),(select v from public._ids where k='invA'),5,'Cash'$q$, 'worker recording payments');
update public.memberships set role='owner' where user_id='00000000-0000-0000-0000-00000000000c';
select pg_temp.expect((select role from public.memberships where user_id='00000000-0000-0000-0000-00000000000c') = 'worker', 'worker cannot escalate own role (update matches no rows)');
update public.jobs set status='done', completed_at=now() where id=(select v from public._ids where k='jobA');
select pg_temp.expect((select status from public.jobs) = 'done', 'worker completes own assigned job');
select pg_temp.expect_fail($q$update public.jobs set amount=99 where id=(select v from public._ids where k='jobA')$q$, 'worker changing job price');

-- Admin D in A
select null from pg_temp.as_user('00000000-0000-0000-0000-00000000000d');
select pg_temp.expect_fail($q$update public.memberships set role='worker' where user_id='00000000-0000-0000-0000-00000000000a'$q$, 'admin demoting the owner');
select pg_temp.expect_fail($q$insert into public.memberships(organization_id,user_id,role) select v,'00000000-0000-0000-0000-00000000000b','owner' from public._ids where k='orgA'$q$, 'admin granting owner');
update public.memberships set role='planner' where user_id='00000000-0000-0000-0000-00000000000c';
select pg_temp.expect((select role from public.memberships where user_id='00000000-0000-0000-0000-00000000000c') = 'planner', 'admin manages non-owner roles');

-- Anonymous
reset role; set role anon; select set_config('request.jwt.claims','',false);
select pg_temp.expect_fail('select count(*) from public.customers', 'anon reading customers');
select pg_temp.expect_fail($q$select public.create_organization('x')$q$, 'anon creating organisations');
reset role;
select 'RLS_TESTS_PASS';
