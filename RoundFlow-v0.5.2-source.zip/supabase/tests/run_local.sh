#!/usr/bin/env bash
# Runs the migration + RLS tests on a throwaway local PostgreSQL (no Supabase project needed).
set -euo pipefail
PGBIN=${PGBIN:-$(ls -d /usr/lib/postgresql/*/bin | sort -V | tail -1)}
DIR=$(mktemp -d); PORT=${PORT:-55432}; HERE=$(cd "$(dirname "$0")" && pwd)
trap '"$PGBIN/pg_ctl" -D "$DIR" stop -m immediate >/dev/null 2>&1 || true; rm -rf "$DIR"' EXIT
"$PGBIN/initdb" -D "$DIR" -U postgres -A trust >/dev/null
"$PGBIN/pg_ctl" -D "$DIR" -o "-p $PORT -k $DIR" -l "$DIR/log" start >/dev/null
PSQL=("$PGBIN/psql" -h "$DIR" -p "$PORT" -U postgres -v ON_ERROR_STOP=1 -q)
"${PSQL[@]}" -c 'create database rf' >/dev/null
"${PSQL[@]}" -d rf -f "$HERE/auth_stub.sql"
"${PSQL[@]}" -d rf -f "$HERE/../migrations/20261005120000_roundflow_v040_tenant_model.sql"
"${PSQL[@]}" -d rf -f "$HERE/rls_test.sql" 2>&1
