# RoundFlow v0.4.0 — Engineering review (Claude, 5 Oct 2026)

Scope: full read of every source file in the mobile handoff (App, 9 components, 6 libs, tests, Supabase draft, Android manifest/Gradle text). Status column: **Fixed** = changed in this patch and covered by a test where marked; **Open** = documented, needs external work.

## Critical

| # | Finding | Where | Status |
|---|---|---|---|
| C1 | **Data loss on unreadable side-data.** BusinessHub, TeamSettings and WaterHub fell back to defaults when a stored key failed to parse, then their auto-save wrote those defaults over the user's quotes/expenses/templates/profile/users/water fills. | BusinessHub, TeamSettings, WaterHub | Fixed — `useStoredState` never saves until a read succeeds; error shown in UI. |
| C2 | **Supabase draft: client could upgrade its own plan.** `organizations.plan` was updatable by the owner via RLS. | supabase-schema.sql | Fixed in new migration — plan lives in `subscriptions`, service-role writes only (SQL-tested). |
| C3 | **Supabase draft: any member, including workers, could insert/update/delete invoices and balances.** | supabase-schema.sql | Fixed in new migration — role-based policies; invoices/payments not deletable (SQL-tested). |

## High

| # | Finding | Status |
|---|---|---|
| H1 | Customer `owing` was a hand-maintained running counter adjusted in 8 places; any missed path (or clamping with `Math.max(0,…)`) drifted it from the invoices. | Fixed — balance is derived on every change: `balanceAdjustment + Σ unpaid invoice balances`. Migration records the exact v0.3.1 difference as `balanceAdjustment`, so **every displayed balance is preserved on upgrade** (tested). |
| H2 | Double-tap / stale-closure risk: handlers used render-time `jobs`/`invoices`; `actionLocks` was cleared on every save effect. | Fixed — single `mutate()` path works on the latest committed state by id; repeated taps are no-ops. |
| H3 | Undo completion **deleted** an issued invoice, leaving an unexplained number gap. | Fixed — invoice is **voided** (number kept, amounts zeroed, original preserved, audit history). Hidden from the default Money view, so the existing Android flow test expectations still hold. |
| H4 | Reports used `invoice.amount` for paid invoices — ignored items, discount, VAT and partial payments. | Fixed — `lib/reports.ts` (cash-basis income from payment lines, reversals, legacy paid invoices). Tested. |
| H5 | Customer statement showed only invoice total + status; no paid/balance/running total; excluded opening balances. | Fixed — `lib/statement.ts`, running total always equals the customer balance (tested). |
| H6 | Full-backup export aborted entirely if any one key was corrupt — exactly when a backup is needed (also from the "could not load" screen). | Fixed — corrupt sections exported verbatim under `raw`; restore validates everything before writing (tested). |
| H7 | Supabase draft: child rows could reference another tenant's customer/job (FKs on id only). | Fixed — composite `(organization_id, id)` FKs (SQL-tested). |
| H8 | Invoice decimal fields committed every keystroke and **raised an alert mid-typing** (e.g. typing a new total below recorded payments). | Fixed — keystroke commits are silent; validation alerts only on blur. |

## Medium

| # | Finding | Status |
|---|---|---|
| M1 | Free-text due date (`1/11/2026`) compared as a string → wrong "Overdue"; shown as "Invalid Date". | Fixed — validated ISO date + presets; non-ISO never overdue (tested). |
| M2 | Customer "Duration" field clamped every keystroke (typing 45 became 5→54…). | Fixed — commit-on-blur numeric input. |
| M3 | ↑/↓ reorder swapped with paused/archived jobs on the same date, appearing to do nothing. | Fixed. |
| M4 | CSV import turned "One-off" into 4-weekly and dropped balances' meaning; export vulnerable to spreadsheet formula injection (`=`, `+`, `-`, `@`). | Fixed — `parseFrequency`, `csvCell` guard (round-trips on import). Imported balances become opening balances. |
| M5 | Attachments stored as OS cache URIs (Android may purge). | Fixed — copied to app document storage. Backups still don't include files (documented in UI). |
| M6 | Delete-local-data: next load re-seeded demo data; mounted components could re-save old data. | Fixed — writes an empty snapshot and remounts. |
| M7 | Expenses/water dates used UTC (`toISOString`) — wrong day after 11pm BST. | Fixed — local dates. |
| M8 | Quotes had no number, expiry, or conversion guard; "create job" could be pressed repeatedly. | Fixed — Q-numbers, validity, expired state, conversion recorded on the job/invoice (`quoteId`) so it can only happen once. |
| M9 | Invoice dates stored as display strings, unusable for month reports. | Fixed — additive `issuedISO`/`atISO`, migrated from legacy strings incl. "Sept". |
| M10 | Google Maps URLs silently truncate long days (waypoint limit). | Fixed — split into chained legs of ≤10 stops. |
| M11 | Supabase draft: invoice-number trigger overwrote any client-supplied number, conflicting with numbers already issued offline. | Fixed in migration — client numbers accepted and the server counter moves above them (SQL-tested). |
| M12 | Safe-area/insets: `SafeAreaView` from react-native is iOS-only/deprecated; nav uses fixed 22px bottom padding with `edgeToEdgeEnabled=true`. | **Open** — needs `react-native-safe-area-context` (could not install/verify here). |

## Low

| # | Finding | Status |
|---|---|---|
| L1 | VAT toggle did nothing; no VAT number on invoices. | Fixed — VAT number, "VAT invoice" title, default VAT % for new invoices, warnings. No compliance claimed. |
| L2 | CIS toggle implied deductions that were never calculated. | Fixed (honesty) — labelled "record only". |
| L3 | Users & roles and subscription prices looked functional. | Fixed (honesty) — labelled as local labels / pricing preview. |
| L4 | Quote PDF stripped `<>&` instead of escaping. | Fixed — shared escaped templates. |
| L5 | "Save version" only added a label. | Improved — records total/balance snapshot. |
| L6 | Components declared inside `App` render (remount each render). | Partly fixed (reminder panel, profile fields). Remaining ones contain no inputs. |
| L7 | Android: `allowBackup=false` means no Google auto-backup. | Kept (privacy); UI now tells users to export backups. |

## Android / dependencies
- Package `uk.co.roundflow.app` and signing path untouched. No new native dependencies added.
- Permissions unchanged (INTERNET only; storage/overlay/vibrate removed). Nothing new requested.
- `npm audit` could not run here (registry blocked); CI now runs it (non-blocking).

## Not claimed
No tax/accounting/MTD compliance, no live payments, no live sync, no automatic reminders.
