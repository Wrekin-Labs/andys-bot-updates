-- SUPERSEDED (v0.4.0): never deployed. Use supabase/migrations/20261005120000_roundflow_v040_tenant_model.sql instead.
-- Kept for reference only. Known issues: org owners could set organizations.plan, all members
-- (incl. workers) could write/delete invoices, and child rows could reference another tenant.
-- RoundFlow SaaS schema draft
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid not null references auth.users(id) on delete cascade,
  plan text not null default 'starter',
  created_at timestamptz not null default now()
);

create table if not exists public.memberships (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'worker' check (role in ('owner','admin','worker')),
  created_at timestamptz not null default now(),
  primary key (organization_id,user_id)
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  area text,
  address text,
  phone text,
  email text,
  notes text,
  price numeric(10,2) not null default 0,
  frequency_weeks int not null default 4,
  balance numeric(10,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  due_date date,
  status text not null default 'scheduled' check (status in ('scheduled','done','skipped','cancelled')),
  route_order int not null default 0,
  amount numeric(10,2) not null default 0,
  completed_at timestamptz,
  assigned_to uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete set null,
  invoice_number bigint not null,
  amount numeric(10,2) not null,
  status text not null default 'owing' check (status in ('draft','owing','paid','void')),
  issued_at timestamptz not null default now(),
  paid_at timestamptz,
  unique (organization_id,invoice_number)
);

create table if not exists public.water_fills (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  fill_date date not null default current_date,
  litres numeric(10,2) not null check (litres > 0),
  total_cost numeric(10,2) not null default 0 check (total_cost >= 0),
  vat_amount numeric(10,2) not null default 0 check (vat_amount >= 0),
  supplier text not null default 'Spotless Water',
  station text,
  vehicle text,
  notes text,
  receipt_path text,
  created_by uuid default auth.uid() references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  provider text,
  provider_customer_id text,
  provider_subscription_id text,
  plan text not null default 'starter',
  status text not null default 'inactive',
  current_period_end timestamptz
);

create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table if not exists private.organization_invoice_sequences (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  next_number bigint not null default 1 check (next_number > 0)
);

create or replace function private.assign_invoice_number()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare assigned bigint;
begin
  insert into private.organization_invoice_sequences (organization_id,next_number)
  values (new.organization_id,2)
  on conflict (organization_id)
  do update set next_number = private.organization_invoice_sequences.next_number + 1
  returning next_number - 1 into assigned;
  new.invoice_number := assigned;
  return new;
end;
$$;

revoke all on function private.assign_invoice_number() from public, anon, authenticated;
drop trigger if exists roundflow_assign_invoice_number on public.invoices;
create trigger roundflow_assign_invoice_number
before insert on public.invoices
for each row execute function private.assign_invoice_number();

create or replace function private.add_owner_membership()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.memberships (organization_id,user_id,role)
  values (new.id,new.owner_id,'owner')
  on conflict (organization_id,user_id) do nothing;
  return new;
end;
$$;

revoke all on function private.add_owner_membership() from public, anon, authenticated;
drop trigger if exists roundflow_add_owner_membership on public.organizations;
create trigger roundflow_add_owner_membership
after insert on public.organizations
for each row execute function private.add_owner_membership();

create or replace function private.is_org_member(org uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select auth.uid() is not null
    and exists(
      select 1
      from public.memberships m
      where m.organization_id = org
        and m.user_id = auth.uid()
    );
$$;

revoke all on function private.is_org_member(uuid) from public, anon;
grant execute on function private.is_org_member(uuid) to authenticated;

alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.customers enable row level security;
alter table public.jobs enable row level security;
alter table public.invoices enable row level security;
alter table public.water_fills enable row level security;
alter table public.subscriptions enable row level security;

revoke all on public.organizations,public.memberships,public.customers,public.jobs,public.invoices,public.water_fills,public.subscriptions from anon;
grant select,insert,update,delete on public.organizations,public.memberships,public.customers,public.jobs,public.invoices,public.water_fills to authenticated;
grant select on public.subscriptions to authenticated;

create policy "users create own org" on public.organizations for insert to authenticated with check (owner_id=(select auth.uid()));
create policy "org owners update org" on public.organizations for update to authenticated using (owner_id=(select auth.uid())) with check (owner_id=(select auth.uid()));
create policy "org owners delete org" on public.organizations for delete to authenticated using (owner_id=(select auth.uid()));
create policy "orgs visible to members" on public.organizations for select to authenticated using (private.is_org_member(id) or owner_id=(select auth.uid()));
create policy "members visible within org" on public.memberships for select to authenticated using (private.is_org_member(organization_id));
create policy "customers org access" on public.customers for all to authenticated using (private.is_org_member(organization_id)) with check (private.is_org_member(organization_id));
create policy "jobs org access" on public.jobs for all to authenticated using (private.is_org_member(organization_id)) with check (private.is_org_member(organization_id));
create policy "invoices org access" on public.invoices for all to authenticated using (private.is_org_member(organization_id)) with check (private.is_org_member(organization_id));
create policy "water fills org access" on public.water_fills for all to authenticated using (private.is_org_member(organization_id)) with check (private.is_org_member(organization_id));
create policy "subscriptions org access" on public.subscriptions for select to authenticated using (private.is_org_member(organization_id));

create index if not exists customers_org_idx on public.customers(organization_id);
create index if not exists jobs_org_due_idx on public.jobs(organization_id,due_date);
create index if not exists invoices_org_status_idx on public.invoices(organization_id,status);
create index if not exists water_fills_org_date_idx on public.water_fills(organization_id,fill_date desc);
