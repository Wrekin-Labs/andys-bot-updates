# RoundFlow v0.4.1 — Responsive Planner & Job Tools

Date: 5 October 2026  
Package: `uk.co.roundflow.app`  
Android versionCode: 24

## What changed

### Phone, tablet and PC/web
- Responsive layout via runtime width breakpoints.
- Phone keeps a compact single-column workflow.
- Tablet/PC use wider split layouts and multi-column work lists.
- Expo web dependencies added and production web export verified.

### Work planner UI
- Dark, denser weekly dashboard inspired by the supplied reference screenshots while keeping RoundFlow branding.
- Planner modes: **List / Map-Route / Week / Calendar**.
- Colour-coded route status:
  - blue scheduled;
  - green completed;
  - red owing;
  - grey skipped.
- Map/Route view includes numbered colour-coded stops, job details and route order.
- Current geographic navigation still hands off to Google Maps; a commercial map/routing API is still required for a true embedded geographic optimisation layer.

### Job records/tools
Each job can now store:
- attached files/pictures;
- start/stop time entries;
- hazards/risks;
- required skills;
- checklist items;
- custom form fields.

These fields are validated and round-trip through RoundFlow core snapshots.

### Feature hub
Added a structured feature catalogue covering:
- Job Management & Scheduling;
- Customer Management;
- Work Assignment & Scheduling;
- Business Management;
- Financials & Reporting;
- Customer Services;
- Messaging & Communication Tools;
- Marketplace.

Each capability is labelled honestly as LIVE, LOCAL, CLOUD REQUIRED or PLANNED.

### Local marketing/marketplace drafts
- Marketing campaign drafts can be prepared locally.
- Round/job marketplace listing drafts can be prepared locally.
- No automated marketing send or public marketplace is claimed without the production backend.

## Verification

- TypeScript: PASS
- CSV parser: PASS
- Invoice integrity: 11/11 PASS
- v0.4.0 logic/migration suite: 18/18 PASS
- v0.4.1 job-tool persistence/validation: 2/2 PASS
- PC/web Expo export: PASS
- Android APK build: PASS
- Android AAB build: PASS
- APK signature: PASS
- AAB signature: PASS
- Android in-place install/launch smoke: PASS
- Runtime metadata: v0.4.1 / code 24

## Dependency audit note

`npm audit --omit=dev --audit-level=high` currently reports high-severity findings through Expo/Metro build-tool dependencies. npm's automatic forced remediation proposes downgrading Expo to 44, which is a breaking and unsafe regression for this project, so it was **not** applied. This should be revisited when compatible upstream Expo/Metro fixes are available.

## Still external / commercial work

- dedicated production RoundFlow Supabase project;
- real multi-device sync and organisation/team membership;
- automatic worker live updates;
- live invoice-payment providers and webhooks;
- RoundFlow SaaS subscription billing;
- automated provider-backed SMS/email;
- hosted customer portal;
- true embedded geographic map/routing optimisation;
- production hosting/domain for the PC web build;
- Play Store closed/public rollout;
- iOS native build/testing.
