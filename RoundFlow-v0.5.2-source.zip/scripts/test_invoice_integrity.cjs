const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const cache = new Map();
function load(name) {
  const filename = path.resolve(__dirname, '../lib', name + '.ts');
  if (cache.has(filename)) return cache.get(filename).exports;
  const m = new Module(filename, module); cache.set(filename, m);
  m.filename = filename; m.paths = module.paths;
  m.require = id => id.startsWith('./') ? load(id.slice(2)) : require(id);
  m._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText, filename);
  return m.exports;
}
const {invoiceAmounts, invoicePaid, invoiceBalance, paymentAllocation, validateInvoiceEdit, numberInvoices, localDateISO} = load('invoiceMath');
const {invoiceHtml} = load('invoiceHtml');
const {decodeCore, validateCore} = load('coreState');
let passed = 0;
function test(name, fn) {fn();passed++;console.log('PASS: '+name);}
const base = {id:'i1',jobId:'j1',customer:'Test customer',amount:100,date:'03 Oct 2026',status:'owing',invoiceNo:7};
test('Discount, VAT and partial payment use the same balance',()=>{
  assert.deepEqual(invoiceAmounts({...base,items:[{description:'Windows',qty:2,rate:18.5},{description:'Frames',qty:1,rate:3.25}],discount:5,taxRate:20,paidAmount:10}),{subtotal:40.25,discount:5,tax:7.05,total:42.3,paid:10,balance:32.3,credit:0});
});
test('Pence rounding avoids residual debt',()=>{
  assert.equal(invoiceAmounts({...base,amount:0.1+0.2}).total,0.3);
  assert.equal(paymentAllocation({...base,amount:0.3,paidAmount:0.1},0.2).status,'paid');
});
test('Legacy paid invoices remain paid and cannot accept another payment',()=>{
  assert.equal(invoicePaid({...base,status:'paid'}),100);
  assert.throws(()=>paymentAllocation({...base,status:'paid'},10),/unpaid balance/);
});
test('Payment cannot exceed remaining debt or use invalid input',()=>{
  assert.deepEqual(paymentAllocation({...base,paidAmount:70},50),{amount:30,paidAmount:100,status:'paid'});
  for(const n of [NaN,Infinity,-1,0]) assert.throws(()=>paymentAllocation(base,n));
});
test('Editing cannot silently erase a recorded payment',()=>{
  assert.throws(()=>validateInvoiceEdit({...base,paidAmount:70},{...base,amount:50}),/recorded payments/);
  assert.equal(validateInvoiceEdit({...base,paidAmount:70},{...base,amount:120,paidAmount:0}).paidAmount,70);
});
test('Partial payments remain visible to completion undo protection',()=>{
  assert.ok(invoicePaid({...base,status:'owing',paidAmount:10})>0);
  assert.equal(invoiceBalance({...base,paidAmount:10,discount:20,taxRate:20}),86);
});
test('Migration reserves every existing number before allocating missing numbers',()=>{
  const result=numberInvoices([{id:'new',invoiceNo:1},{id:'old'}],0);
  assert.equal(result.invoices.find(i=>i.id==='new').invoiceNo,1);
  assert.equal(result.invoices.find(i=>i.id==='old').invoiceNo,2);
  assert.equal(numberInvoices([],result.lastInvoiceNo).lastInvoiceNo,2);
  assert.equal(new Set(numberInvoices([{invoiceNo:1},{invoiceNo:1}]).invoices.map(i=>i.invoiceNo)).size,2);
});
test('Quick PDF and editor PDF use itemised totals and escape user text',()=>{
  const html=invoiceHtml({...base,customer:'<script>bad</script>',items:[{description:'Windows & frames',qty:2,rate:18.5}],taxRate:20,paidAmount:10},{address:'Test road'},{businessName:'Test business'});
  assert.ok(html.includes('Balance due £34.40'));
  assert.ok(html.includes('Total £44.40'));
  assert.ok(html.includes('Windows &amp; frames'));
  assert.ok(!html.includes('<script>'));
});
test('Corrupt stored data is rejected before it can replace live state',()=>{
  assert.throws(()=>decodeCore('{invalid'));
  assert.throws(()=>decodeCore(JSON.stringify({version:9,jobs:[],invoices:[]})));
  assert.throws(()=>validateCore({},[]));
  assert.throws(()=>validateCore([], [{...base,amount:-1}]));
});
test('Snapshot restart preserves invoice sequence and exact balances',()=>{
  const jobs=[{id:'j1',name:'Test',freq:'4-weekly',tags:[],price:100,owing:60}];
  const snapshot=validateCore(jobs,[{...base,paidAmount:40}],20);
  const restored=decodeCore(JSON.stringify(snapshot));
  assert.equal(restored.jobs[0].owing,60);
  assert.equal(restored.lastInvoiceNo,20);
  assert.equal(invoiceBalance(restored.invoices[0]),60);
});
test('Planner uses local calendar dates around midnight',()=>{
  const old=process.env.TZ;process.env.TZ='Europe/London';
  try{assert.equal(localDateISO(new Date('2026-10-02T23:30:00Z')),'2026-10-03');}finally{if(old===undefined)delete process.env.TZ;else process.env.TZ=old;}
});
console.log(`INVOICE_INTEGRITY_PASS ${passed}/${passed}`);
