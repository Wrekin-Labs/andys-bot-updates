import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {load}=require('./lib_loader.cjs');
const {parseCsv}=load('csv');

const sample=[
 'Name,Area,Address,Phone,Email,Notes,Price,Frequency,Owing',
 '"Jane Smith","Telford","1 Test Road","07123 456789","jane@example.com","Rear gate, left side',
 'Dog may be outside; customer said ""ring first""","18.50","4-weekly","5.00"',
 '"Bob Jones","Wellington","2 High Street","","","Normal note","20","8-weekly","0"'
].join('\r\n');

const rows=parseCsv(sample);
assert.equal(rows.length,3);
assert.equal(rows[1][0],'Jane Smith');
assert.equal(rows[1][5],'Rear gate, left side\r\nDog may be outside; customer said "ring first"');
assert.equal(rows[1][6],'18.50');
assert.equal(rows[2][0],'Bob Jones');
assert.throws(()=>parseCsv('Name,Notes\nJane,"unclosed'),/unclosed quoted field/);
console.log('CSV_MULTILINE_PASS');
console.log(JSON.stringify(rows[1]));
