param([string]$JdkHome)
$ErrorActionPreference = 'Stop'
$rfRoot = Split-Path -Parent $PSScriptRoot
$rfOriginalJavaHome = $env:JAVA_HOME
$rfOriginalLocation = Get-Location
try {
    if (!$JdkHome) {
        $ErrorActionPreference = 'Continue'
        $rfInfo = (& java -XshowSettings:properties -version 2>&1 | Out-String)
        $ErrorActionPreference = 'Stop'
        $JdkHome = (($rfInfo -split "`r?`n" | Where-Object { $_ -match '^\s*java.home = ' }) -replace '^\s*java.home = ', '').Trim()
    }
    if (!(Test-Path "$JdkHome\bin\java.exe")) { throw 'Pass -JdkHome with an installed JDK 17 directory.' }
    if ((Get-Content (Join-Path $JdkHome 'release') | Where-Object { $_ -match '^JAVA_VERSION=' }) -notmatch '"17[.]') { throw 'RoundFlow release builds currently require JDK 17.' }
    $env:JAVA_HOME = $JdkHome
    Set-Location $rfRoot
    & npm.cmd run typecheck
    if ($LASTEXITCODE -ne 0) { throw 'TypeScript check failed.' }
    & npm.cmd test
    if ($LASTEXITCODE -ne 0) { throw 'Regression checks failed.' }
    if (!(Test-Path 'android\keystore.properties')) { throw 'Release signing configuration is missing. Do not distribute a debug-signed release.' }
    Set-Location (Join-Path $rfRoot 'android')
    & .\gradlew.bat assembleRelease bundleRelease --max-workers=2 --console=plain
    if ($LASTEXITCODE -ne 0) { throw 'Android build failed.' }
} finally {
    $env:JAVA_HOME = $rfOriginalJavaHome
    Set-Location $rfOriginalLocation
}
