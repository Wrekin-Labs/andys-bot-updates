// Loads lib/*.ts in plain Node by transpiling with the project's TypeScript (no bundler needed).
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const cache = new Map();
function load(name) {
  const filename = path.resolve(__dirname, '../lib', name + '.ts');
  if (cache.has(filename)) return cache.get(filename).exports;
  const m = new Module(filename, module); cache.set(filename, m);
  m.filename = filename; m.paths = module.paths;
  m.require = id => id.startsWith('./') ? load(id.slice(2)) : require(id);
  m._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020}}).outputText, filename);
  return m.exports;
}
module.exports = {load};
