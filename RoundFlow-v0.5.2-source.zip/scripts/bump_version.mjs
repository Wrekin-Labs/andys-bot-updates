// Usage: node scripts/bump_version.mjs 0.4.0 23
// Run ONLY after typecheck, tests and the Android release build pass. Keeps package ID and signing untouched.
import fs from 'node:fs';
const [version, code] = process.argv.slice(2);
if (!/^\d+\.\d+\.\d+$/.test(version || '') || !/^\d+$/.test(code || '')) { console.error('Usage: node scripts/bump_version.mjs <x.y.z> <versionCode>'); process.exit(1); }
const edit = (f, fn) => { const before = fs.readFileSync(f, 'utf8'); const after = fn(before); if (before === after) throw new Error('No change in ' + f); fs.writeFileSync(f, after); console.log('updated', f); };
edit('package.json', s => s.replace(/"version": "[^"]+"/, `"version": "${version}"`));
const lock = JSON.parse(fs.readFileSync('package-lock.json','utf8'));
lock.version = version;
if (lock.packages?.['']) lock.packages[''].version = version;
fs.writeFileSync('package-lock.json', JSON.stringify(lock,null,2)+'\n');
console.log('updated package-lock.json');
edit('app.json', s => s.replace(/"version": "[^"]+"/, `"version": "${version}"`).replace(/"versionCode": \d+/, `"versionCode": ${code}`));
edit('android/app/build.gradle', s => s.replace(/versionCode \d+/, `versionCode ${code}`).replace(/versionName "[^"]+"/, `versionName "${version}"`));
edit('lib/version.ts', s => s.replace(/'[^']+'/, `'${version}'`));
