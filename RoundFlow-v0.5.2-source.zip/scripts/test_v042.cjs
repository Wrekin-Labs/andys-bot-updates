const assert=require('node:assert/strict');
const {load}=require('./lib_loader.cjs');
const planning=load('planning');
const {encodeCore,decodeCore,validateCore}=load('coreState');

let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}

const users=[
 {id:'u1',name:'Andy',email:'',active:true,roles:['Owner'],skills:['WFP','Ladder'],dailyCapacityMin:480},
 {id:'u2',name:'Sam',email:'',active:true,roles:['Worker'],skills:['Commercial'],dailyCapacityMin:360},
 {id:'u3',name:'Off',email:'',active:false,roles:['Worker'],skills:['MEWP'],dailyCapacityMin:999},
];
const job=(o={})=>({id:'j1',name:'Jane',area:'Telford',price:20,owing:0,freq:'4-weekly',tags:[],done:false,durationMin:60,worker:'Andy',...o});

test('Team daily capacity counts active users only',()=>{
 assert.equal(planning.totalDailyCapacity(users),840);
 assert.equal(planning.totalDailyCapacity([],480),480);
});

test('Planned minutes ignores archived paused and skipped work',()=>{
 const rows=[job({id:'a',durationMin:60}),job({id:'b',durationMin:45,skipped:true}),job({id:'c',durationMin:30,paused:true}),job({id:'d',durationMin:20,archived:true}),job({id:'e',durationMin:90})];
 assert.equal(planning.plannedMinutes(rows),150);
 assert.equal(planning.capacityPercent(rows,[users[0]],480),31);
});

test('Required skills match assigned worker case-insensitively',()=>{
 assert.deepEqual(planning.missingSkills(job({requiredSkills:['wfp','LADDER']}),users),[]);
 assert.deepEqual(planning.missingSkills(job({worker:undefined,requiredSkills:['WFP']}),users),[]);
 assert.deepEqual(planning.missingSkills(job({requiredSkills:['WFP','MEWP']}),users),['MEWP']);
 assert.deepEqual(planning.missingSkills(job({worker:'Unknown',requiredSkills:['WFP']}),users),['WFP']);
});

test('Capacity labels distinguish available healthy full and overloaded',()=>{
 assert.equal(planning.capacityLabel(40),'Available');
 assert.equal(planning.capacityLabel(80),'Healthy');
 assert.equal(planning.capacityLabel(100),'Nearly full');
 assert.equal(planning.capacityLabel(120),'Over capacity');
});

test('Visit history survives core snapshot and malformed events are rejected',()=>{
 const j=job({visitHistory:[
  {id:'v1',atISO:'2026-10-05T10:00:00.000Z',status:'completed',worker:'Andy'},
  {id:'v2',atISO:'2026-10-06T10:00:00.000Z',status:'rescheduled',worker:'Andy',note:'Moved from 2026-10-05 to 2026-10-06'}
 ]});
 const out=decodeCore(encodeCore([j],[],0));
 assert.deepEqual(out.jobs[0].visitHistory,j.visitHistory);
 assert.throws(()=>validateCore([{...j,visitHistory:[{id:'bad',atISO:'x',status:'not-real'}]}],[],0),/invalid details or amounts/);
});

test('Day Pilot filters not-done, completed and all deterministically',()=>{
 const rows=[job({id:'a'}),job({id:'b',done:true}),job({id:'c',skipped:true})];
 assert.deepEqual(planning.filterDayPilot(rows,'notdone').map(x=>x.id),['a','c']);
 assert.deepEqual(planning.filterDayPilot(rows,'completed').map(x=>x.id),['b']);
 assert.deepEqual(planning.filterDayPilot(rows,'all').map(x=>x.id),['a','b','c']);
});

test('Route planning supports manual/area order plus explicit start and end',()=>{
 const rows=[job({id:'a',area:'South',address:'2 Zed St'}),job({id:'b',area:'North',address:'9 Bee St'}),job({id:'c',area:'North',address:'1 Able St'}),job({id:'d',area:'West',address:'3 Way St'})];
 assert.deepEqual(planning.routePlan(rows,'manual').map(x=>x.id),['a','b','c','d']);
 assert.deepEqual(planning.routePlan(rows,'area').map(x=>x.id),['c','b','a','d']);
 assert.deepEqual(planning.routePlan(rows,'area','d','c').map(x=>x.id),['d','b','a','c']);
});

test('Area summary counts and sorts route groups',()=>{
 const rows=[job({id:'a',area:'South'}),job({id:'b',area:'North'}),job({id:'c',area:'South'}),job({id:'d',area:''})];
 assert.deepEqual(planning.areaSummary(rows),[{area:'South',count:2},{area:'North',count:1},{area:'Unassigned',count:1}]);
});

console.log('V042_PASS '+passed+'/8');
