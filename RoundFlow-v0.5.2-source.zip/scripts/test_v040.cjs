const assert = require('node:assert/strict');
const {load} = require('./lib_loader.cjs');
process.env.TZ = 'Europe/London';
const {invoiceAmounts, invoiceBalance, validateInvoiceEdit} = load('invoiceMath');
const ledger = load('ledger');
const {decodeCore, loadCore, encodeCore} = load('coreState');
const {parseLegacyDate, isISODate} = load('dates');
const {statementRows, statementTotals, statementHtml} = load('statement');
const {buildReport} = load('reports');
const {normalizeProfile, validateProfile, paymentDetailsLines, defaultDueDate} = load('profile');
const {invoiceHtml} = load('invoiceHtml');
const quotes = load('quotes');
const reminders = load('reminders');
const routes = load('routes');
const backup = load('backup');
const {csvCell, parseFrequency, parseCsv} = load('csv');
const payments = load('payments');

let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS: ' + name); }
const NOW = new Date('2026-10-05T10:00:00+01:00');
const TODAY = '2026-10-05';
const job = (o = {}) => ({id: 'j1', name: 'Jane', area: 'Telford', price: 20, owing: 0, freq: '4-weekly', tags: [], done: false, ...o});
const inv = (o = {}) => ({id: 'i1', jobId: 'j1', customer: 'Jane', amount: 20, date: '05 Oct 2026', issuedISO: TODAY, status: 'owing', invoiceNo: 1, paidAmount: 0, payments: [], ...o});

test('Legacy en-GB dates parse to ISO (incl. "Sept" and toLocaleString)', () => {
  assert.equal(parseLegacyDate('05 Oct 2026'), '2026-10-05');
  assert.equal(parseLegacyDate('5 Sept 2026'), '2026-09-05');
  assert.equal(parseLegacyDate('05/10/2026, 10:08:00'), '2026-10-05');
  assert.equal(parseLegacyDate('2026-02-30'), undefined);
  assert.equal(parseLegacyDate('On receipt'), undefined);
  assert.ok(!isISODate('1/11/2026'));
});

test('Upgrade from v0.3.1 preserves every displayed balance exactly', () => {
  const jobs = [job({owing: 38}), job({id: 'j2', name: 'Bob', owing: 16}), job({id: 'j3', name: 'Drift', owing: 5})];
  const invoices = [inv({amount: 22, issuedISO: undefined}), inv({id: 'i2', jobId: 'j3', amount: 10, paidAmount: 0, invoiceNo: 2})];
  const v031 = JSON.stringify({version: 1, jobs, invoices, lastInvoiceNo: 2});
  const core = decodeCore(v031);
  assert.deepEqual(core.jobs.map(j => j.owing), [38, 16, 5]);
  assert.deepEqual(core.jobs.map(j => j.balanceAdjustment), [16, 16, -5]);
  assert.equal(core.invoices[0].issuedISO, '2026-10-05');
  assert.equal(core.revision, 2);
  assert.ok(core.migrated);
  // Second load is a no-op (idempotent migration).
  const again = decodeCore(encodeCore(core.jobs, core.invoices, core.lastInvoiceNo));
  assert.deepEqual(again.jobs, core.jobs);
  assert.equal(again.migrated, false);
});

test('v0.4.0 snapshot keeps version 1 so v0.3.1 can still open it', () => {
  const s = JSON.parse(encodeCore([job()], [], 0));
  assert.equal(s.version, 1); assert.equal(s.revision, 2);
  assert.throws(() => decodeCore(JSON.stringify({...s, revision: 99})), /newer RoundFlow/);
});

test('Customer balance is derived from invoices + adjustment and never drifts', () => {
  let jobs = [job({balanceAdjustment: 5, owing: 0})];
  let invoices = [inv()];
  jobs = ledger.reconcileBalances(jobs, invoices); assert.equal(jobs[0].owing, 25);
  invoices = [ledger.recordPayment(invoices[0], 7.5, 'Cash', NOW)];
  jobs = ledger.reconcileBalances(jobs, invoices); assert.equal(jobs[0].owing, 17.5);
  invoices = [ledger.reversePayments(invoices[0], NOW)];
  jobs = ledger.reconcileBalances(jobs, invoices); assert.equal(jobs[0].owing, 25);
  invoices = [ledger.settleInvoice(invoices[0], NOW)];
  jobs = [ledger.settleAdjustment(jobs[0], NOW)];
  jobs = ledger.reconcileBalances(jobs, invoices); assert.equal(jobs[0].owing, 0);
  assert.equal(jobs[0].balanceLog[0].amount, -5);
  const same = ledger.reconcileBalances(jobs, invoices); assert.equal(same, jobs, 'no-op returns same array (no extra saves)');
});

test('Undo voids the invoice: number kept, amounts zero, paid invoices protected', () => {
  const v = ledger.voidInvoice(inv({items: [{description: 'W', qty: 1, rate: 20}]}), 'Completion undone', NOW);
  assert.equal(invoiceBalance(v), 0); assert.equal(v.invoiceNo, 1); assert.equal(v.voided.original.amount, 20);
  assert.equal(ledger.invoiceState(v, TODAY).state, 'void');
  assert.throws(() => ledger.voidInvoice(inv({paidAmount: 1}), 'x'), /Reverse the payment/);
  assert.throws(() => validateInvoiceEdit(v, {...v, amount: 50}), /void invoice cannot be edited/);
  assert.throws(() => ledger.recordPayment(v, 5, 'Cash'), /void/);
  assert.ok(invoiceHtml(v, {}, {}).includes('VOID'));
});

test('Overdue status and days overdue use calendar dates; bad due dates are never overdue', () => {
  assert.deepEqual(ledger.invoiceState(inv({dueDate: '2026-09-28'}), TODAY), {state: 'overdue', daysOverdue: 7});
  assert.equal(ledger.invoiceState(inv({dueDate: TODAY}), TODAY).state, 'due');
  assert.equal(ledger.invoiceState(inv({dueDate: '2026-10-12'}), TODAY).state, 'owing');
  assert.equal(ledger.invoiceState(inv({dueDate: '1/11/2026'}), TODAY).state, 'owing');
  assert.equal(ledger.invoiceState(inv({dueDate: '2026-09-01', paidAmount: 20, status: 'paid'}), TODAY).state, 'paid');
  assert.equal(ledger.invoiceStateLabel({state: 'overdue', daysOverdue: 1}), 'Overdue 1 day');
});

test('Statement shows total, paid, balance and a running outstanding that matches the customer balance', () => {
  const invoices = [
    inv({id: 'a', invoiceNo: 1, issuedISO: '2026-08-01', amount: 20, paidAmount: 20, status: 'paid'}),
    inv({id: 'b', invoiceNo: 2, issuedISO: '2026-09-01', amount: 20, paidAmount: 5}),
    ledger.voidInvoice(inv({id: 'c', invoiceNo: 3, issuedISO: '2026-09-15'}), 'undo', NOW),
    inv({id: 'd', invoiceNo: 4, issuedISO: '2026-10-01', amount: 22, dueDate: '2026-09-20'}),
  ];
  const j = ledger.reconcileBalances([job({balanceAdjustment: 10})], invoices)[0];
  const rows = statementRows(j, invoices, TODAY);
  assert.deepEqual(rows.map(r => r.running), [10, 10, 25, 25, 47]);
  assert.equal(rows[rows.length - 1].running, j.owing);
  assert.deepEqual(statementTotals(rows), {charged: 72, paid: 25, outstanding: 47});
  assert.ok(rows[4].status.startsWith('Overdue'));
  const html = statementHtml({...j, name: '<b>x</b>'}, invoices, {sortCode: '123456', accountNumber: '12345678'}, TODAY);
  assert.ok(html.includes('Outstanding £47.00') && html.includes('Sort code: 12-34-56') && !html.includes('<b>x</b>'));
});

test('Statement includes opening balances paid via "Mark balance paid"', () => {
  const j = ledger.settleAdjustment(job({balanceAdjustment: 16}), NOW);
  const rows = statementRows(ledger.reconcileBalances([j], [])[0], [], TODAY);
  assert.deepEqual(rows.map(r => [r.charged, r.paid, r.running]), [[16, 0, 16], [0, 16, 0]]);
});

test('Reports: cash-basis income by month, reversals, legacy paid invoices, void excluded, aged debt', () => {
  const invoices = [
    inv({id: 'a', issuedISO: '2026-09-02', amount: 50, paidAmount: 50, status: 'paid', payments: [{id: 'p', date: '02/09/2026, 10:00:00', amount: 50, method: 'Cash'}]}),
    inv({id: 'b', issuedISO: '2026-09-10', amount: 30, paidAmount: 0, payments: [{id: 'p1', date: '', atISO: '2026-09-11', amount: 30, method: 'Card'}, {id: 'r', date: '', atISO: '2026-10-01', amount: -30, method: 'Reversal'}], dueDate: '2026-09-17'}),
    inv({id: 'c', issuedISO: undefined, date: '01 Aug 2026', amount: 40, status: 'paid', paidAmount: undefined, payments: undefined}),
    ledger.voidInvoice(inv({id: 'v', amount: 999}), 'x', NOW),
    inv({id: 'd', jobId: 'j2', amount: 10, dueDate: '2026-06-01'}),
  ];
  const jobs = ledger.reconcileBalances([job({worker: 'Andy'}), job({id: 'j2', worker: 'Sam', freq: 'One-off'})], invoices);
  const r = buildReport({jobs, invoices, expenses: [{id: 'e', supplier: 'Fuel', category: 'Fuel', amount: 12.5, date: '2026-09-03'}], today: TODAY});
  assert.equal(r.received, 90); assert.equal(r.invoiced, 130); assert.equal(r.expenses, 12.5); assert.equal(r.net, 77.5);
  const sep = r.monthly.find(m => m.month === '2026-09'); const oct = r.monthly.find(m => m.month === '2026-10'); const aug = r.monthly.find(m => m.month === '2026-08');
  assert.deepEqual([sep.received, sep.expenses, sep.net, oct.received, aug.received], [80, 12.5, 67.5, -30, 40]);
  assert.equal(r.outstanding, 40); assert.equal(r.overdue, 40); assert.equal(r.overdueCount, 2);
  assert.equal(r.aged.d1_30, 30); assert.equal(r.aged.d90plus, 10);
  assert.equal(r.workers.find(w => w.worker === 'Andy').visits, 3);
  assert.equal(r.round.oneOff, 1); assert.equal(r.round.monthlyRoundValue, 21.67);
});

test('Business/payment profile validates UK details and flows into invoice PDFs', () => {
  const p = normalizeProfile({businessName: 'Shine Ltd', vat: true, vatNumber: 'GB123456789', defaultTaxRate: 20, bankAccountName: 'Shine Ltd', sortCode: '12 34 56', accountNumber: '1234 5678', paymentUrl: 'https://pay.example/shine', paymentTermsDays: 14, invoiceFooter: 'Thanks!'});
  assert.deepEqual(validateProfile(p), []);
  assert.deepEqual(paymentDetailsLines(p, 'RF-00001'), ['Account name: Shine Ltd', 'Sort code: 12-34-56', 'Account number: 12345678', 'Reference: RF-00001', 'Pay online: https://pay.example/shine']);
  assert.equal(defaultDueDate(p, NOW), '2026-10-19');
  const html = invoiceHtml(inv({taxRate: 20, dueDate: '2026-10-19'}), {}, p);
  for (const s of ['VAT INVOICE RF-00001', 'VAT No. GB123456789', 'VAT @ 20%', 'Sort code: 12-34-56', 'Reference: RF-00001', 'Thanks!', 'Due 19 Oct 2026']) assert.ok(html.includes(s), s);
  const bad = validateProfile(normalizeProfile({sortCode: '12345', accountNumber: 'abc', paymentUrl: 'http://x', email: 'nope', vat: true, defaultTaxRate: 0}));
  assert.equal(bad.length, 5);
  assert.equal(normalizeProfile({businessName: 'Old', vat: true}).paymentTermsDays, 7, 'v0.3.1 profile keeps 7-day terms');
  assert.ok(validateProfile(normalizeProfile({defaultTaxRate: 20})).some(e => /not marked VAT/.test(e)));
});

test('Per-invoice payment info overrides profile bank details', () => {
  const html = invoiceHtml(inv({paymentInfo: 'Cash only please'}), {}, {sortCode: '123456', accountNumber: '12345678'});
  assert.ok(html.includes('Cash only please') && !html.includes('Sort code'));
});

test('Quotes: numbering, expiry, status guard and single conversion', () => {
  const legacy = quotes.normalizeQuotes([{id: 'q2', customer: 'B', description: 'x', amount: 10, status: 'sent', created: '2026-09-01'}, {id: 'q1', customer: 'A', description: 'y', amount: 5, status: 'weird', created: '2026-08-01'}]);
  assert.deepEqual(legacy.map(q => q.number), [2, 1]); assert.equal(legacy[1].status, 'draft');
  const q = quotes.newQuote(legacy, {customer: 'C', description: 'Conservatory', amount: 120}, '2026-08-01', 'q3');
  assert.equal(q.number, 3); assert.equal(q.validUntil, '2026-08-31');
  assert.equal(quotes.quoteDisplayStatus(q, TODAY), 'expired');
  assert.throws(() => quotes.setQuoteStatus(q, 'accepted', TODAY, {}), /expired/);
  const ok = quotes.setQuoteStatus(quotes.extendQuote(q, TODAY), 'accepted', TODAY, {});
  assert.equal(ok.status, 'accepted');
  const links = quotes.quoteLinks(ok, [{id: 'jX', quoteId: 'q3'}], [{id: 'iX', quoteId: 'q3', invoiceNo: 9}]);
  assert.deepEqual(links, {jobId: 'jX', invoiceId: 'iX', invoiceNo: 9});
  assert.throws(() => quotes.setQuoteStatus(ok, 'declined', TODAY, links), /already been converted/);
  assert.equal(quotes.quoteLinks(ok, [], [{id: 'iV', quoteId: 'q3', voided: {}}]).invoiceId, undefined, 'void invoice frees the quote');
  assert.ok(!quotes.quoteHtml({...ok, customer: '<i>'}, {}, TODAY).includes('<i>'));
  assert.throws(() => quotes.normalizeQuotes({}), /not a list/);
});

test('Reminder templates fill tokens, include payment details and log composer hand-off', () => {
  const i = inv({dueDate: '2026-09-28', invoiceNo: 12});
  const t = reminders.suggestedTemplate(i, TODAY);
  assert.equal(t.id, 'overdue');
  const text = reminders.fillReminder(t, i, {name: 'Jane'}, {businessName: 'Shine', sortCode: '123456', accountNumber: '12345678'}, TODAY);
  assert.ok(text.includes('RF-00012') && text.includes('7 days overdue') && text.includes('£20.00') && text.includes('Sort code: 12-34-56') && text.includes('Shine'));
  assert.equal(reminders.smsHref('07123 456 789', 'Hi & bye'), 'sms:07123456789?body=Hi%20%26%20bye');
  assert.ok(reminders.mailtoHref('a@b.com', 'S', 'B').startsWith('mailto:a%40b.com?subject=S&body=B'));
  const logged = reminders.logReminder(i, 'sms', t, NOW);
  assert.equal(logged.reminders.length, 1); assert.equal(reminders.lastReminder(logged).atISO, TODAY);
  assert.equal(reminders.suggestedTemplate(inv({dueDate: '2026-08-01'}), TODAY).id, 'final');
});

test('Route hand-off splits long days into Google Maps legs that chain', () => {
  const stops = Array.from({length: 23}, (_, i) => 'Stop ' + i);
  const legs = routes.routeLegs(stops);
  assert.deepEqual(legs.map(l => l.length), [10, 11, 4]);
  assert.equal(legs[1][0], 'Stop 9'); assert.equal(legs[2][0], 'Stop 19');
  const urls = routes.routeUrls(stops);
  assert.ok(!urls[0].includes('origin=') && urls[1].includes('origin=Stop%209'));
  assert.equal(urls[0].split('waypoints=')[1].split('%7C').length, 9);
  assert.ok(routes.routeUrls(['Only one'])[0].includes('/maps/search/'));
  const ordered = routes.orderByArea([{id: 'a', area: 'Wellington', address: '1 Road, TF1 1AA'}, {id: 'b', area: 'Dawley', address: '2 St, TF4 2BB'}, {id: 'c', area: 'Wellington', address: '3 Rd, TF1 3CC'}]);
  assert.deepEqual(ordered.map(x => x.id), ['a', 'c', 'b']);
  assert.deepEqual(routes.applySubsetOrder([{id: 'x'}, {id: 'a'}, {id: 'y'}, {id: 'b'}], ['b', 'a']).map(r => r.id), ['x', 'b', 'y', 'a']);
});

test('Backup: corrupt sections no longer block export; restore validates before writing', () => {
  const core = encodeCore([job({owing: 20, balanceAdjustment: 20})], [], 0);
  const {json, warnings} = backup.buildBackup([['roundflow.core', core], ['roundflow.quotes', '{broken'], ['roundflow.profile', '{"businessName":"X"}'], ['roundflow.users', null]], {appVersion: '0.4.0', now: NOW});
  assert.deepEqual(warnings, ['roundflow.quotes']);
  const parsed = JSON.parse(json);
  assert.equal(parsed.version, 1); assert.equal(parsed.raw['roundflow.quotes'], '{broken'); assert.equal(parsed.data['roundflow.jobs'].length, 1);
  const plan = backup.planRestore(json);
  assert.deepEqual(plan.ops.map(o => o[0]), ['roundflow.core', 'roundflow.profile']);
  assert.equal(plan.summary.customers, 1); assert.equal(plan.warnings.length, 1);
  assert.throws(() => backup.planRestore('{"format":"roundflow-backup","version":1,"data":{"roundflow.quotes":{}}}'), /Invalid backup section/);
  assert.throws(() => backup.planRestore('nope'), /not valid JSON/);
  assert.throws(() => backup.planRestore(JSON.stringify({...parsed, revision: 7})), /newer RoundFlow/);
  // v0.3.1 legacy-only backup (no core) restores through the migration path.
  const legacy = backup.planRestore(JSON.stringify({format: 'roundflow-backup', version: 1, data: {'roundflow.jobs': [job({owing: 16})], 'roundflow.invoices': []}}));
  assert.equal(JSON.parse(legacy.ops[0][1]).jobs[0].balanceAdjustment, 16);
});

test('CSV export neutralises formulas; import keeps one-off work one-off', () => {
  assert.equal(csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
  assert.equal(csvCell('+44 7123'), '"\'+44 7123"');
  assert.equal(csvCell(-5), '-5'); assert.equal(csvCell('Plain'), '"Plain"');
  assert.deepEqual(['One-off', 'once', '', '4', '6 weeks', 'Fortnightly', 'monthly', 'every 2 months', '0'].map(parseFrequency), ['One-off', 'One-off', '4-weekly', '4-weekly', '6-weekly', '2-weekly', '4-weekly', '9-weekly', 'One-off']);
  assert.equal(parseCsv('a,b\n"x",' + csvCell('=1+1'))[1][1], "'=1+1");
});

test('Provider reconciliation is idempotent, GBP-only and never over-applies', () => {
  const ev = {provider: 'stripe', providerRef: 'pi_1', kind: 'payment', amountPence: 1250, currency: 'GBP', occurredAt: NOW};
  const first = payments.applyProviderEvent(inv(), ev);
  assert.ok(first.applied); assert.equal(first.invoice.paidAmount, 12.5);
  const dup = payments.applyProviderEvent(first.invoice, ev);
  assert.equal(dup.applied, false); assert.equal(dup.invoice, first.invoice);
  const over = payments.applyProviderEvent(first.invoice, {...ev, providerRef: 'pi_2', amountPence: 5000});
  assert.equal(over.invoice.paidAmount, 20); assert.match(over.note, /overpayment of £42.50/);
  const refund = payments.applyProviderEvent(over.invoice, {...ev, providerRef: 're_1', kind: 'refund', amountPence: 500});
  assert.equal(refund.invoice.paidAmount, 15); assert.equal(refund.invoice.status, 'owing');
  assert.throws(() => payments.applyProviderEvent(inv(), {...ev, currency: 'EUR'}), /GBP/);
  assert.equal(payments.notConfiguredProvider.isConfigured(), false);
});

test('Legacy v0.3.0 split keys still load through the migration path', () => {
  const core = loadCore([job({owing: 22})], [], 0, 1);
  assert.equal(core.jobs[0].owing, 22); assert.equal(core.jobs[0].balanceAdjustment, 22);
});

console.log(`V040_PASS ${passed}/${passed}`);
