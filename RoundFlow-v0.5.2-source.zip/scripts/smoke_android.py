import subprocess, time, xml.etree.ElementTree as ET, re, sys
from pathlib import Path

ADB = r"C:\Users\andye\AppData\Local\Android\Sdk\platform-tools\adb.exe"
PKG = "uk.co.roundflow.app"
TMP = Path(r"C:\Users\andye\Desktop\RoundFlow\scripts\_ui.xml")
results=[]

def adb(*args, check=True):
    p=subprocess.run([ADB,*args],capture_output=True,text=True,timeout=60)
    if check and p.returncode: raise RuntimeError(p.stderr or p.stdout)
    return p.stdout.strip()

def dump():
    last=None
    for attempt in range(3):
        try:
            raw=adb("exec-out","uiautomator","dump","--compressed","/dev/tty")
            start=raw.find("<?xml")
            end=raw.rfind("</hierarchy>")
            if start<0 or end<0:
                raise RuntimeError("UI dump missing XML")
            return ET.fromstring(raw[start:end+12])
        except Exception as e:
            last=e
            subprocess.run([ADB,"reconnect","offline"],capture_output=True,text=True,timeout=10)
            time.sleep(1.5)
    raise RuntimeError(f"UI dump failed after retries: {last}")

def nodes(root):
    return list(root.iter("node"))

def bounds(n):
    x1,y1,x2,y2=map(int,re.findall(r"\d+",n.attrib["bounds"]))
    return (x1+x2)//2,(y1+y2)//2
def find(root, attr, value, index=0):
    if attr=="hint":
        hits=[n for n in nodes(root) if n.attrib.get("hint")==value or (n.attrib.get("class")=="android.widget.EditText" and n.attrib.get("text")==value)]
    else:
        hits=[n for n in nodes(root) if n.attrib.get(attr)==value]
    if len(hits)<=index: raise AssertionError(f"missing {attr}={value} index={index}")
    return hits[index]

def tap_node(root, attr, value, index=0):
    x,y=bounds(find(root,attr,value,index))
    adb("shell","input","tap",str(x),str(y)); time.sleep(.35)

def input_field(root,hint,text):
    n=find(root,"hint",hint)
    x,y=bounds(n); adb("shell","input","tap",str(x),str(y)); time.sleep(.2)
    adb("shell","input","text",text); time.sleep(.2)

def expect(root, text):
    if not any(n.attrib.get("text")==text for n in nodes(root)):
        raise AssertionError(f"missing text: {text}")

def expect_contains(root, fragment):
    if not any(fragment in n.attrib.get("text","") for n in nodes(root)):
        raise AssertionError(f"missing fragment: {fragment}")

def expect_amount(root, amount):
    if not any(re.sub(r"[^0-9.]","",n.attrib.get("text",""))==amount for n in nodes(root)):
        raise AssertionError(f"missing amount: {amount}")

def wait_for_text(text, tries=4, delay=2):
    last=None
    for _ in range(tries):
        try:
            last=dump()
            if any(n.attrib.get("text")==text for n in nodes(last)):
                return last
        except Exception:
            pass
        time.sleep(delay)
    if last is None: raise AssertionError(f"missing text after wait: {text}")
    raise AssertionError(f"missing text after wait: {text}")

def ok(name, fn):
    try:
        fn(); results.append((name,"PASS",""))
    except Exception as e:
        results.append((name,"FAIL",str(e)))
        raise
def launch_clean():
    adb("shell","am","force-stop","host.exp.exponent",check=False)
    adb("shell","pm","clear",PKG)
    adb("shell","am","start","-n",PKG+"/.MainActivity")
    time.sleep(6)

def test_initial():
    r=wait_for_text("RoundFlow"); expect(r,"4"); expect_amount(r,"91.00"); expect_amount(r,"38.00")

def week_navigation():
    r=dump()
    nx,ny=bounds(find(r,"content-desc","Next week"))
    px,py=bounds(find(r,"content-desc","Previous week"))
    adb("shell","input","tap",str(nx),str(ny)); time.sleep(.6)
    adb("shell","input","tap",str(px),str(py)); time.sleep(.6)
    r=dump(); expect(r,"4"); expect_amount(r,"91.00")

def add_screen_structure():
    r=dump(); tap_node(r,"content-desc","＋"); time.sleep(.8); r=dump()
    for hint in ["Customer name","Area / postcode","Full address","Phone","Email","Notes / access instructions","Price"]:
        find(r,"hint",hint)
    for desc in ["2-weekly","4-weekly","6-weekly","8-weekly"]:
        find(r,"content-desc",desc)
    tap_node(r,"content-desc","Today"); time.sleep(.4)

def complete_first():
    r=dump(); tap_node(r,"content-desc","COMPLETE",0); time.sleep(.6); r=dump()
    expect(r,"3"); expect_amount(r,"73.00"); expect_amount(r,"56.00"); expect(r,"Done")
    expect_contains(r,"Next due")

def undo_completion():
    r=dump(); tap_node(r,"content-desc","Undo",0); time.sleep(.6); r=dump()
    expect(r,"4"); expect_amount(r,"91.00"); expect_amount(r,"38.00")
    if any(n.attrib.get("text")=="Done" for n in nodes(r)): raise AssertionError("Done tag remained after undo")
    tap_node(r,"content-desc","COMPLETE",0); time.sleep(.6)

def check_invoice():
    r=dump(); tap_node(r,"content-desc","Money"); r=dump()
    expect(r,"Money"); expect(r,"1"); expect_amount(r,"18.00"); expect(r,"Owing"); expect_contains(r,"RF-00001"); expect(r,"PDF / Share")
def persist_restart():
    adb("shell","am","force-stop",PKG); time.sleep(.3)
    adb("shell","am","start","-n",PKG+"/.MainActivity")
    time.sleep(3); r=wait_for_text("RoundFlow"); expect(r,"3"); expect_amount(r,"73.00"); expect_amount(r,"56.00"); expect(r,"Done")

def mark_paid():
    r=dump(); tap_node(r,"content-desc","Mark balance paid",0); time.sleep(.5); r=dump()
    expect_amount(r,"38.00")
    tap_node(r,"content-desc","Money"); r=dump(); expect(r,"Paid")

def paid_undo_guard():
    r=dump(); tap_node(r,"content-desc","Today"); time.sleep(.4); r=dump()
    tap_node(r,"content-desc","Undo",0); time.sleep(.5); r=dump()
    expect_contains(r,"Cannot undo"); expect_contains(r,"paid invoice")
    try: tap_node(r,"text","OK",0)
    except Exception: pass
    time.sleep(.4); r=dump()
    expect(r,"3"); expect_amount(r,"73.00"); expect_amount(r,"38.00"); expect(r,"Done")

def test_more():
    r=dump(); tap_node(r,"content-desc","More"); r=dump()
    expect(r,"More"); expect_contains(r,"Import / Export"); expect_contains(r,"Offline-first storage")
    expect_contains(r,"Cloud account")

def run():
    launch_clean()
    for name,fn in [
        ("initial dashboard",test_initial),
        ("week planner navigation",week_navigation),
        ("add screen structure",add_screen_structure),
        ("complete job + totals",complete_first),
        ("undo completion reverses money",undo_completion),
        ("invoice generated",check_invoice),
        ("restart persistence",persist_restart),
        ("mark paid",mark_paid),
        ("paid invoice undo guard",paid_undo_guard),
        ("more/tools screen",test_more),
    ]:
        print("RUN:",name,flush=True)
        ok(name,fn)
        print("PASS:",name,flush=True)
    out=Path(r"C:\Users\andye\Desktop\RoundFlow\AUDIT-SMOKE-RESULTS.txt")
    out.write_text("\n".join(f"{s}: {n}" + (f" - {d}" if d else "") for n,s,d in results),encoding="utf-8")
    print(out.read_text(encoding="utf-8"))
    if any(s!="PASS" for _,s,_ in results): sys.exit(1)

if __name__=="__main__":
    try: run()
    except Exception as e:
        print("SMOKE TEST FAILED:",e)
        for n,s,d in results: print(f"{s}: {n} {d}")
        sys.exit(1)
