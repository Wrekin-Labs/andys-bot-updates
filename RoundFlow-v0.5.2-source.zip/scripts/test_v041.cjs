const assert=require('node:assert/strict');
const {load}=require('./lib_loader.cjs');
const {encodeCore,decodeCore,validateCore}=load('coreState');

let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}

const base={
 id:'j1',name:'Jane',area:'Telford',price:20,owing:0,freq:'4-weekly',tags:[],done:false,
 hazards:'Dog in rear garden',requiredSkills:['WFP','Ladder'],
 jobAttachments:[{id:'a1',name:'gate.jpg',uri:'file:///gate.jpg',mimeType:'image/jpeg',addedAt:'2026-10-05T12:00:00.000Z'}],
 checklist:[{id:'c1',text:'Check gate',done:true}],
 formFields:[{id:'f1',label:'Access code',value:'1234'}],
 timeEntries:[{id:'t1',startISO:'2026-10-05T12:00:00.000Z',endISO:'2026-10-05T12:25:00.000Z',minutes:25}]
};

test('v0.4.1 job tools survive core save/reload',()=>{
 const out=decodeCore(encodeCore([base],[],0));
 const j=out.jobs[0];
 assert.equal(j.hazards,base.hazards);
 assert.deepEqual(j.requiredSkills,base.requiredSkills);
 assert.deepEqual(j.jobAttachments,base.jobAttachments);
 assert.deepEqual(j.checklist,base.checklist);
 assert.deepEqual(j.formFields,base.formFields);
 assert.deepEqual(j.timeEntries,base.timeEntries);
});

test('v0.4.1 rejects malformed job-tool records',()=>{
 assert.throws(()=>validateCore([{...base,jobAttachments:[{id:'bad',name:'missing uri'}]}],[],0),/invalid details or amounts/);
 assert.throws(()=>validateCore([{...base,timeEntries:[{id:'bad',startISO:'x',minutes:-1}]}],[],0),/invalid details or amounts/);
});

console.log('V041_PASS '+passed+'/2');
