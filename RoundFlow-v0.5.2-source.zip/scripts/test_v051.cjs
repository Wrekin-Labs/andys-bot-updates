const assert=require('node:assert/strict');
const {load}=require('./lib_loader.cjs');
const routing=load('routing');
const settings=load('routingSettings');

let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}
const job=(id,lat,lng)=>({id,name:id,area:'Telford',price:20,owing:0,freq:'4-weekly',tags:[],done:false,latitude:lat,longitude:lng});

test('Routing settings trim public token and preserve valid start time',()=>{
 const out=settings.normalizeRoutingSettings({mapboxToken:'  pk.abcdef123456  ',advancedRoutingUrl:'  https://router.example ',defaultRouteStartTime:'07:30'});
 assert.equal(out.mapboxToken,'pk.abcdef123456');
 assert.equal(out.advancedRoutingUrl,'https://router.example');
 assert.equal(out.defaultRouteStartTime,'07:30');
 assert.equal(settings.normalizeRoutingSettings({defaultRouteStartTime:'99:99'}).defaultRouteStartTime,'08:00');
});

test('Public Mapbox token validation rejects secret/non-public values',()=>{
 assert.equal(settings.isPublicMapboxToken('pk.abcdef123456'),true);
 assert.equal(settings.isPublicMapboxToken('sk.secret123456'),false);
 assert.equal(settings.isPublicMapboxToken('abc'),false);
});

test('Traffic matrix uses driving-traffic and max nine candidates plus source',()=>{
 const rows=Array.from({length:9},(_,i)=>job(String(i),52.6+i/100,-2.4-i/100));
 const url=routing.matrixUrl(rows,{lat:52.67,lng:-2.45},'pk.test');
 assert.match(url,/directions-matrix\/v1\/mapbox\/driving-traffic/);
 assert.match(url,/sources=0/);
 assert.throws(()=>routing.matrixUrl([...rows,job('10',52.9,-2.9)],{lat:52.67,lng:-2.45},'pk.test'),/1 to 9/);
});

test('Live routing can be enabled from a runtime token without build env',()=>{
 assert.equal(routing.liveRoutingReady('pk.runtime123456'),true);
 assert.equal(routing.liveRoutingReady(''),false);
});

console.log('V051_PASS '+passed+'/4');
