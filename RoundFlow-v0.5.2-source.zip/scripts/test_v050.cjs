const assert=require('node:assert/strict');
const {load}=require('./lib_loader.cjs');
const routing=load('routing');
const {encodeCore,decodeCore,validateCore}=load('coreState');

let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}
const job=(id,lat,lng,o={})=>({id,name:id,area:'Telford',address:id+' Road, Telford',price:20,owing:0,freq:'4-weekly',tags:[],done:false,latitude:lat,longitude:lng,...o});

test('Mapbox geocoding uses v6 UK forward endpoint',()=>{
 const url=routing.geocodeUrl('1 High Street, Telford','pk.test');
 assert.match(url,/search\/geocode\/v6\/forward/);
 assert.match(url,/country=GB/);
 assert.match(url,/access_token=pk.test/);
});

test('Directions URL is traffic-aware and keeps supplied order',()=>{
 const rows=[job('a',52.67,-2.45),job('b',52.68,-2.44),job('c',52.69,-2.43)];
 const url=routing.directionsUrl(rows,'pk.test');
 assert.match(url,/directions\/v5\/mapbox\/driving-traffic/);
 assert.ok(url.indexOf('-2.45,52.67')<url.indexOf('-2.44,52.68'));
});

test('Mapbox optimisation limits to 12 and supports fixed endpoints',()=>{
 const rows=[job('a',52.67,-2.45),job('b',52.68,-2.44),job('c',52.69,-2.43)];
 const url=routing.optimisationUrl(rows,true,true,'pk.test');
 assert.match(url,/optimized-trips\/v1\/mapbox\/driving-traffic/);
 assert.match(url,/source=first/);
 assert.match(url,/destination=last/);
 assert.match(url,/roundtrip=false/);
 assert.throws(()=>routing.optimisationUrl(Array.from({length:13},(_,i)=>job(String(i),52+i/100,-2-i/100)),false,false,'pk.test'),/2 to 12/);
});

test('Static map only renders real located jobs and uses numbered pins',()=>{
 const rows=[job('a',52.67,-2.45),job('b',52.68,-2.44,{owing:5})];
 const url=routing.staticMapUrl(rows,'abc123','pk.test');
 assert.match(url,/styles\/v1\/mapbox\/dark-v11\/static/);
 assert.match(url,/pin-s-1/);
 assert.match(url,/pin-s-2/);
 assert.match(url,/path-4\+19a37f/);
 assert.equal(routing.staticMapUrl([{...rows[0],latitude:undefined}],undefined,'pk.test'),'');
});

test('v0.5 geo and appointment data survives snapshots and validates ranges',()=>{
 const j=job('j1',52.678,-2.445,{geocodedAt:'2026-10-05T12:00:00.000Z',geocodeLabel:'1 High Street, Telford',geocodeProvider:'mapbox',fixedAppointment:true,timeWindowStart:'09:00',timeWindowEnd:'10:00'});
 const out=decodeCore(encodeCore([j],[],0)).jobs[0];
 assert.equal(out.latitude,j.latitude);
 assert.equal(out.longitude,j.longitude);
 assert.equal(out.fixedAppointment,true);
 assert.equal(out.timeWindowStart,'09:00');
 assert.throws(()=>validateCore([{...j,latitude:95}],[],0),/invalid details or amounts/);
 assert.throws(()=>validateCore([{...j,longitude:undefined}],[],0),/invalid details or amounts/);
});

console.log('V050_PASS '+passed+'/5');
