"""Bounded UI probe for the dedicated RoundFlow emulator; never targets a phone."""
import argparse,json,os,re,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path

ADB=Path(os.environ['LOCALAPPDATA'])/'Android/Sdk/platform-tools/adb.exe'
SERIAL='emulator-5580'
OUT=Path(__file__).parent/'qa-evidence'
OUT.mkdir(exist_ok=True)

def adb(*args,timeout=18,binary=False):
    r=subprocess.run([str(ADB),'-s',SERIAL,*args],capture_output=True,text=not binary,timeout=timeout)
    if r.returncode:raise RuntimeError(str(r.stderr))
    return r.stdout

def dump():
    last=''
    for _ in range(5):
        raw=adb('exec-out','uiautomator','dump','--compressed','/dev/tty')
        start=raw.find('<?xml');end=raw.rfind('</hierarchy>')
        if start>=0 and end>=0:
            xml=raw[start:end+12]
            (OUT/'latest.xml').write_text(xml,encoding='utf8')
            return ET.fromstring(xml)
        last=raw;time.sleep(.5)
    raise RuntimeError('No UI hierarchy returned after retries: '+last[-200:])

def visible(root):
    return [{'text':n.get('text'),'label':n.get('content-desc'),'class':n.get('class'),'bounds':n.get('bounds')} for n in root.iter('node') if n.get('text') or n.get('content-desc') or n.get('class')=='android.widget.EditText']

def target(root,label,index=0):
    def tappable(n):
        bounds=list(map(int,re.findall(r'\d+',n.get('bounds',''))))
        return len(bounds)==4 and bounds[2]-bounds[0]>=8 and bounds[3]-bounds[1]>=12
    rows=[n for n in root.iter('node') if tappable(n) and ((label[7:] in (n.get('text') or '') or label[7:] in (n.get('content-desc') or '')) if label.startswith('prefix:') else n.get('content-desc')==label or n.get('text')==label)]
    if len(rows)<=index:raise RuntimeError('Visible control not found: '+label)
    return rows[index]

def tap_node(n):
    x1,y1,x2,y2=map(int,re.findall(r'\d+',n.get('bounds')))
    adb('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2));time.sleep(.5)

def capture(name):
    p=OUT/(name+'.png');p.write_bytes(adb('exec-out','screencap','-p',binary=True));return str(p)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['dump','tap','input','scroll','capture','restart']);ap.add_argument('value',nargs='?',default='screen');ap.add_argument('--index',type=int,default=0);ap.add_argument('--text',default='');args=ap.parse_args()
    if args.action=='tap':tap_node(target(dump(),args.value,args.index))
    elif args.action=='input':
        tap_node(target(dump(),args.value,args.index));adb('shell','input','keyevent','KEYCODE_MOVE_END');adb('shell','input','keyevent','--longpress','KEYCODE_DEL');adb('shell','input','text',args.text);adb('shell','input','keyevent','KEYCODE_BACK');time.sleep(.4)
    elif args.action=='scroll':
        nodes=list(dump().iter('node'));sc=[n for n in nodes if n.get('scrollable')=='true']
        if not sc:raise RuntimeError('No scrollable view found')
        x1,y1,x2,y2=map(int,re.findall(r'\d+',sc[0].get('bounds')));x=(x1+x2)//2
        a,b=(int(y2-(y2-y1)*.15),int(y1+(y2-y1)*.15))
        if args.value=='up':a,b=b,a
        adb('shell','input','swipe',str(x),str(a),str(x),str(b),'350');time.sleep(.5)
    elif args.action=='restart':
        adb('shell','am','force-stop','uk.co.roundflow.app');adb('shell','am','start','-n','uk.co.roundflow.app/.MainActivity');time.sleep(2)
    if args.action=='capture':print(capture(args.value))
    else:
        payload=json.dumps(visible(dump()),ensure_ascii=True);(OUT/'latest.json').write_text(payload,encoding='utf8');print(payload)
