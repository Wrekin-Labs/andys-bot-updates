"""Runs only on qa_roundflow.py's dedicated emulator, using synthetic demo data."""
import argparse,json,time
from qa_roundflow import adb,dump,target,tap_node,capture,OUT

ap=argparse.ArgumentParser();ap.add_argument('--start-step',type=int,default=1,choices=range(1,9));args=ap.parse_args()
results=json.loads((OUT/'flow-results.json').read_text(encoding='utf8'))[:args.start_step-1] if args.start_step>1 else []
assert all(r['status']=='PASS' for r in results), 'Resume requires the earlier steps to have passed'
def text(root):return '\n'.join(n.get('text','') for n in root.iter('node'))
def expect(value):
    found=text(dump())
    assert value in found, f'Missing {value!r} in screen: {found}'
def tap(label):tap_node(target(dump(),label))
def scroll_to(label):
    for attempt in range(18):
        root=dump()
        try:return target(root,label)
        except RuntimeError:
            nodes=[n for n in root.iter('node') if n.get('scrollable')=='true']
            if not nodes:raise
            import re
            x1,y1,x2,y2=map(int,re.findall(r'\d+',nodes[0].get('bounds')));x=(x1+x2)//2
            start=max(y1+120,y2-180);end=min(y2-180,y1+180)
            adb('shell','input','swipe',str(x),str(start),str(x),str(end),'420');time.sleep(.45)
    raise RuntimeError('Cannot reach '+label)
def enter(label,value):
    n=scroll_to(label);old=n.get('text','');tap_node(n)
    adb('shell','input','keyevent','KEYCODE_MOVE_END')
    for _ in range(min(100,len(old))):adb('shell','input','keyevent','KEYCODE_DEL')
    adb('shell','input','text',value);adb('shell','input','keyevent','KEYCODE_BACK');time.sleep(.4)
def check(name,fn):
    fn();results.append({'step':len(results)+1,'name':name,'status':'PASS'});print('PASS: '+name,flush=True)
    (OUT/'flow-results.json').write_text(json.dumps(results,indent=2),encoding='utf8')
def upgrade():
    tap('Money');expect('RF-00001');expect('£56.00');capture('02-money-after')
def edit():
    tap('prefix:RF-00001');enter('Item rate','19.50');tap('Preview');expect('£19.50');capture('03-preview-after')
    tap('Edit');enter('prefix:Payment amount','5');tap('Record payment');expect('£5.00 paid');capture('04-partial-payment')
    tap('Back to invoices');expect('£52.50');expect('£5.00')
def open_fixture_visit():
    # This dedicated emulator preserves the synthetic completed visit from 2026-09-20.
    # Do not assume the wall-clock 'Today' still matches the fixture date.
    tap('Today')
    for _ in range(8):
        root=dump()
        try:
            tap_node(target(root,'Schedule 2026-09-20'));return
        except RuntimeError:
            tap('Previous week')
    raise RuntimeError('Could not reach synthetic visit date 2026-09-20')

def guard():
    tap('Money');open_fixture_visit();tap_node(scroll_to('Undo'));expect('Cannot undo');tap('OK')
    tap('Money');expect('RF-00001');expect('£52.50')
def duplicate():
    tap('prefix:RF-00001');tap('Invoice actions');tap('Duplicate');expect('RF-00002');tap('Back to invoices');expect('£72.00')
def reverse():
    tap_node(scroll_to('prefix:RF-00001'));tap_node(scroll_to('Reverse recorded payment'));tap('REVERSE');tap('Back to invoices');expect('£77.00')
def undo():
    open_fixture_visit();tap_node(scroll_to('Undo'));tap('Money');expect('RF-00002');expect('£57.50');assert 'RF-00001' not in text(dump())
def redo():
    open_fixture_visit();tap_node(scroll_to('COMPLETE'));tap('Money');expect('RF-00003');expect('£75.50')
def restart():
    adb('shell','am','force-stop','uk.co.roundflow.app');adb('shell','am','start','-n','uk.co.roundflow.app/.MainActivity');time.sleep(2)
    expect('RoundFlow');capture('01-today-after');tap('Money');expect('RF-00003');expect('£75.50');capture('05-money-verified')

try:
    for step,(name,fn) in enumerate([('Upgrade retains v0.3.0 invoice and balance',upgrade),('Decimal editing and partial payment reconcile',edit),('Partial payment blocks completion undo',guard),('Duplicate updates customer balance',duplicate),('Partial payment reversal restores balance',reverse),('Undo removes the completed visit, preserving duplicate',undo),('Recompletion gets a new invoice number',redo),('Restart preserves invoices and balances',restart)],start=1):
        if step>=args.start_step:check(name,fn)
    print('ANDROID_INVOICE_FLOW_PASS 8/8',flush=True)
except Exception as error:
    results.append({'step':len(results)+1,'status':'FAIL','error':str(error)})
    (OUT/'flow-results.json').write_text(json.dumps(results,indent=2),encoding='utf8')
    capture('failure');raise
