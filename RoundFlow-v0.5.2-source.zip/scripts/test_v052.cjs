const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {load}=require('./lib_loader.cjs');
const routing=load('routing');

let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}
const job=(id,lat,lng)=>({id,name:id,area:'Telford',price:20,owing:0,freq:'4-weekly',tags:[],done:false,latitude:lat,longitude:lng});

test('Managed real-map viewport keeps numbered job pins on the map',()=>{
 const rows=[job('a',52.665,-2.470),job('b',52.685,-2.430),job('c',52.700,-2.455)];
 const v=routing.mapViewport(rows,700,420,56);
 assert.ok(v);assert.ok(v.zoom>=2&&v.zoom<=18);
 for(const j of rows){const p=routing.projectMapPoint(j.latitude,j.longitude,v);assert.ok(p.x>0&&p.x<700);assert.ok(p.y>0&&p.y<420);}
});

test('Static road map uses the same explicit camera as tappable pin overlay',()=>{
 const rows=[job('a',52.665,-2.470),job('b',52.685,-2.430)];
 const url=routing.staticMapUrl(rows,'abc123','pk.test');
 assert.doesNotMatch(url,/\/auto\//);
 assert.match(url,/pin-s-1/);
 assert.match(url,/pin-s-2/);
 assert.match(url,/path-4\+19a37f/);
});

test('Cleaner routing settings do not expose provider tokens or API setup',()=>{
 const src=fs.readFileSync(path.join(process.cwd(),'components','RoutingSettings.tsx'),'utf8');
 assert.ok(src.includes('Cleaners do not need a mapping account, API key or provider setup.'));
 assert.ok(!src.includes('Mapbox public token'));
 assert.ok(!src.includes('Test Mapbox'));
 assert.ok(!src.includes('Advanced routing service URL'));
});

test('Day Pilot live map auto-locates jobs and pins open the matching job',()=>{
 const src=fs.readFileSync(path.join(process.cwd(),'components','GeoRoutePanel.tsx'),'utf8');
 assert.ok(src.includes('ensureLocated'));
 assert.ok(src.includes('onOpenJob(j.id)'));
 assert.ok(src.includes('livePin'));
 assert.ok(!src.includes('SETUP NEEDED'));
 assert.ok(!src.includes('Open More → Settings → Routing Setup'));
});

console.log('V052_PASS '+passed+'/4');
