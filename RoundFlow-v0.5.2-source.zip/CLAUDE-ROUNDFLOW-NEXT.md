# RoundFlow — remaining external-account / deployment work only

> Post-review update (5 Oct 2026): item 1 (Andy Home verification, version bump and signed Android build) is complete. Items 2 onward remain external/deployment work. See `RELEASE_STATUS.md`.

1. **Verify on Andy Home**, then `node scripts/bump_version.mjs 0.4.0 23` and build/sign with the existing upload key (see TESTS "Not verified").
2. **Dedicated Supabase project** (new, RoundFlow-only, UK/EU region): apply `supabase/migrations/20261005120000_roundflow_v040_tenant_model.sql`, set `EXPO_PUBLIC_SUPABASE_URL` / `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` in `.env` (never the service-role key). Configure auth email templates and redirect URLs.
3. **Sync engine**: write the client sync (push by `client_id` upsert, pull by `updated_at` > cursor, tombstones via `deleted_at`, conflict = highest `version` wins with server re-check). `lib/cloudSync.ts` still targets the old draft schema and must be rewritten against the new one.
4. **Invitation email**: Edge Function to create `invitations` rows (store SHA-256 of a random token) and send the link; acceptance RPC already exists.
5. **Customer payment collection** (Stripe / GoCardless / PayPal accounts needed): Edge Function creates checkout/mandate sessions with the secret key; webhook function verifies signatures and inserts `payments` with `provider_ref` (idempotent — unique constraint exists); the app uses `lib/payments.ts` `applyProviderEvent` for local reconciliation.
6. **App subscription billing**: Google Play Billing (required for in-app digital subscriptions on Android) or web billing; webhook writes `subscriptions` with the service role only.
7. **Automatic SMS/email reminders**: provider account (e.g. Twilio/Postmark), scheduled Edge Function, `reminders.status` updates, opt-out handling.
8. **Customer portal / secure invoice links**: hosted page with signed, expiring tokens.
9. **Route optimisation** (optional, paid API) — current Maps hand-off and area ordering are free.
10. **Store release**: privacy policy and terms hosting, Play Data Safety update (business profile now stores bank details on device), store listing, closed testing track.
11. **iOS**: build and test on a Mac/EAS; safe-area insets (`react-native-safe-area-context`) for both platforms.
12. **GitHub remote** so the CI workflow (including the new database job) actually runs.

## Files ChatGPT should inspect first
1. `lib/ledger.ts` + `lib/coreState.ts` — derived balances, migration, void
2. `App.tsx` — `mutate()` and all money handlers
3. `scripts/test_v040.cjs`
4. `supabase/migrations/20261005120000_roundflow_v040_tenant_model.sql` + `supabase/tests/rls_test.sql`
5. `components/useStoredState.ts`, `lib/backup.ts`
6. `components/ui.tsx`, `components/InvoiceStudio.tsx`, `components/Insights.tsx`
7. `lib/profile.ts`, `lib/invoiceHtml.ts`, `lib/statement.ts`
