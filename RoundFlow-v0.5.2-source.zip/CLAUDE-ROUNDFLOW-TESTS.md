# RoundFlow v0.4.0 — Tests run and actual results

> Post-review update (5 Oct 2026): the previously unverified Windows/Android release checks were completed on Andy Home. Typecheck, all local tests, signed 0.4.0/code 23 artifacts and the 8/8 API 35 upgrade/invoice flow are verified. See `RELEASE_STATUS.md` for the current result.

Environment: Claude cloud workspace, Linux, Node 22.22, TypeScript 6.0.3 (global), PostgreSQL 16.
**The npm registry was blocked by this session's network policy (HTTP 403 `host_not_allowed`), so `npm ci` could not run.**

| Command | Result |
|---|---|
| `node scripts/test_csv_parser.mjs` | `CSV_MULTILINE_PASS` |
| `node scripts/test_invoice_integrity.cjs` (original 11 regressions, unchanged) | `INVOICE_INTEGRITY_PASS 11/11` |
| `node scripts/test_v040.cjs` (new) | `V040_PASS 18/18` |
| `npm test` (all three) | pass |
| `tsc` strict against **stub typings** for react / react-native / expo / async-storage / supabase (scratch config, not shipped) | 0 errors with `noImplicitAny` off; with it on, only implicit-any on callbacks of stubbed `any` components (real RN types infer these) |
| `supabase/tests/run_local.sh` (migration + RLS on PostgreSQL 16 with auth stub) | `RLS_TESTS_PASS`, 34 checks |

New tests cover: legacy date parsing; exact balance preservation on v0.3.1 upgrade; idempotent migration; downgrade-safe snapshot; derived balances through payment/reversal/settle; void protections; overdue/days-overdue; statement running totals incl. opening balances; cash-basis monthly reports with reversals/legacy/void; profile validation and PDF flow; quote numbering/expiry/single conversion; reminder text and logging; multi-leg routes; backup with corrupt sections and legacy restore; CSV injection + frequencies; idempotent provider reconciliation.

RLS suite covers: tenant isolation (read/insert/update), cross-tenant FK, worker/admin/owner limits, last-owner protection, owner-grant protection, client cannot change plan, invoices/payments undeletable, invoice renumber/void guards, offline invoice numbers, idempotent provider payments, sync version bump, audit trail, anon denied.

## NOT verified here — must run on Andy Home
1. `npm ci && npm run typecheck` with real dependencies.
2. `npm test` on Windows (expected identical).
3. `assembleRelease` / `bundleRelease` with JDK 17, signature check.
4. `scripts/test_android_invoice_flow.py` on the API 35 emulator (labels were preserved deliberately; undo now voids and hides the invoice, which matches its assertions).
5. Visual check of the redesigned screens at 320px width, large font scale and Android edge-to-edge — **no screenshots were possible here**.
6. Upgrade install over signed 0.3.1 with real-looking synthetic data; confirm balances unchanged and `roundflow.core.pre-0.4.0` written.
7. Native PDF sharing, attachments copy, SMS/email composers on a physical phone.
